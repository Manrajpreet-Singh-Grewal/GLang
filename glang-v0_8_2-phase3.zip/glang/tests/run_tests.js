// Glang test suite
// Run with: node tests/run_tests.js   (or: npm test)
//
// No test framework dependency on purpose — keeps `npm test` working with
// zero extra installs. Each test runs a snippet of Glang source through the
// real lexer -> parser -> interpreter pipeline and checks the captured
// output, or checks that a specific error is thrown.

const path = require("path");
const fs = require("fs");
const os = require("os");
const { Lexer } = require("../src/lexer.js");
const { Parser } = require("../src/parser.js");
const { Interpreter } = require("../src/interpreter.js");

let passed = 0;
let failed = 0;
const failures = [];

// Runs a Glang source string and returns everything passed to show() as an
// array of strings, in order. Throws if lexing/parsing/execution fails.
//
// show() writes straight to console.log, so we temporarily swap it out to
// capture output instead of printing it during the test run.
function run(source) {
  const output = [];
  const originalLog = console.log;
  console.log = (...parts) => output.push(parts.join(" "));
  try {
    const tokens = new Lexer(source).tokenize();
    const ast = new Parser(tokens).parse();
    new Interpreter().interpret(ast);
  } finally {
    console.log = originalLog;
  }
  return output;
}

// Like run(), but executes a real file on disk (so relative `import`
// statements resolve against that file's own directory) instead of a
// bare source string. Used by the module-import tests below.
function runFile(filePath) {
  const output = [];
  const originalLog = console.log;
  console.log = (...parts) => output.push(parts.join(" "));
  try {
    const source = fs.readFileSync(filePath, "utf8");
    const tokens = new Lexer(source).tokenize();
    const ast = new Parser(tokens).parse();
    new Interpreter().interpret(ast, filePath);
  } finally {
    console.log = originalLog;
  }
  return output;
}

// Writes a small throwaway multi-file project under a fresh temp
// directory. `files` is { "relative/path.grw": "source text" }. Returns
// the temp directory's absolute path.
function makeTempProject(files) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "glang-import-test-"));
  for (const [rel, contents] of Object.entries(files)) {
    const full = path.join(dir, rel);
    fs.mkdirSync(path.dirname(full), { recursive: true });
    fs.writeFileSync(full, contents, "utf8");
  }
  return dir;
}

function test(name, fn) {
  try {
    fn();
    passed++;
    console.log(`  \x1b[32m✓\x1b[0m ${name}`);
  } catch (err) {
    failed++;
    failures.push({ name, err });
    console.log(`  \x1b[31m✗ ${name}\x1b[0m`);
    console.log(`      ${err.message}`);
  }
}

function assertEqual(actual, expected, label) {
  if (actual !== expected) {
    throw new Error(
      `${label ? label + ": " : ""}expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`
    );
  }
}

function assertClose(actual, expected, tolerance, label) {
  const a = parseFloat(String(actual).replace(/[^0-9.\-]/g, ""));
  if (Math.abs(a - expected) > tolerance) {
    throw new Error(
      `${label ? label + ": " : ""}expected ~${expected} (tolerance ${tolerance}), got ${actual}`
    );
  }
}

function assertThrows(fn, messageSubstring, label) {
  try {
    fn();
  } catch (err) {
    if (messageSubstring && !err.message.includes(messageSubstring)) {
      throw new Error(
        `${label ? label + ": " : ""}expected error containing "${messageSubstring}", got "${err.message}"`
      );
    }
    return; // expected to throw — success
  }
  throw new Error(`${label ? label + ": " : ""}expected an error to be thrown, but none was`);
}

console.log("\n\x1b[1mGlang test suite\x1b[0m\n");

// ── Lexer / parser basics ─────────────────────────────────────────────────
console.log("\x1b[1mLexer & parser\x1b[0m");

test("variable declaration and show()", () => {
  const out = run(`let x = 5\nshow(x)`);
  assertEqual(out[0], "5");
});

test("currency literal parses and prints with symbol", () => {
  const out = run(`let balance = $1000\nshow(balance)`);
  assertEqual(out[0], "$1,000.00");
});

test("percent literal stores as a fraction", () => {
  const out = run(`let rate = 5%\nshow(rate)`);
  assertEqual(out[0], "5%");
});

test("tabs for indentation are rejected", () => {
  assertThrows(() => run("let x = 5\n\tshow(x)"), "Tabs aren't allowed");
});

test("unclosed string is rejected", () => {
  assertThrows(() => run(`show("unterminated`), "never closed");
});

// ── Control flow ──────────────────────────────────────────────────────────
console.log("\n\x1b[1mControl flow\x1b[0m");

test("if / else branches correctly", () => {
  const out = run(`let age = 20\nif age >= 18:\n    show("adult")\nelse:\n    show("minor")`);
  assertEqual(out[0], "adult");
});

test("repeat N times loops the right number of times", () => {
  const out = run(`let n = 0\nrepeat 4 times:\n    n = n + 1\nshow(n)`);
  assertEqual(out[0], "4");
});

test("for-in loop iterates a list in order", () => {
  const out = run(`let items = [10, 20, 30]\nfor x in items:\n    show(x)`);
  assertEqual(out.join(","), "10,20,30");
});

test("list indexing reads the right element", () => {
  const out = run(`let items = [10, 20, 30]\nshow(items[1])`);
  assertEqual(out[0], "20");
});

test("functions return values correctly", () => {
  const out = run(`fn add(a, b):\n    return a + b\nshow(add(3, 4))`);
  assertEqual(out[0], "7");
});

// ── Currency / percent type rules (the core "killer feature") ─────────────
console.log("\n\x1b[1mCurrency & percent type rules\x1b[0m");

test("currency + currency (same code) adds correctly", () => {
  const out = run(`show($100 + $50)`);
  assertEqual(out[0], "$150.00");
});

test("currency * percent gives a currency result", () => {
  const out = run(`let balance = $1000\nlet rate = 5%\nshow(balance * rate)`);
  assertEqual(out[0], "$50.00");
});

test("mixing different currencies without convert() is a friendly error, not silent math", () => {
  assertThrows(() => run(`show($100 + ₹100)`));
});

test("adding text and a number gives a plain-English error", () => {
  assertThrows(() => run(`let name = "Alex"\nlet age = 10\nshow(name + age)`), "combine");
});

// ── Financial stdlib correctness (checked against known formulas) ─────────
console.log("\n\x1b[1mFinancial functions\x1b[0m");

test("emi() matches the standard reducing-balance formula", () => {
  // P=500000, annual rate=8.5%, 20 years -> well-known EMI ~ 4,338
  const out = run(`show(emi($500000, 8.5%, 20))`);
  assertClose(out[0], 4338, 5, "emi(500000, 8.5%, 20)");
});

test("compound() matches A = P(1+r)^t", () => {
  // 1000 * 1.05^3 = 1157.625
  const out = run(`show(compound($1000, 5%, 3))`);
  assertClose(out[0], 1157.63, 0.05, "compound(1000, 5%, 3)");
});

test("cagr() matches (end/start)^(1/years) - 1", () => {
  // (350000/100000)^(1/5) - 1 ≈ 0.2851 -> 28.51%
  const out = run(`show(cagr($100000, $350000, 5))`);
  assertClose(out[0], 28.51, 0.1, "cagr(100000, 350000, 5)");
});

test("simple_interest() matches P*r*t", () => {
  const out = run(`show(simple_interest($10000, 5%, 3))`);
  assertClose(out[0], 1500, 0.01, "simple_interest(10000, 5%, 3)");
});

test("total = principal + interest for a loan over its term", () => {
  const out = run(
    `let total = total_loan_cost($500000, 8.5%, 20)\nlet interest = loan_interest_paid($500000, 8.5%, 20)\nshow(total - interest)`
  );
  assertClose(out[0], 500000, 1, "total_loan_cost - loan_interest_paid should equal principal");
});

// ── List builtins ──────────────────────────────────────────────────────────
console.log("\n\x1b[1mList builtins\x1b[0m");

test("total() sums a list of numbers", () => {
  const out = run(`show(total([1, 2, 3, 4]))`);
  assertEqual(out[0], "10");
});

test("average() computes the mean", () => {
  const out = run(`show(average([2, 4, 6]))`);
  assertEqual(out[0], "4");
});

test("append() returns a new list with the value added", () => {
  const out = run(`let a = [1, 2]\nlet b = append(a, 3)\nshow(b[2])\nshow(length(a))`);
  assertEqual(out[0], "3");
  assertEqual(out[1], "2", "append should not mutate the original list");
});

test("sort() orders a list ascending", () => {
  const out = run(`show(sort([3, 1, 2]))`);
  assertEqual(out[0], "[1, 2, 3]");
});

// ── Dictionaries ────────────────────────────────────────────────────────
console.log("\n\x1b[1mDictionaries\x1b[0m");

test("dict literal stores and prints key-value pairs", () => {
  const out = run(`let person = {name: "Alex", age: 30}\nshow(person.name)\nshow(person["age"])`);
  assertEqual(out[0], "Alex");
  assertEqual(out[1], "30");
});

test("keys() and values() return lists in insertion order", () => {
  const out = run(`let d = {a: 1, b: 2}\nshow(keys(d))\nshow(values(d))`);
  assertEqual(out[0], "[a, b]");
  assertEqual(out[1], "[1, 2]");
});

test("has_key() and dict_get() behave correctly for present/missing keys", () => {
  const out = run(
    `let d = {a: 1}\nshow(has_key(d, "a"))\nshow(has_key(d, "z"))\nshow(dict_get(d, "z", "fallback"))`
  );
  assertEqual(out[0], "true");
  assertEqual(out[1], "false");
  assertEqual(out[2], "fallback");
});

test("for-in over a dictionary iterates its keys", () => {
  const out = run(`let d = {a: 1, b: 2}\nfor k in d:\n    show(k)`);
  assertEqual(out.join(","), "a,b");
});

test("indexing a dict with a missing key gives a friendly error", () => {
  assertThrows(() => run(`let d = {a: 1}\nshow(d["nope"])`), "doesn't have a key");
});

test("dict[key] = value updates an existing key", () => {
  const out = run(`let d = {a: 1}\nd["a"] = 99\nshow(d.a)`);
  assertEqual(out[0], "99");
});

test("dict.key = value adds a brand-new key", () => {
  const out = run(`let d = {a: 1}\nd.b = 2\nshow(keys(d))`);
  assertEqual(out[0], "[a, b]");
});

test("list[i] = value updates a list in place", () => {
  const out = run(`let nums = [1, 2, 3]\nnums[0] = 99\nshow(nums)`);
  assertEqual(out[0], "[99, 2, 3]");
});

test("assigning into a non-container with [ ] gives a friendly error", () => {
  assertThrows(() => run(`let x = 5\nx[0] = 1`), "only lists and dictionaries");
});

// ── Regressions: security & crash fixes (v0.6.1) ──────────────────────────
console.log("\x1b[1mRegressions (v0.6.1)\x1b[0m");

test("stock() rejects a symbol containing shell metacharacters", () => {
  // Guards against the shell-injection bug fixed in 0.6.1: stock() used to
  // interpolate the ticker straight into a shell command. A malicious
  // symbol must now be rejected before it ever reaches a subprocess call,
  // with a friendly error rather than a shell escape or a crash.
  assertThrows(
    () => run(`let s = stock("AAA$(touch /tmp/should_never_run)")\nshow(s.price)`),
    "isn't a valid stock symbol"
  );
});

test("stock() rejects a symbol containing spaces or quotes", () => {
  assertThrows(
    () => run(`let s = stock("NOT A TICKER")\nshow(s.price)`),
    "isn't a valid stock symbol"
  );
});

test("stock() still accepts a normal ticker symbol", () => {
  // Make sure the allow-list isn't so strict it breaks legitimate symbols
  // like "RELIANCE.NS" or "BRK-B". We don't assert on network/mock
  // behavior here (that depends on the environment) — only that a
  // well-formed symbol never fails with the *validation* error.
  try {
    run(`let s = stock("BRK-B")\nshow(s.price)`);
  } catch (err) {
    assertEqual(
      err.message.includes("isn't a valid stock symbol"),
      false,
      "a well-formed ticker should never fail validation"
    );
  }
});

test("runaway recursion gives a friendly Glang error, not a raw JS crash", () => {
  // Guards against the RangeError-leak bug fixed in 0.6.1.
  assertThrows(
    () => run(`fn boom():\n    return boom()\nboom()`),
    "called itself too many times"
  );
});

test("negative currency prints the minus sign before the symbol", () => {
  const out = run(`let y = -$50\nshow(y)`);
  assertEqual(out[0], "-$50.00");
});

// ── New in v0.6.2: while / break / continue ───────────────────────────────
console.log("\x1b[1mLoops: while / break / continue (v0.6.2)\x1b[0m");

test("while loop runs until its condition is false", () => {
  const out = run(`let x = 0\nwhile x < 3:\n    show(x)\n    x = x + 1`);
  assertEqual(out.join(","), "0,1,2");
});

test("while loop with a false condition never runs its body", () => {
  const out = run(`let x = 5\nwhile x < 3:\n    show(x)`);
  assertEqual(out.length, 0);
});

test("break exits a while loop early", () => {
  const out = run(`let x = 0\nwhile true:\n    if x == 2:\n        break\n    show(x)\n    x = x + 1`);
  assertEqual(out.join(","), "0,1");
});

test("break exits a for-in loop early", () => {
  const out = run(`for n in [1,2,3,4,5]:\n    if n == 3:\n        break\n    show(n)`);
  assertEqual(out.join(","), "1,2");
});

test("break exits a repeat loop early", () => {
  const out = run(`let i = 0\nrepeat 10 times:\n    i = i + 1\n    if i == 3:\n        break\n    show(i)`);
  assertEqual(out.join(","), "1,2");
});

test("continue skips to the next iteration of a for-in loop", () => {
  const out = run(`for n in [1,2,3,4]:\n    if n == 2:\n        continue\n    show(n)`);
  assertEqual(out.join(","), "1,3,4");
});

test("continue skips to the next iteration of a while loop", () => {
  const out = run(`let x = 0\nwhile x < 5:\n    x = x + 1\n    if x == 3:\n        continue\n    show(x)`);
  assertEqual(out.join(","), "1,2,4,5");
});

test("break used outside any loop gives a friendly error", () => {
  assertThrows(() => run(`break`), "can only be used inside a loop");
});

test("continue used outside any loop gives a friendly error", () => {
  assertThrows(() => run(`continue`), "can only be used inside a loop");
});

// ── Phase 1 language features (v0.7.0 -> v0.8.0) ──────────────────────────
console.log("\n\x1b[1mPhase 1: elif / ternary / f-strings / const / random\x1b[0m");

test("elif picks the first matching branch", () => {
  const out = run(`let age = 15\nif age >= 18:\n    show("adult")\nelif age >= 13:\n    show("teen")\nelse:\n    show("kid")`);
  assertEqual(out[0], "teen");
});

test("elif falls through to else when nothing matches", () => {
  const out = run(`let age = 5\nif age >= 18:\n    show("adult")\nelif age >= 13:\n    show("teen")\nelse:\n    show("kid")`);
  assertEqual(out[0], "kid");
});

test("elif chain supports multiple elif branches", () => {
  const src = `fn grade(score):\n    if score >= 90:\n        return "A"\n    elif score >= 80:\n        return "B"\n    elif score >= 70:\n        return "C"\n    else:\n        return "F"\nshow(grade(85))\nshow(grade(65))`;
  const out = run(src);
  assertEqual(out.join(","), "B,F");
});

test("ternary expression picks the correct branch", () => {
  const out = run(`let age = 20\nlet label = "adult" if age >= 18 else "minor"\nshow(label)`);
  assertEqual(out[0], "adult");
});

test("ternary expression works with the false branch", () => {
  const out = run(`let age = 10\nshow("adult" if age >= 18 else "minor")`);
  assertEqual(out[0], "minor");
});

test("f-string interpolates a variable", () => {
  const out = run(`let name = "Alex"\nshow(f"Hello {name}")`);
  assertEqual(out[0], "Hello Alex");
});

test("f-string interpolates an expression, not just a bare variable", () => {
  const out = run(`show(f"Total: {1 + 2 * 3}")`);
  assertEqual(out[0], "Total: 7");
});

test("f-string interpolates money and formats it the normal way", () => {
  const out = run(`let total = $250\nshow(f"You owe {total}")`);
  assertEqual(out[0], "You owe $250.00");
});

test("f-string supports multiple interpolations in one string", () => {
  const out = run(`let a = 2\nlet b = 3\nshow(f"{a} + {b} = {a + b}")`);
  assertEqual(out[0], "2 + 3 = 5");
});

test("f-string escapes {{ and }} to literal braces", () => {
  const out = run(`show(f"{{not interpolated}} but {1 + 1} is")`);
  assertEqual(out[0], "{not interpolated} but 2 is");
});

test("plain (non-f) strings do not interpolate braces", () => {
  const out = run(`show("literal {not_a_var} text")`);
  assertEqual(out[0], "literal {not_a_var} text");
});

test("const declares a value that can be read normally", () => {
  const out = run(`const TAX_RATE = 8%\nshow(TAX_RATE)`);
  assertEqual(out[0], "8%");
});

test("reassigning a const gives a friendly error", () => {
  assertThrows(() => run(`const X = 5\nX = 6`), "is a constant and can't be changed");
});

test("const inside a function body is scoped normally", () => {
  const out = run(`fn area(r):\n    const PI = 3.14159\n    return PI * r * r\nshow(round(area(2), 2))`);
  assertEqual(out[0], "12.57");
});

test("random() with no args returns a decimal between 0 and 1", () => {
  const out = run(`let r = random()\nshow(r >= 0 and r < 1)`);
  assertEqual(out[0], "true");
});

test("random(min, max) returns a whole number in range", () => {
  const out = run(`let ok = true\nrepeat 50 times:\n    let r = random(1, 6)\n    if r < 1 or r > 6:\n        ok = false\nshow(ok)`);
  assertEqual(out[0], "true");
});

test("random(min, max) rejects a non-integer range", () => {
  assertThrows(() => run(`show(random(1.5, 6))`), "whole numbers");
});

test("random_choice() picks an item that's actually in the list", () => {
  const out = run(`let options = ["heads", "tails"]\nlet pick = random_choice(options)\nshow(contains(options, pick))`);
  assertEqual(out[0], "true");
});

test("random_choice() rejects an empty list", () => {
  assertThrows(() => run(`show(random_choice([]))`), "empty list");
});

// ── Phase 2: exception handling (try / catch / finally / throw) ──────────
console.log("\n\x1b[1mPhase 2: try / catch / finally / throw\x1b[0m");

test("try with no error skips catch entirely", () => {
  const out = run(`try:\n    show("fine")\ncatch err:\n    show("should not run")`);
  assertEqual(out.join(","), "fine");
});

test("catch binds the value passed to throw", () => {
  const out = run(`try:\n    throw "custom error"\ncatch e:\n    show(e)`);
  assertEqual(out[0], "custom error");
});

test("catch binds an engine error as a dictionary with .message", () => {
  const out = run(`try:\n    show(1 / 0)\ncatch err:\n    show(err.message)`);
  assertEqual(out[0], "Can't divide by zero.");
});

test("catch with no bound variable still catches", () => {
  const out = run(`try:\n    let x = undefined_var\ncatch:\n    show("caught")`);
  assertEqual(out[0], "caught");
});

test("finally runs after a normal try with no error", () => {
  const out = run(`try:\n    show("a")\nfinally:\n    show("cleanup")`);
  assertEqual(out.join(","), "a,cleanup");
});

test("finally runs after catch handles an error", () => {
  const out = run(`try:\n    throw "x"\ncatch e:\n    show("caught")\nfinally:\n    show("cleanup")`);
  assertEqual(out.join(","), "caught,cleanup");
});

test("finally runs even when a break unwinds through it", () => {
  const out = run(`for i in [1,2,3]:\n    try:\n        if i == 2:\n            break\n        show(i)\n    finally:\n        show(f"cleanup {i}")`);
  assertEqual(out.join(","), "1,cleanup 1,cleanup 2");
});

test("finally runs even when a return unwinds through it", () => {
  const out = run(`fn f():\n    try:\n        return 1\n    finally:\n        show("cleanup")\nshow(f())`);
  assertEqual(out.join(","), "cleanup,1");
});

test("an uncaught error inside try still propagates when there's no catch", () => {
  assertThrows(() => run(`try:\n    let x = undefined_var\nfinally:\n    show("cleanup")`), "no variable called");
});

test("try without catch or finally is a syntax error", () => {
  assertThrows(() => run(`try:\n    show("x")`), "needs a 'catch' and/or a 'finally'");
});

test("nested try/catch: inner catch handles its own error without affecting the outer try", () => {
  const out = run(`try:\n    try:\n        throw "inner"\n    catch e:\n        show(f"inner caught: {e}")\n    show("outer continues")\ncatch e:\n    show("outer should not run")`);
  assertEqual(out.join(","), "inner caught: inner,outer continues");
});

test("a function can use try/catch to recover and keep going", () => {
  const src = `fn safe_divide(a, b):\n    try:\n        if b == 0:\n            throw "cannot divide by zero"\n        return a / b\n    catch err:\n        return 0\nshow(safe_divide(10, 0))\nshow(safe_divide(10, 2))`;
  const out = run(src);
  assertEqual(out.join(","), "0,5");
});

// ── Phase 2: parser depth guard (found by fuzz testing) ───────────────────
console.log("\n\x1b[1mPhase 2: expression depth guard (fuzz-testing regression)\x1b[0m");

test("pathologically deep nested parens fail with a friendly error, not a raw JS crash", () => {
  const src = "show(" + "(".repeat(50000) + "1" + ")".repeat(50000) + ")";
  assertThrows(() => run(src), "nested too deeply");
});

test("reasonably deep (but normal) nesting still works fine", () => {
  const out = run("show(" + "(".repeat(50) + "1" + ")".repeat(50) + ")");
  assertEqual(out[0], "1");
});

test("a top-level 'return' outside any function gives a friendly error, not a crash (fuzz-found regression)", () => {
  assertThrows(() => run(`return $500`), "can only be used inside a function");
});

// ── Phase 3: list & dict comprehensions ────────────────────────────────
console.log("\n\x1b[1mPhase 3: list & dict comprehensions\x1b[0m");

test("basic list comprehension", () => {
  const out = run(`show([n * n for n in [1, 2, 3, 4]])`);
  assertEqual(out[0], "[1, 4, 9, 16]");
});

test("list comprehension with a filter condition", () => {
  const out = run(`let nums = [1, 2, 3, 4, 5, 6]\nshow([n for n in nums if n > 3])`);
  assertEqual(out[0], "[4, 5, 6]");
});

test("list comprehension over an empty list produces an empty list", () => {
  const out = run(`show([n for n in []])`);
  assertEqual(out[0], "[]");
});

test("list comprehension iterating a dict yields its keys, same as for-in", () => {
  const out = run(`let d = {a: 1, b: 2}\nshow([k for k in d])`);
  assertEqual(out[0], "[a, b]");
});

test("dict comprehension builds a dictionary from a loop", () => {
  const out = run(`show({str(n): n * n for n in [1, 2, 3]})`);
  assertEqual(out[0], "{1: 1, 2: 4, 3: 9}");
});

test("dict comprehension with a filter condition", () => {
  const out = run(`show({str(n): n for n in [1, 2, 3, 4] if n > 2})`);
  assertEqual(out[0], "{3: 3, 4: 4}");
});

test("dict comprehension requires text keys", () => {
  assertThrows(() => run(`show({n: n for n in [1, 2, 3]})`), "keys must be text");
});

test("comprehensions compose with f-strings, function calls, and ternaries", () => {
  const out = run(`fn label(n):\n    return f"item {n}" if n > 1 else "first"\nshow([label(n) for n in [1, 2, 3]])`);
  assertEqual(out[0], "[first, item 2, item 3]");
});

test("nested comprehensions (a comprehension inside a comprehension)", () => {
  const out = run(`let matrix = [[1, 2], [3, 4]]\nshow([[y * 2 for y in row] for row in matrix])`);
  assertEqual(out[0], "[[2, 4], [6, 8]]");
});

test("a normal dict literal (including bareword keys) still parses correctly, not as a comprehension", () => {
  const out = run(`show({name: "Alex", age: 30})`);
  assertEqual(out[0], "{name: Alex, age: 30}");
});

test("an empty list literal still works", () => {
  const out = run(`show([])`);
  assertEqual(out[0], "[]");
});

test("comprehension over a non-list/non-dict gives a friendly error", () => {
  assertThrows(() => run(`show([x for x in 5])`), "needs a list or dictionary");
});

// ── Phase 3: named & default function parameters ───────────────────────
console.log("\n\x1b[1mPhase 3: named & default function parameters\x1b[0m");

test("a default parameter is used when the argument is omitted", () => {
  const out = run(`fn greet(name, greeting = "Hello"):\n    return f"{greeting}, {name}!"\nshow(greet("Alex"))`);
  assertEqual(out[0], "Hello, Alex!");
});

test("a default parameter is overridden when an argument is supplied", () => {
  const out = run(`fn greet(name, greeting = "Hello"):\n    return f"{greeting}, {name}!"\nshow(greet("Alex", "Hi"))`);
  assertEqual(out[0], "Hi, Alex!");
});

test("default values are evaluated fresh per call, not memoized once", () => {
  const out = run(`let n = 1\nfn add_n(x, y = n):\n    return x + y\nshow(add_n(10))\nn = 100\nshow(add_n(10))`);
  assertEqual(out.join(","), "11,110");
});

test("a default expression can reference an earlier parameter", () => {
  const out = run(`fn f(a, b = 1, c = a + b):\n    return c\nshow(f(10))`);
  assertEqual(out[0], "11");
});

test("named arguments work in any order", () => {
  const out = run(`fn greet(name, greeting = "Hello"):\n    return f"{greeting}, {name}!"\nshow(greet(greeting = "Yo", name = "Sam"))`);
  assertEqual(out[0], "Yo, Sam!");
});

test("mixed positional + named arguments work", () => {
  const out = run(`fn greet(name, greeting = "Hello"):\n    return f"{greeting}, {name}!"\nshow(greet("Sam", greeting = "Hey"))`);
  assertEqual(out[0], "Hey, Sam!");
});

test("a parameter without a default after one with a default is a syntax error", () => {
  assertThrows(() => run(`fn f(a = 1, b):\n    return a`), "missing a default value");
});

test("calling with too few arguments and no default gives a friendly error", () => {
  assertThrows(() => run(`fn f(a, b):\n    return a\nshow(f(1))`), "missing a value for");
});

test("calling with too many positional arguments gives a friendly error", () => {
  assertThrows(() => run(`fn f(a):\n    return a\nshow(f(1, 2, 3))`), "too many values");
});

test("an unknown named argument gives a friendly error", () => {
  assertThrows(() => run(`fn f(a):\n    return a\nshow(f(b = 1))`), "doesn't have a parameter called");
});

test("passing the same parameter both positionally and by name is a friendly error", () => {
  assertThrows(() => run(`fn f(a, b):\n    return a\nshow(f(1, a = 2))`), "given both a positional value and a named value");
});

test("a positional argument after a named one is a friendly error", () => {
  assertThrows(() => run(`fn f(a, b):\n    return a\nshow(f(a = 1, 2))`), "plain value after a named argument");
});

test("built-in functions reject named arguments with a friendly error", () => {
  assertThrows(() => run(`show(str(value = 5))`), "doesn't support named arguments");
});

// ── Phase 3: user-defined modules (local .grw imports) ─────────────────
console.log("\n\x1b[1mPhase 3: user-defined modules\x1b[0m");

test("importing a local .grw file brings its functions and values into scope", () => {
  const dir = makeTempProject({
    "helper.grw": `let greeting = "Hi"\nfn double(x):\n    return x * 2`,
    "main.grw": `import "./helper.grw"\nshow(greeting)\nshow(double(21))`,
  });
  const out = runFile(path.join(dir, "main.grw"));
  assertEqual(out.join(","), "Hi,42");
});

test("import ... as gives a namespaced module for a local file too", () => {
  const dir = makeTempProject({
    "helper.grw": `fn double(x):\n    return x * 2`,
    "main.grw": `import "./helper.grw" as h\nshow(h.double(5))`,
  });
  const out = runFile(path.join(dir, "main.grw"));
  assertEqual(out[0], "10");
});

test("relative imports resolve against the importing file's own directory, not the process's cwd", () => {
  const dir = makeTempProject({
    "sub/helper.grw": `fn double(x):\n    return x * 2`,
    "main.grw": `import "./sub/helper.grw"\nshow(double(21))`,
  });
  const originalCwd = process.cwd();
  const elsewhere = fs.mkdtempSync(path.join(os.tmpdir(), "glang-elsewhere-"));
  process.chdir(elsewhere);
  let out;
  try {
    out = runFile(path.join(dir, "main.grw"));
  } finally {
    process.chdir(originalCwd);
  }
  assertEqual(out[0], "42");
});

test("a module imported from two different files only runs its top-level code once (cached per run)", () => {
  const dir = makeTempProject({
    "math_utils.grw": `show("math_utils loaded")\nfn square(x):\n    return x * x`,
    "helper.grw": `import "./math_utils.grw"\nfn helper_fn(x):\n    return square(x) + 1`,
    "main.grw": `import "./math_utils.grw"\nimport "./helper.grw"\nshow(square(5))\nshow(helper_fn(5))`,
  });
  const out = runFile(path.join(dir, "main.grw"));
  assertEqual(out.join(","), "math_utils loaded,25,26");
});

test("a circular import (a imports b imports a) fails with a friendly named cycle, not a crash", () => {
  const dir = makeTempProject({
    "a.grw": `import "./b.grw"`,
    "b.grw": `import "./a.grw"`,
  });
  assertThrows(() => runFile(path.join(dir, "a.grw")), "Circular import");
});

test("importing a local file that doesn't exist gives a friendly error", () => {
  const dir = makeTempProject({ "main.grw": `import "./nope.grw"` });
  assertThrows(() => runFile(path.join(dir, "main.grw")), `Can't find module`);
});

test("a top-level 'return' inside an imported module gives a friendly error, not a crash", () => {
  const dir = makeTempProject({
    "bad.grw": `return $500`,
    "main.grw": `import "./bad.grw"`,
  });
  assertThrows(() => runFile(path.join(dir, "main.grw")), "can only be used inside a function");
});

// ── Phase 3: file I/O ────────────────────────────────────────────────────
console.log("\n\x1b[1mPhase 3: file I/O\x1b[0m");

test("write_file then read_file round-trips text content", () => {
  const dir = makeTempProject({
    "main.grw": `write_file("out.txt", "hello glang")\nshow(read_file("out.txt"))`,
  });
  const out = runFile(path.join(dir, "main.grw"));
  assertEqual(out[0], "hello glang");
});

test("file_exists reflects reality before and after writing", () => {
  const dir = makeTempProject({
    "main.grw": `show(file_exists("data.txt"))\nwrite_file("data.txt", "x")\nshow(file_exists("data.txt"))`,
  });
  const out = runFile(path.join(dir, "main.grw"));
  assertEqual(out.join(","), "false,true");
});

test("append_file creates the file if it doesn't exist, and appends on repeat calls", () => {
  const dir = makeTempProject({
    "main.grw": `append_file("log.txt", "one ")\nappend_file("log.txt", "two")\nshow(read_file("log.txt"))`,
  });
  const out = runFile(path.join(dir, "main.grw"));
  assertEqual(out[0], "one two");
});

test("read_file on a missing file gives a friendly error, not a raw Node error", () => {
  const dir = makeTempProject({ "main.grw": `show(read_file("missing.txt"))` });
  assertThrows(() => runFile(path.join(dir, "main.grw")), "Can't find the file");
});

test("write_csv then read_csv round-trips a list of dictionaries", () => {
  const dir = makeTempProject({
    "main.grw": `let students = [{name: "Alex", score: "90"}, {name: "Sam", score: "85"}]\nwrite_csv("students.csv", students)\nlet loaded = read_csv("students.csv")\nshow(loaded[0].name)\nshow(loaded[1].score)`,
  });
  const out = runFile(path.join(dir, "main.grw"));
  assertEqual(out.join(","), "Alex,85");
});

test("read_csv handles a quoted field containing a comma", () => {
  const dir = makeTempProject({
    "data.csv": `name,note\n"Smith, John",hello\n`,
  });
  fs.writeFileSync(path.join(dir, "main.grw"), `let rows = read_csv("data.csv")\nshow(rows[0].name)`, "utf8");
  const out = runFile(path.join(dir, "main.grw"));
  assertEqual(out[0], "Smith, John");
});

test("file paths resolve relative to the script's own directory, not the process cwd", () => {
  const dir = makeTempProject({
    "sub/main.grw": `write_file("here.txt", "x")\nshow(file_exists("here.txt"))`,
  });
  const originalCwd = process.cwd();
  process.chdir(os.tmpdir());
  let out;
  try {
    out = runFile(path.join(dir, "sub", "main.grw"));
  } finally {
    process.chdir(originalCwd);
  }
  assertEqual(out[0], "true");
  assertEqual(fs.existsSync(path.join(dir, "sub", "here.txt")), true);
});

test("glang app scripts (AppInterpreter) don't have file I/O builtins at all — the sandbox policy", () => {
  const { AppInterpreter } = require("../src/app.js");
  const interp = new AppInterpreter({ text: () => {}, alert: () => {} }, {});
  assertEqual(interp.globals.vars.has("read_file"), false, "read_file should not exist in AppInterpreter");
  assertEqual(interp.globals.vars.has("write_file"), false, "write_file should not exist in AppInterpreter");
});

// ── Summary ─────────────────────────────────────────────────────────────
console.log(`\n\x1b[1m${passed} passed, ${failed} failed\x1b[0m out of ${passed + failed} tests\n`);

if (failed > 0) {
  process.exitCode = 1;
}
