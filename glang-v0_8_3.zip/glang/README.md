# Glang

A beginner-friendly programming language with **plain-English error messages**
and **native financial types** (currency and percentages). Built as a teaching
language — designed so a learner's first programs can be real personal-finance
calculations, not just "hello world."

File extension: `.grw`

## Quick start

```bash
npm install -g @manrajpreet.singh.grewal/glang
glang run examples/compound_interest.grw
```

Or from source, without installing globally:

```bash
node src/run.js examples/compound_interest.grw
```

## What makes Glang different

1. **Errors explain themselves.** Instead of `TypeError: unsupported operand
   type(s)`, Glang says what went wrong, in what value, and how to fix it —
   every error has a message *and* a suggested fix.

2. **Money and percentages are real types**, not just numbers:
   ```
   let balance = $1000
   let rate = 5%
   let interest = balance * rate   # -> $50.00, a real currency value
   ```
   Mixing incompatible types (e.g. adding USD and INR) gives a friendly error
   instead of silently doing the wrong thing.

3. **Clean, Python-like syntax** with indentation-based blocks, but more
   explicit (`let` for variables, `fn` for functions) to keep things
   unambiguous for beginners.

4. **A large built-in finance library** — EMI, loan cost/interest, compound
   interest, CAGR, SIP, NPV, IRR, ROI, tax brackets, take-home pay, and
   simple stock helpers — so real financial questions are a function call
   away, not a spreadsheet formula you have to derive yourself.

5. **Lists and loops** for real programs — `for item in list:`, `while
   condition:`, `repeat N times:`, `break`, `continue`, `sort()`, `total()`,
   `average()`, `append()`, and more — not just straight-line scripts.

## Language reference

```
let name = value            # declare a variable
name = value                 # reassign an existing variable

fn function_name(a, b):      # define a function
    return a + b

if condition:                 # conditional
    ...
elif other_condition:         # optional additional branches
    ...
else:
    ...

value_if_true if condition else value_if_false   # ternary/inline conditional

const NAME = value            # declare a value that can't be reassigned

repeat 5 times:               # loop N times
    ...

while condition:               # loop while a condition holds
    ...

for item in a_list:           # loop over a list
    ...

break                          # exit the current loop immediately
continue                       # skip to the next iteration of the current loop

[expr for var in a_list]                    # list comprehension
[expr for var in a_list if condition]       # list comprehension with a filter
{key_expr: value_expr for var in a_list}    # dict comprehension (same filtering with 'if')

fn greet(name, greeting = "Hello"):   # default parameter value
    return greeting + ", " + name

greet("Alex")                  # -> "Hello, Alex" (uses the default)
greet("Alex", "Hi")            # -> "Hi, Alex" (positional override)
greet(name = "Alex", greeting = "Hi")   # named arguments, any order
greet("Alex", greeting = "Hi")          # mixed positional + named (positional first)

try:                           # exception handling
    ...
catch err:                     # err.message / err.line / err.hint, or whatever was thrown
    ...
finally:                       # always runs, even on return/break/continue
    ...
throw "message"                # raise your own error (any value, not just text)

show(value, ...)              # print to output
str(value)                    # convert any value to text
f"Total: {amount}"            # string interpolation (any expression inside { })
random()                      # random decimal, 0 <= n < 1
random(1, 6)                  # random whole number, inclusive range
random_choice(a_list)         # random item from a list

$500   ₹500   €500   £500     # currency literals
5%                            # percentage literal (stored as 0.05)
[1, 2, 3]                     # list literal
my_list[0]                    # list indexing
{name: "Alex", age: 30}        # dictionary literal (bareword or "quoted" keys)
my_dict.name                  # dictionary dot access
my_dict["name"]               # dictionary bracket access
my_list[0] = 99                # list index assignment (mutates in place)
my_dict["city"] = "Delhi"       # dict key assignment (adds or updates)
my_dict.city = "Delhi"          # same, via dot syntax
import finance                # bring in a stdlib module
import "./mymodule.grw"       # bring in your own local .grw file
import "./mymodule.grw" as m  # same, but namespaced: m.some_function()

read_file(path)                # read a file's contents as text
write_file(path, content)      # write (overwrite) a file, creating it if needed
append_file(path, content)     # append text to a file, creating it if needed
file_exists(path)              # true/false
read_csv(path)                 # -> list of dicts, one per row, keyed by the header row
write_csv(path, list_of_dicts) # write a list of dicts as a CSV file
```

Local `import` paths and all `*_file`/`*_csv` paths are resolved relative to
the running script's own directory by default (not the terminal's current
directory), so a multi-file project works the same way no matter where you
run `glang run` from. File I/O (`read_file`, `write_file`, `append_file`,
`file_exists`, `read_csv`, `write_csv`) is only available under `glang run`
and `glang share` — it's deliberately unavailable inside `glang app`, since
app scripts run in a sandbox specifically so untrusted/shared code can't
touch the host filesystem.

### Type rules for currency/percent

| Operation | Result |
|---|---|
| `currency + currency` (same code) | `currency` |
| `currency + currency` (different code) | **error** — must `convert()` first |
| `currency * number` | `currency` |
| `currency * percent` | `currency` |
| `percent + percent` | `percent` |
| `number * percent` | `number` |

### Built-in functions (partial — run `glang docs` for the full reference)

- **Core**: `show`, `str`, `num`, `round`, `abs`, `type_of`
- **Text**: `upper`, `lower`, `trim`, `split`, `join`, `contains`, `replace`, `substring`
- **Lists**: `sort`, `reverse`, `unique`, `slice`, `first`, `last`, `total`, `average`, `append`, `length`
- **Dictionaries**: `keys`, `values`, `has_key`, `dict_get`, `is_dict`
- **Math**: `floor`, `ceil`, `sqrt`, `power`, `min`, `max`
- **Finance**: `simple_interest`, `compound`, `emi`, `total_loan_cost`, `cagr`, `sip`, `npv`, `irr`, `roi`, `tax`, `take_home`
- **Stocks**: `stock`, `portfolio_value`, `history`, `moving_average`, `compare_stocks`
- **Files** (CLI/share only, not `glang app`): `read_file`, `write_file`, `append_file`, `file_exists`, `read_csv`, `write_csv`

### Standard library modules (`import ...`)

- `finance` — loan affordability, rule of 72, real return, savings rate
- `tax` — old-vs-new regime comparisons, HRA exemption, GST
- `stocks` — price-to-book, dividend yield, intrinsic value, position sizing
- `math` — general numeric helpers (`increase_by`, `clamp`, etc.)

## CLI commands

```
glang run   <file.grw>       Run a script in the terminal
glang app   <file.grw>       Start a web app at http://localhost:4000
glang share <file.grw>       Export standalone HTML (no install needed)
glang site  <file.grw>       Generate a full website (landing + app + embed)
glang new   <name>           Scaffold a new project
glang docs  [output.md]      Generate the full language reference
glang packages                List all available modules
```

Note: scripts that call `input(...)` or `show_card(...)` (like
`examples/loan_calculator.grw`) are written for `glang app`, not `glang run`
— they render as an interactive web form, not a terminal script.

`examples/comprehensions_demo.grw`, `examples/named_default_params_demo.grw`,
and `examples/file_io_demo.grw` demonstrate the Phase 3 language features
(comprehensions, named/default parameters, file I/O). For a real multi-file
project using local `import`, see `examples/multi_file_project/` — run
`glang run examples/multi_file_project/main.grw` from anywhere.

## Project structure

```
src/
  lexer.js         # source text -> tokens
  parser.js         # tokens -> AST (recursive descent)
  interpreter.js     # tree-walking interpreter (executes the AST directly)
  run.js             # CLI entry point, renders errors in plain English
  app.js             # web-app server for interactive .grw scripts
  share.js, site.js   # HTML export / static site generation
  sandbox.js, sandbox-worker.js  # runs glang app requests in an isolated,
                                  # time- and memory-limited worker thread

packages/stdlib/     # finance.grw, tax.grw, stocks.grw, math.grw
examples/             # sample programs
tests/                # automated test suites + fuzz tester
```

## Running the tests

```bash
npm test        # core interpreter tests + app/share/site layer tests
npm run fuzz     # fuzz tester: mutated + randomly-generated input, 4000 cases
```

Covers lexer/parser edge cases, currency/percent type rules, control flow,
exception handling, and financial functions checked against known-correct
values (EMI, compound interest, CAGR, etc.), so a wrong calculation surfaces
before it ships. The fuzz tester feeds mutated and randomly-generated source
through the real pipeline and flags anything that crashes instead of failing
gracefully with a normal Glang error; it's seeded and reproducible, and runs
as part of CI on every push/PR.

## The browser bundle

`src/browser-bundle.js` is a generated file (browserified from
`src/browser-glang.js`) used by `glang share` and `glang site` to run Glang
directly in a browser with no install. It's regenerated automatically before
every `npm publish` via the `prepublishOnly` script, so it can't silently go
stale relative to the interpreter. If you're hacking on the interpreter and
testing the browser/share/site output locally, rebuild it manually first:

```bash
npm run build-browser
```

## Roadmap

- **Bytecode VM** — compile the AST to bytecode instead of tree-walking, for
  speed and to support a faster standalone binary.
- **Live currency conversion** (`convert(amount, to: "INR")`) — currently
  stubbed with a friendly "not available yet" error.
- **The step-by-step execution visualizer** and **beginner→advanced syntax
  growth path** — the other two "killer features" from the original design,
  not yet started.
- **Editor support** — syntax highlighting for `.grw` files.

## Design decisions worth knowing

- **Tabs are disallowed** for indentation — spaces only, to avoid an entire
  category of confusing beginner errors.
- **Mixed-currency math always errors** rather than guessing an exchange
  rate — silently converting would both require live rate data and teach
  the wrong mental model about money.
- Built with a tree-walking interpreter first, on purpose — this proves out
  language semantics quickly. The bytecode VM should only be built once the
  language design feels solid, otherwise you'll be debugging VM bugs and
  language bugs at the same time.

## License

MIT — see [LICENSE](LICENSE).
