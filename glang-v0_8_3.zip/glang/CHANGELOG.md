# Changelog

## 0.8.3 — Windows stack-size fix

- Fixed a test/CI-only issue found when running on Windows: the runaway-
  recursion test asserted on one specific friendly error message
  ("called itself too many times"), assuming Glang's own 900-level call
  counter would always fire before the underlying JS engine ran out of
  native stack space. On platforms with a smaller default stack (seen
  on some Windows setups), the real stack can run out slightly earlier,
  which is already handled safely by the existing `RangeError` fallback
  in `callFunction()` (added earlier, in 0.6.1) — but that fallback
  produces a different, equally friendly message ("recursed too
  deeply..."), which the test didn't recognize as a pass.
  - Lowered `MAX_CALL_DEPTH` from 900 to 500 to widen the safety margin
    before hitting a platform's native stack limit, so Glang's own
    counter is more likely to fire first (and produce the more specific
    "missing a base case" guidance) on constrained-stack platforms too.
  - Updated the test to accept either friendly message as a pass, since
    both represent the same correct behavior: no raw, unhandled crash
    ever reaches the user, regardless of which safety net catches it
    first on a given platform.
  - No behavior change for normal Glang programs — 500 levels of
    recursion is still far more than any realistic teaching/finance
    script needs; this only affects the runaway/infinite-recursion case.

## 0.8.2 — Phase 3: language completeness

**List & dict comprehensions**
- Added `[expr for var in iterable]` and `[expr for var in iterable if
  condition]` list comprehensions, and `{key_expr: value_expr for var in
  iterable}` / `... if condition` dict comprehensions — concise syntax
  for building a list or dict from a loop instead of the old "make an
  empty list, loop, `append()`" pattern.
  - Iterating a dict in a comprehension yields its keys, matching the
    existing `for var in a_dict:` behavior exactly.
  - Compose with everything else: nested comprehensions (a comprehension
    whose expression is itself a list literal containing a
    comprehension), f-strings, ternaries, function calls, etc.
  - Dict comprehension keys must evaluate to text (same rule as regular
    dict literals) — a non-text key gives a friendly error instead of a
    silently broken dictionary.
  - Parsing note: dict comprehensions and normal dict literals share the
    same `{` — the parser speculatively parses `key_expr : value_expr`
    and only commits to a comprehension if a `for` follows; otherwise it
    rolls back and parses a normal dict literal (preserving the existing
    bareword-key sugar, e.g. `{name: "Alex"}`, unchanged).
  - Fixed a real grammar ambiguity found while implementing this: a
    comprehension's iterable expression (`for x in <iterable>`) was
    parsed with full ternary precedence, so a trailing `if` meant as the
    comprehension's filter clause was instead swallowed as the start of
    a `x if cond else y` ternary on the iterable. The iterable is now
    parsed one precedence level below ternary; wrap it in parentheses if
    you genuinely need a ternary there (`for x in (a if cond else b)`).

**Named & default function parameters**
- Added default parameter values: `fn greet(name, greeting = "Hello"):`
  — callable as `greet("Alex")` or `greet("Alex", "Hi")`. Once one
  parameter has a default, every parameter after it must have one too
  (a friendly syntax error otherwise), matching the common convention in
  languages Glang's syntax resembles.
  - Defaults are evaluated fresh on every call, not memoized once at
    function-definition time — so `fn f(x, y = some_global):` picks up
    the current value of `some_global` each call, not whatever it was
    when `f` was defined.
  - A default expression can reference an earlier parameter, e.g.
    `fn split(total, first_share = total / 2):` — earlier parameters are
    already bound by the time a later default is evaluated.
- Added named arguments at the call site: `greet(name = "Alex", greeting
  = "Hi")`, in any order, and mixed positional + named calls
  (`greet("Alex", greeting = "Hi")`, positional arguments filling
  left-to-right first). Chose `name = value` over `name: value` for
  keyword arguments since `=` is the more conventional choice in the
  languages Glang's syntax otherwise resembles, and it stays visually
  distinct from dict-literal `key: value` syntax.
  - Friendly errors for every failure mode: missing a required
    (non-default) parameter, an unknown named argument, the same
    parameter given both positionally and by name, a positional
    argument written after a named one, and too many positional
    arguments — each names the function and its parameters rather than
    just saying "wrong number of arguments."
  - Built-in functions (`show`, `str`, etc.) don't support named
    arguments — calling one with `name = value` gives a friendly error
    rather than silently ignoring the name, since built-ins only bind
    positionally.

**User-defined modules (`import "./yourfile.grw"`)**
- This already partially worked before this release (it could already
  resolve a relative/absolute `.grw` file path, distinct from the 4
  built-in stdlib modules) — this release verifies it end-to-end for a
  realistic multi-file project and fixes real bugs found doing that:
  - **Fixed a path-resolution bug**: a relative `import "./helper.grw"`
    was resolving against the process's current working directory
    (`cwd`), not the *importing file's own directory* — so a student's
    multi-file project only worked if `glang run` happened to be
    invoked from exactly the right folder. Local imports (and, since it
    shares the same resolution logic, all file-I/O paths — see below)
    now resolve relative to whichever file is currently importing/
    running, tracked via a small directory stack (`baseDirStack`) pushed
    and popped as modules import other modules.
  - **Added circular import detection**: `a.grw` importing `b.grw`
    importing `a.grw` (or any longer cycle) now fails with a friendly
    error naming the full chain (e.g. `Circular import: a.grw → b.grw →
    a.grw`) instead of infinite-looping or blowing the call stack.
  - **Added re-import caching**: a module imported from two different
    places in one run (e.g. both `main.grw` and `helper.grw` importing
    `math_utils.grw`) now executes its top-level code exactly once,
    keyed by the module's resolved absolute path, and every importer
    shares the same exports. Chosen over re-executing on every import
    because a module with side effects (e.g. a stray `show()` at module
    scope) would otherwise print its output once per importer, which is
    both wasteful and confusing. This also applies uniformly to the
    stdlib/community modules, which previously re-executed on every
    `import` statement.
  - Confirmed `import "./mymodule.grw" as m` namespacing works for local
    files exactly like it already did for stdlib modules.
  - When an error occurs inside a module (a normal runtime error, a
    parse error, or a circular-import error surfacing from a nested
    import), it's no longer re-wrapped with a generic "Error running
    module..." prefix at every level of nesting — the original friendly
    message, hint, and line number propagate through unchanged.
  - Added `examples/multi_file_project/` (a `main.grw` + `budget_helpers.grw`
    pair) as a real runnable example, referenced from the README.

**File I/O**
- Added `read_file(path)`, `write_file(path, content)`,
  `append_file(path, content)`, and `file_exists(path)`, plus
  `read_csv(path)` (→ a list of dictionaries, one per row, keyed by the
  header row) and `write_csv(path, list_of_dicts)` — the CSV helpers use
  a small hand-rolled parser/writer (quoted fields, embedded commas,
  `""`-escaped quotes) rather than a dependency, specifically to remove
  the "students hand-rolling CSV parsing with `split()`" gap called out
  in the original scope.
  - All paths resolve relative to the running script's own directory by
    default (reusing the exact same `baseDirStack` resolution logic
    built for module imports above), so file I/O is cwd-independent the
    same way local imports are.
  - **Security decision (read this if you're touching `glang app`)**:
    file I/O builtins are only registered on the plain CLI `Interpreter`
    (`glang run` / `glang share`) — `AppInterpreter` (`src/app.js`,
    used by `glang app`) is constructed with `{ allowFileIO: false }`
    and never gets `read_file`/`write_file`/etc. defined at all. This
    was chosen over the alternative (allowing file I/O inside `glang
    app` but jailed to a per-run temp directory) because it's strictly
    simpler and has no path-escaping logic to get wrong — and Phase 2's
    entire reason for adding real `worker_thread` sandboxing was so
    `glang app` could safely run untrusted/shared scripts; giving those
    scripts any filesystem access at all would undermine that, however
    carefully jailed. Verified (not just assumed) by calling
    `read_file()` from inside both `runApp()` and the real
    `runSandboxed()` worker-thread path with a directory-traversal path
    (`../../etc/passwd`) and confirming the builtin doesn't exist there
    at all — it fails as an undefined variable, the same as any other
    typo would.

**Testing**
- `npm test` now runs 136 tests total (120 core + 16 app-layer, up from
  95 in 0.8.1), adding coverage for: comprehensions (including the
  dict-key-must-be-text and non-list/dict-iterable error paths),
  named/default parameters (every friendly-error case listed above),
  modules (caching, circular imports, cwd-independence — using real
  temp-directory multi-file projects on disk, not just in-memory
  source), and file I/O (round-tripping text and CSV, missing-file
  errors, and — importantly — a direct assertion that `AppInterpreter`
  never defines `read_file`/`write_file` at all).
- Ran the fuzz tester (`npm run fuzz`) repeatedly across multiple seeds
  throughout implementation, especially after the comprehension and
  named/default-parameter grammar changes (new syntax = new ways to
  write malformed input).
- **Found and fixed a real crash via fuzzing**: a top-level `return`
  outside any function (e.g. a stray `return $500` at the start of a
  script) threw an internal `ReturnSignal` object that nothing caught,
  surfacing as a raw `Internal Glang error: undefined` instead of a
  normal Glang error — pre-existing since `return`, unlike `break`/
  `continue`, was never guarded against appearing outside its valid
  context. Fixed both at the top level (`interpret()`) and inside
  module execution (`execImport()`, which has the same "run a block of
  top-level statements" shape), so a stray `return` now fails with
  `"return" can only be used inside a function.` either way. 10,000+
  fuzz cases across multiple seeds run clean with zero crashes as of
  this release.

## 0.8.1 — Phase 2: robustness & safety

**Language feature**
- Added exception handling: `try:` / `catch err:` / `finally:` / `throw`.
  - `catch err:` binds either exactly what you `throw` (a string, number,
    dict — whatever), or, for an engine error (bad input, missing
    variable, divide by zero, etc.), a dictionary with `.message`,
    `.line`, and `.hint` so it's inspectable like any other value.
  - `catch:` with no bound name is allowed when you just want to recover
    without needing the error value.
  - `finally:` always runs — even if the try (or catch) block returns,
    breaks, continues, or re-throws.
  - `try` needs at least one of `catch`/`finally` after it (a bare `try`
    with neither is a syntax error, since it wouldn't do anything).
  - Lets a script validate input and recover instead of halting
    completely on the first bad value — e.g. a safe-divide helper that
    catches divide-by-zero and returns a fallback instead of crashing
    the whole program.

**Execution sandboxing (`glang app`)**
- Every request to a running `glang app` server now executes inside its
  own `worker_thread` (`src/sandbox.js`, `src/sandbox-worker.js`)
  instead of on the server's main thread.
  - **Timeout**: a script that runs past 5 seconds (configurable via
    `GLANG_APP_TIMEOUT_MS`) is stopped and shown a friendly "this took
    too long" message, instead of hanging the request forever.
  - **Memory cap**: a script that allocates past 128MB (configurable via
    `GLANG_APP_MEMORY_MB`) is stopped with a friendly message, instead
    of exhausting the server process's memory.
  - **Isolation**: each request gets a completely separate V8 isolate,
    so nothing from one student's session can leak into another's —
    this was previously untested; it's now covered by concurrency tests
    that fire several requests at once and confirm each sees only its
    own variables.
- This directly addresses "no execution sandboxing/limits" and "no
  verified multi-user concurrency handling" from the technical gap list.

**Fuzz testing**
- Added `tests/fuzz.js` (`npm run fuzz`), a seeded/reproducible fuzz
  tester covering the lexer → parser → interpreter pipeline. Combines
  mutation fuzzing (corrupting real example programs — deletions,
  insertions, truncation, mangled indentation) and grammar-soup fuzzing
  (random sequences of real Glang tokens). Anything that isn't handled
  as a normal `GlangSyntaxError`/`GlangRuntimeError` is reported as a
  crash. Wired into CI (5,000 cases per run) as a regression gate.
- **Found and fixed a real crash via fuzzing**: pathologically deep
  nested parentheses (tens of thousands of `(` deep) blew the real JS
  call stack and leaked a raw, unwrapped `RangeError` — not a friendly
  Glang error. Added `MAX_EXPR_DEPTH` to the parser (same "explain,
  don't crash" pattern as the interpreter's existing recursion guard),
  so this now fails with a normal, readable syntax error instead.
  Reasonable nesting (tested up to 50 levels) is unaffected.
- 6,000+ fuzz cases across multiple seeds run clean with zero crashes
  as of this release.

**Testing**
- `npm test` now runs 95 tests total (79 core + 16 app-layer, up from
  76 in 0.8.0), including full coverage of the new try/catch/finally
  behavior and the parser depth guard.
- CI now also runs the fuzz suite on every push/PR.

## 0.8.0 — Phase 1: quick language wins + quality infrastructure

**Language features**
- Added `elif`, so multi-branch conditionals no longer need nested
  `if`/`else`. `if a: ... elif b: ... elif c: ... else: ...` chains as
  far as you like, and reads exactly like `if`/`else` (it desugars to
  nested `if`s under the hood, so scoping and error messages match).
- Added ternary/inline conditional expressions:
  `"adult" if age >= 18 else "minor"`. Works anywhere an expression is
  allowed (assignments, function args, f-strings, etc.) and can be
  chained/nested on its "else" side.
- Added string interpolation with f-strings: `f"Total: {amount}"`.
  Any expression can go inside `{ }` (not just a bare variable), values
  are formatted exactly the way `show()`/`str()` already format them
  (so money and percent values look right automatically), and `{{`/`}}`
  escape to literal braces.
- Added `const` for declaring values that can't be reassigned. Trying
  to assign to a `const` gives a friendly error pointing at `let`
  instead. Scoped the same way `let` is (function-local, block-local).
- Added `random()` (decimal between 0 and 1), `random(min, max)`
  (whole number in an inclusive range — dice rolls, simple
  simulations), and `random_choice(list)` (pick one item at random).

**Testing & quality infrastructure**
- Added a GitHub Actions CI workflow (`.github/workflows/ci.yml`) that
  builds the browser bundle and runs the full test suite on every push
  and pull request, across Node 16/18/20.
- Added `tests/run_tests_app_layer.js`, the first automated coverage
  of the `glang app` / `glang share` / `glang site` layer (previously
  only the core interpreter had test coverage — this is exactly the
  gap that let the earlier `--title`/`--desc` bug slip through).
  `npm test` now runs both suites (76 tests total).
- Fixed a bug in `show_metric()` (app layer) found by the new tests:
  the trend-direction argument referenced a variable (`chg`) outside
  the scope where it was declared, which threw "chg is not defined"
  on every call. `show_metric()` now works correctly.

## 0.7.0

**Consistency fix**
- `glang version` and `glang help` were hardcoded to "v0.6.0" — stale
  since an earlier release, and wrong before this fix even landed. Both
  now read the version from `package.json`, same as `glang docs`, so
  there's a single source of truth. Copyright/author name updated to
  the full name throughout (LICENSE, package.json, CLI banner, docs).

**Language feature**
- Added `while condition:` loops. Previously the only loop constructs were
  `repeat N times` (fixed count) and `for item in list` (iteration) —
  there was no way to express "keep going until a condition changes,"
  which is a normal thing to want (e.g. "pay down a loan until the
  balance hits zero"). A runaway `while` loop (condition that never
  becomes false) now stops with a friendly Glang error after 10 million
  iterations, the same "explain, don't crash" philosophy as the existing
  recursion-depth guard, instead of hanging the process forever.
- Added `break` and `continue`, usable inside `repeat`, `while`, and
  `for` loops. Using either outside of any loop gives a friendly error
  explaining why, instead of a confusing failure.
- Added `examples/debt_payoff.grw` demonstrating `while` + `break`.

**Docs fix**
- `glang docs` was hardcoded to "v0.4" and missed roughly 40 built-in
  functions (all of text, math, date, type-checking, and every stdlib
  module function). It now pulls the version from `package.json`
  automatically, and documents the full, verified function surface.

## 0.6.1

**Security fix**
- `stock()` / `history()` / `portfolio_value()` and related built-ins built a
  shell command by interpolating the ticker symbol directly into a string
  passed to `execSync`. A crafted symbol (e.g. one containing `$(...)`)
  could inject arbitrary shell commands into the process running the
  interpreter — including, notably, a `glang app` web server where the
  symbol can come from an end user's form input via `input(...)`.
  Fixed by:
  - Validating ticker symbols against a strict allow-list
    (`[A-Za-z0-9.-]`, max 20 chars) before they're used anywhere, with a
    friendly rejection error for anything else.
  - Replacing `execSync` (which runs through `/bin/sh`) with
    `execFileSync` (which runs the binary directly, with an argument
    array, and never interprets shell metacharacters), as defense in
    depth.

**Bug fix**
- Deep recursion (e.g. a function missing its base case) used to crash
  with a raw Node.js `RangeError: Maximum call stack size exceeded` and a
  JS stack trace — exactly the kind of cryptic error Glang exists to
  avoid. The interpreter now tracks call depth and raises a normal,
  friendly Glang error ("recursed too deeply...") once it passes 900
  nested calls, well before the real JS stack limit is hit.

**Minor fix**
- Negative currency values now print as `-$50.00` instead of `$-50.00`.
