// Glang fuzz tester
// Run with: node tests/fuzz.js [iterations]   (default 4000)
//
// Feeds malformed / random / mutated source through the real
// Lexer -> Parser -> Interpreter pipeline and checks ONE thing per case:
// did Glang fail *gracefully*? "Gracefully" means either it ran fine, or
// it threw a GlangSyntaxError / GlangRuntimeError (the "explain, don't
// crash" error types every other part of Glang is built around) within
// a bounded number of steps. Anything else — a raw JS TypeError, a stack
// overflow that isn't Glang's own recursion guard, an infinite loop that
// ignores the loop guard, etc. — is a crash and gets reported.
//
// Two strategies:
//   1. Mutation fuzzing: take real, valid .grw programs (the example
//      files) and corrupt them — delete/insert/flip characters, chop
//      indentation, truncate mid-token — the way a student mashing keys
//      or a copy-paste gone wrong actually produces broken input.
//   2. Grammar-soup fuzzing: stitch together random tokens/snippets from
//      Glang's own vocabulary in random order, so we get input that
//      *looks* like Glang but almost never parses — the adversarial case
//      described in the Phase 2 goal ("students who will absolutely
//      write broken code in creative ways").
//
// Deterministic: seeded PRNG, so a failing run can be reproduced exactly
// by re-running with the same seed (printed at the top of the output).

const fs = require("fs");
const path = require("path");

const { Lexer, GlangSyntaxError } = require("../src/lexer.js");
const { Parser } = require("../src/parser.js");
const { Interpreter, GlangRuntimeError, GlangThrownValue } = require("../src/interpreter.js");

// ── Seeded PRNG (mulberry32) — deterministic and reproducible ─────────────
function mulberry32(seed) {
  let a = seed;
  return function () {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const SEED = Number(process.argv[3]) || Date.now() | 0;
const ITERATIONS = Number(process.argv[2]) || 4000;
const rand = mulberry32(SEED);

function randInt(max) { return Math.floor(rand() * max); }
function pick(arr) { return arr[randInt(arr.length)]; }

// ── Load real programs as mutation seeds ───────────────────────────────
const examplesDir = path.join(__dirname, "../examples");
const seedSources = fs
  .readdirSync(examplesDir)
  .filter((f) => f.endsWith(".grw"))
  .map((f) => fs.readFileSync(path.join(examplesDir, f), "utf8"));

// A few hand-written small seeds too, so fuzzing isn't only large programs
seedSources.push(
  `let x = 5\nshow(x)`,
  `fn add(a, b):\n    return a + b\nshow(add(1, 2))`,
  `if true:\n    show("yes")\nelif false:\n    show("no")\nelse:\n    show("maybe")`,
  `try:\n    throw "oops"\ncatch err:\n    show(err.message)\nfinally:\n    show("done")`,
  `let name = "Alex"\nshow(f"Hello {name}, total: {1+2}")`,
  `for x in [1,2,3]:\n    show(x)`,
  `const RATE = 8%\nshow(RATE)`
);

// ── Mutation strategies (character-level) ───────────────────────────────
const RANDOM_CHARS = "{}[]()\"'#:.,+-*/%\t\n abcXYZ$₹€£=<>!_0123456789";

function mutateOnce(src) {
  if (src.length === 0) return pick(RANDOM_CHARS);
  const op = randInt(6);
  const i = randInt(src.length);
  switch (op) {
    case 0: // delete a char
      return src.slice(0, i) + src.slice(i + 1);
    case 1: // insert a random char
      return src.slice(0, i) + pick(RANDOM_CHARS) + src.slice(i);
    case 2: // replace a char
      return src.slice(0, i) + pick(RANDOM_CHARS) + src.slice(i + 1);
    case 3: // duplicate a chunk
      { const len = randInt(20); return src.slice(0, i) + src.slice(i, i + len) + src.slice(i); }
    case 4: // truncate
      return src.slice(0, i);
    case 5: // flip indentation (mess with leading whitespace on a random line)
      { const lines = src.split("\n"); const li = randInt(lines.length);
        lines[li] = " ".repeat(randInt(12)) + lines[li].trimStart();
        return lines.join("\n"); }
    default:
      return src;
  }
}

function mutate(src, count) {
  let out = src;
  for (let i = 0; i < count; i++) out = mutateOnce(out);
  return out;
}

// ── Grammar-soup fuzzing ────────────────────────────────────────────────
const TOKEN_VOCAB = [
  "let", "const", "fn", "return", "if", "elif", "else", "repeat", "times",
  "while", "break", "continue", "for", "in", "import", "true", "false",
  "and", "or", "not", "try", "catch", "finally", "throw",
  "x", "y", "n", "total", "amount", "items", "(", ")", "[", "]", "{", "}",
  ":", ",", ".", "=", "==", "!=", "<", "<=", ">", ">=", "+", "-", "*", "/",
  "$500", "₹100", "5%", '"hi"', 'f"{x}"', "42", "3.14", "\n", "    ",
];

function grammarSoup(tokenCount) {
  const parts = [];
  for (let i = 0; i < tokenCount; i++) parts.push(pick(TOKEN_VOCAB));
  return parts.join(" ");
}

// ── Run one case through the real pipeline ──────────────────────────────
// Only GlangSyntaxError / GlangRuntimeError / GlangThrownValue (a `throw`
// that reached top level, which is itself just a GlangRuntimeError in
// practice — see interpret()) count as "handled". Everything else is a
// crash worth reporting.
function classify(source) {
  try {
    const tokens = new Lexer(source).tokenize();
    const ast = new Parser(tokens).parse();
    const originalLog = console.log;
    console.log = () => {}; // silence any show() output during fuzzing
    try {
      new Interpreter().interpret(ast);
    } finally {
      console.log = originalLog;
    }
    return { kind: "ok" };
  } catch (err) {
    if (err instanceof GlangSyntaxError || err instanceof GlangRuntimeError || err instanceof GlangThrownValue) {
      return { kind: "handled" };
    }
    return { kind: "crash", err };
  }
}

// ── Run the fuzzer ───────────────────────────────────────────────────────
console.log(`\n\x1b[1mGlang fuzz tester\x1b[0m  (seed=${SEED}, iterations=${ITERATIONS})\n`);

let ok = 0, handled = 0, crashes = 0;
const crashSignatures = new Map(); // dedup by "ErrorType: message" -> {count, example}

for (let i = 0; i < ITERATIONS; i++) {
  let source;
  const strategy = randInt(3);
  if (strategy === 0) {
    // mutate a real program
    const seed = pick(seedSources);
    source = mutate(seed, 1 + randInt(8));
  } else if (strategy === 1) {
    // grammar soup
    source = grammarSoup(2 + randInt(30));
  } else {
    // pure random noise
    const len = randInt(80);
    let s = "";
    for (let j = 0; j < len; j++) s += pick(RANDOM_CHARS);
    source = s;
  }

  const result = classify(source);
  if (result.kind === "ok") ok++;
  else if (result.kind === "handled") handled++;
  else {
    crashes++;
    const sig = `${result.err.constructor.name}: ${result.err.message}`.slice(0, 120);
    if (!crashSignatures.has(sig)) {
      crashSignatures.set(sig, { count: 0, example: source });
    }
    crashSignatures.get(sig).count++;
  }
}

console.log(`  ${ok} ran clean, ${handled} produced a friendly Glang error, ${crashes} crashed\n`);

if (crashSignatures.size > 0) {
  console.log(`\x1b[31m\x1b[1m${crashSignatures.size} distinct crash signature(s):\x1b[0m\n`);
  for (const [sig, info] of crashSignatures) {
    console.log(`  \x1b[31m✗\x1b[0m ${sig}  (x${info.count})`);
    console.log(`      example input: ${JSON.stringify(info.example.slice(0, 200))}`);
  }
  console.log("");
  process.exitCode = 1;
} else {
  console.log(`\x1b[32mNo crashes found — every case was either handled cleanly or ran fine.\x1b[0m\n`);
}
