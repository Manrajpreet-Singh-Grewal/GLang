// Glang app-generation layer test suite
// Run with: node tests/run_tests_app_layer.js  (also wired into `npm test`)
//
// The core interpreter (lexer/parser/interpreter) has thorough coverage in
// run_tests.js. This file covers the layer on top of it — `glang app`,
// `glang share`, and `glang site` — which turns a .grw script into a running
// web app / static HTML / a deployable site folder. This layer was
// previously only exercised by hand, which is exactly how the earlier
// --title/--desc bug slipped through, so it gets its own suite here.

const fs   = require("fs");
const os   = require("os");
const path = require("path");

let passed = 0;
let failed = 0;
const failures = [];

function test(name, fn) {
  try {
    fn();
    passed++;
    console.log(`  \x1b[32m✓\x1b[0m ${name}`);
  } catch (err) {
    failed++;
    failures.push({ name, err });
    console.log(`  \x1b[31m✗ ${name}\x1b[0m`);
    console.log(`      ${err.stack || err.message}`);
  }
}

function assertEqual(actual, expected, label) {
  if (actual !== expected) {
    throw new Error(
      `${label ? label + ": " : ""}expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`
    );
  }
}

function assertTrue(cond, label) {
  if (!cond) throw new Error(label || "expected condition to be true");
}

function assertIncludes(haystack, needle, label) {
  if (!haystack.includes(needle)) {
    throw new Error(`${label ? label + ": " : ""}expected output to include ${JSON.stringify(needle)}`);
  }
}

// Async variant of test() for sandbox tests, which run real worker threads.
async function testAsync(name, fn) {
  try {
    await fn();
    passed++;
    console.log(`  \x1b[32m✓\x1b[0m ${name}`);
  } catch (err) {
    failed++;
    failures.push({ name, err });
    console.log(`  \x1b[31m✗ ${name}\x1b[0m`);
    console.log(`      ${err.stack || err.message}`);
  }
}

console.log("\n\x1b[1mGlang app-generation layer test suite\x1b[0m\n");

// ── glang app (runApp) ──────────────────────────────────────────────────
console.log("\x1b[1mrunApp() — in-memory app execution\x1b[0m");

const { runApp } = require("../src/app.js");

test("runApp renders a text element from show()", () => {
  const { elements } = runApp(`show("hello from an app")`, "t.grw", {});
  assertTrue(elements.some(e => e.type === "text" && e.content.includes("hello from an app")));
});

test("runApp discovers input() fields on the scan pass, even with no inputs supplied", () => {
  const src = `let amount = input("Loan Amount", "money")\nshow(amount)`;
  const { inputFields } = runApp(src, "t.grw", {});
  assertTrue(inputFields.some(f => f.key === "loan_amount" && f.type === "money"));
});

test("runApp uses a supplied input value instead of the default", () => {
  const src = `let amount = input("Loan Amount", "money", 100)\nshow(amount)`;
  const { elements } = runApp(src, "t.grw", { loan_amount: "500" });
  assertTrue(elements.some(e => e.type === "text" && e.content.includes("500")));
});

test("runApp surfaces a Glang syntax error as a friendly alert element, not a crash", () => {
  const { elements } = runApp(`let x = `, "t.grw", {});
  const alert = elements.find(e => e.type === "alert" && e.kind === "error");
  assertTrue(!!alert, "expected an error alert element");
});

test("runApp surfaces a Glang runtime error as a friendly alert element, not a crash", () => {
  const { elements } = runApp(`show(undefined_variable)`, "t.grw", {});
  const alert = elements.find(e => e.type === "alert" && e.kind === "error");
  assertTrue(!!alert && alert.msg.includes("undefined_variable"));
});

test("runApp renders card/metric/table/chart elements from their builtins", () => {
  const src = [
    'show_card("Net Worth", $1000, "up from last month")',
    'show_metric("Revenue", $500, $400)',
    'show_table(["Item", "Cost"], [["Rent", $1200]])',
    'show_chart("Sales", [1,2,3], "line")',
  ].join("\n");
  const { elements } = runApp(src, "t.grw", {});
  const types = elements.map(e => e.type);
  assertTrue(types.filter(t => t === "card").length >= 2, "expected show_card and show_metric to both render as card elements");
  assertTrue(types.includes("table"), "expected a table element");
  assertTrue(types.includes("chart"), "expected a chart element");
});

test("runApp works with Phase 1 features (elif / f-strings / const)", () => {
  const src = [
    'const RATE = 5%',
    'let age = 20',
    'let label = "adult" if age >= 18 else "minor"',
    'show(f"Label: {label}, rate: {RATE}")',
  ].join("\n");
  const { elements } = runApp(src, "t.grw", {});
  assertTrue(elements.some(e => e.type === "text" && e.content.includes("Label: adult, rate: 5%")));
});

// ── glang share (buildShareHTML) ────────────────────────────────────────
console.log("\n\x1b[1mbuildShareHTML() — standalone shareable HTML\x1b[0m");

const { _buildShareHTML } = require("../src/share.js");

test("buildShareHTML produces a full HTML document embedding the source", () => {
  const html = _buildShareHTML("My Calculator", 'show("hi")');
  assertIncludes(html, "<!DOCTYPE html>");
  assertIncludes(html, "My Calculator");
  assertIncludes(html, 'show("hi")');
});

test("buildShareHTML safely escapes backticks in the source so it doesn't break out of the template literal", () => {
  const html = _buildShareHTML("Title", 'show(`not real glang`)');
  assertTrue(!html.includes("show(`not real glang`)"), "backtick should have been escaped, not embedded raw");
});

// ── glang site (generateSite) ───────────────────────────────────────────
console.log("\n\x1b[1mgenerateSite() — full deployable site folder\x1b[0m");

const { generateSite } = require("../src/site.js");

test("generateSite writes index.html, app.html, embed.js, and README.md", () => {
  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), "glang-site-test-"));
  const scriptPath = path.join(tmpDir, "budget_planner.grw");
  fs.writeFileSync(scriptPath, 'show("hello site")', "utf8");
  const outDir = path.join(tmpDir, "out");

  generateSite(scriptPath, { out: outDir, title: "Budget Planner", desc: "A test app", author: "Test" });

  for (const f of ["index.html", "app.html", "embed.js", "README.md"]) {
    assertTrue(fs.existsSync(path.join(outDir, f)), `expected ${f} to be generated`);
  }
  const landing = fs.readFileSync(path.join(outDir, "index.html"), "utf8");
  assertIncludes(landing, "Budget Planner", "landing page should use the supplied --title, not a mangled default");
});

test("generateSite falls back to a title derived from the filename when --title is omitted", () => {
  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), "glang-site-test-"));
  const scriptPath = path.join(tmpDir, "loan_calculator.grw");
  fs.writeFileSync(scriptPath, 'show("hi")', "utf8");
  const outDir = path.join(tmpDir, "out");

  generateSite(scriptPath, { out: outDir });

  const landing = fs.readFileSync(path.join(outDir, "index.html"), "utf8");
  assertIncludes(landing, "Loan Calculator");
});

// ── glang app sandboxing (runSandboxed) — Phase 2 ───────────────────────
// These run real worker_threads, so they're async.
const { runSandboxed } = require("../src/sandbox.js");

async function runAsyncTests() {
  console.log("\n\x1b[1mrunSandboxed() — timeouts, memory caps, and isolation (Phase 2)\x1b[0m");

  await testAsync("a normal script runs fine inside the sandbox", async () => {
    const { elements } = await runSandboxed('show("hello sandbox")', "t.grw", {});
    assertTrue(elements.some(e => e.type === "text" && e.content === "hello sandbox"));
  });

  await testAsync("an infinite loop is stopped by the timeout, not left to hang forever", async () => {
    const start = Date.now();
    const { elements } = await runSandboxed("while true:\n    let x = 1", "t.grw", {}, { timeoutMs: 800 });
    const elapsed = Date.now() - start;
    assertTrue(elapsed < 5000, `expected the sandbox to stop quickly, took ${elapsed}ms`);
    assertTrue(elements.some(e => e.type === "alert" && e.kind === "error" && e.msg.includes("took longer than")));
  });

  await testAsync("a script that allocates far past the memory cap is stopped, not left to OOM the process", async () => {
    const items = Array.from({ length: 3000000 }, (_, i) => i).join(", ");
    const src = `let big = [${items}]\nshow(length(big))`;
    const { elements } = await runSandboxed(src, "t.grw", {}, { timeoutMs: 8000, memoryMb: 24 });
    assertTrue(elements.some(e => e.type === "alert" && e.kind === "error" && e.msg.includes("memory")));
  });

  await testAsync("concurrent sandboxed runs don't bleed state between each other", async () => {
    const jobs = [];
    for (let i = 0; i < 8; i++) {
      jobs.push(runSandboxed(`let n = ${i}\nshow(n)`, "t.grw", {}));
    }
    const results = await Promise.all(jobs);
    results.forEach((r, i) => {
      assertTrue(
        r.elements.some(e => e.type === "text" && e.content === String(i)),
        `expected job ${i} to see its own value of n, got ${JSON.stringify(r.elements)}`
      );
    });
  });

  await testAsync("a sandboxed script can still use try/catch/throw normally", async () => {
    const src = 'try:\n    throw "custom"\ncatch e:\n    show(f"caught: {e}")';
    const { elements } = await runSandboxed(src, "t.grw", {});
    assertTrue(elements.some(e => e.type === "text" && e.content === "caught: custom"));
  });

  // ── Summary ─────────────────────────────────────────────────────────────
  console.log(`\n\x1b[1m${passed} passed, ${failed} failed\x1b[0m out of ${passed + failed} tests\n`);

  if (failed > 0) {
    process.exitCode = 1;
  }
}

runAsyncTests();
