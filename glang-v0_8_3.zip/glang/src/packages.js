// Glang Package System — Phase 5 Part 2
// glang publish mymodule.grw   → creates a shareable package
// glang install <name or path> → installs a community package

const fs   = require("fs");
const path = require("path");

const BOLD  = "\x1b[1m";
const CYAN  = "\x1b[36m";
const GREEN = "\x1b[32m";
const RED   = "\x1b[31m";
const RESET = "\x1b[0m";
const DIM   = "\x1b[2m";

const COMMUNITY_DIR = path.join(__dirname, "../packages/community");
const STDLIB_DIR    = path.join(__dirname, "../packages/stdlib");

// ── glang publish ─────────────────────────────────────────────────────────
// Packages a .grw file into a distributable module with metadata

function publish(filePath) {
  const resolved = path.resolve(filePath);
  if (!fs.existsSync(resolved)) {
    console.error(`${RED}File not found: "${filePath}"${RESET}`);
    process.exit(1);
  }
  if (!resolved.endsWith(".grw")) {
    console.error(`${RED}Only .grw files can be published.${RESET}`);
    process.exit(1);
  }

  const source   = fs.readFileSync(resolved, "utf8");
  const filename = path.basename(resolved, ".grw");

  // Parse the module to extract exported function names
  const { Lexer }  = require("./lexer.js");
  const { Parser } = require("./parser.js");
  let exports_ = [];
  try {
    const tokens = new Lexer(source).tokenize();
    const ast    = new Parser(tokens).parse();
    exports_ = ast.body
      .filter(n => n.type === "FnDecl")
      .map(n => n.name);
  } catch (e) {
    console.error(`${RED}Parse error in module: ${e.message}${RESET}`);
    process.exit(1);
  }

  // Build package manifest
  const manifest = {
    name:        filename,
    version:     "1.0.0",
    description: `Glang module: ${filename}`,
    author:      "Grewal",
    exports:     exports_,
    created:     new Date().toISOString(),
    glang:       ">=0.5.0",
  };

  // Write the package directory in current working directory
  const outDir = path.join(process.cwd(), filename + "-pkg");
  fs.mkdirSync(outDir, { recursive: true });
  fs.writeFileSync(path.join(outDir, "index.grw"),      source,                          "utf8");
  fs.writeFileSync(path.join(outDir, "manifest.json"),  JSON.stringify(manifest, null, 2), "utf8");
  fs.writeFileSync(path.join(outDir, "README.md"),      buildModuleReadme(manifest),      "utf8");

  console.log(`\n${GREEN}✓ Package created: ${outDir}/${RESET}`);
  console.log(`\n${BOLD}Exports (${exports_.length} functions):${RESET}`);
  exports_.forEach(fn => console.log(`  ${CYAN}${fn}()${RESET}`));
  console.log(`\n${BOLD}To share this module:${RESET}`);
  console.log(`  ${DIM}Zip the ${filename}-pkg/ folder and send it to anyone${RESET}`);
  console.log(`  ${DIM}They can install it with: glang install ./${filename}-pkg/${RESET}`);
  console.log(`  ${DIM}Then use it with: import ${filename}${RESET}\n`);
}

// ── glang install ─────────────────────────────────────────────────────────
// Installs a package into the community packages directory

function install(packagePath) {
  if (!packagePath) {
    console.error("Usage: glang install <path-to-package-folder-or-grw-file>");
    process.exit(1);
  }

  const resolved = path.resolve(packagePath);

  if (!fs.existsSync(resolved)) {
    console.error(`${RED}Not found: "${packagePath}"${RESET}`);
    console.error(`\nTo install a package, provide the path to a:`);
    console.error(`  - .grw file:        glang install ./mymodule.grw`);
    console.error(`  - package folder:   glang install ./mymodule-pkg/`);
    process.exit(1);
  }

  fs.mkdirSync(COMMUNITY_DIR, { recursive: true });

  let name, source, manifest = null;

  if (resolved.endsWith(".grw")) {
    // Single .grw file install
    name   = path.basename(resolved, ".grw");
    source = fs.readFileSync(resolved, "utf8");
  } else if (fs.statSync(resolved).isDirectory()) {
    // Package folder install
    const indexPath    = path.join(resolved, "index.grw");
    const manifestPath = path.join(resolved, "manifest.json");

    if (!fs.existsSync(indexPath)) {
      console.error(`${RED}Package folder must contain index.grw${RESET}`);
      process.exit(1);
    }

    source = fs.readFileSync(indexPath, "utf8");

    if (fs.existsSync(manifestPath)) {
      manifest = JSON.parse(fs.readFileSync(manifestPath, "utf8"));
      name     = manifest.name;
    } else {
      name = path.basename(resolved).replace(/-pkg$/, "");
    }
  } else {
    console.error(`${RED}Unsupported package format. Use a .grw file or package folder.${RESET}`);
    process.exit(1);
  }

  // Validate it parses correctly before installing
  const { Lexer }  = require("./lexer.js");
  const { Parser } = require("./parser.js");
  let exports_ = [];
  try {
    const tokens = new Lexer(source).tokenize();
    const ast    = new Parser(tokens).parse();
    exports_     = ast.body.filter(n => n.type === "FnDecl").map(n => n.name);
  } catch (e) {
    console.error(`${RED}Package has syntax errors: ${e.message}${RESET}`);
    process.exit(1);
  }

  // Check for stdlib name collision
  const stdlibPath = path.join(STDLIB_DIR, name + ".grw");
  if (fs.existsSync(stdlibPath)) {
    console.error(`${RED}"${name}" is a built-in Glang module and can't be overwritten.${RESET}`);
    console.error(`Try a different name for your package.`);
    process.exit(1);
  }

  // Install it
  const destDir = path.join(COMMUNITY_DIR, name);
  fs.mkdirSync(destDir, { recursive: true });
  fs.writeFileSync(path.join(destDir, "index.grw"), source, "utf8");
  if (manifest) {
    fs.writeFileSync(path.join(destDir, "manifest.json"), JSON.stringify(manifest, null, 2), "utf8");
  } else {
    fs.writeFileSync(path.join(destDir, "manifest.json"), JSON.stringify({
      name, version: "1.0.0", exports: exports_, installed: new Date().toISOString()
    }, null, 2), "utf8");
  }

  console.log(`\n${GREEN}✓ Installed: ${name}${RESET}`);
  console.log(`  Location: ${destDir}/`);
  if (exports_.length) {
    console.log(`  Exports: ${exports_.map(f => f + "()").join(", ")}`);
  }
  console.log(`\n  Use it with: ${CYAN}import ${name}${RESET}\n`);
}

// ── glang packages ────────────────────────────────────────────────────────
// Lists all available modules (stdlib + installed community)

function listPackages() {
  console.log(`\n${BOLD}Glang Packages${RESET}\n`);

  // Stdlib
  console.log(`${BOLD}Built-in modules (always available):${RESET}`);
  const stdlibFiles = fs.existsSync(STDLIB_DIR)
    ? fs.readdirSync(STDLIB_DIR).filter(f => f.endsWith(".grw"))
    : [];
  if (stdlibFiles.length === 0) {
    console.log(`  ${DIM}(none)${RESET}`);
  } else {
    stdlibFiles.forEach(f => {
      const name   = f.replace(".grw", "");
      const source = fs.readFileSync(path.join(STDLIB_DIR, f), "utf8");
      const fns    = (source.match(/^fn (\w+)/gm) || []).map(l => l.replace("fn ", ""));
      console.log(`  ${CYAN}import ${name}${RESET}  — ${fns.length} functions: ${fns.slice(0, 4).join(", ")}${fns.length > 4 ? "..." : ""}`);
    });
  }

  // Community
  console.log(`\n${BOLD}Installed community modules:${RESET}`);
  const communityDirs = fs.existsSync(COMMUNITY_DIR)
    ? fs.readdirSync(COMMUNITY_DIR).filter(d => fs.statSync(path.join(COMMUNITY_DIR, d)).isDirectory())
    : [];
  if (communityDirs.length === 0) {
    console.log(`  ${DIM}(none installed yet)${RESET}`);
    console.log(`  ${DIM}Install with: glang install <path-to-package>${RESET}`);
  } else {
    communityDirs.forEach(d => {
      const manifestPath = path.join(COMMUNITY_DIR, d, "manifest.json");
      if (fs.existsSync(manifestPath)) {
        const m = JSON.parse(fs.readFileSync(manifestPath, "utf8"));
        console.log(`  ${CYAN}import ${m.name}${RESET}  v${m.version || "?"} — ${(m.exports || []).length} functions`);
      } else {
        console.log(`  ${CYAN}import ${d}${RESET}`);
      }
    });
  }
  console.log("");
}

// ── helpers ───────────────────────────────────────────────────────────────
function buildModuleReadme(manifest) {
  const fnList = manifest.exports.map(f => `- \`${f}()\``).join("\n");
  return `# ${manifest.name}

> Glang module — ${manifest.description}

## Install

\`\`\`bash
glang install ./${manifest.name}-pkg/
\`\`\`

## Usage

\`\`\`
import ${manifest.name}
\`\`\`

## Functions

${fnList || "(none exported)"}

---
*Built with [Glang](https://github.com/grewal/glang) v${manifest.glang || "0.5.0"}*
`;
}

module.exports = { publish, install, listPackages };
