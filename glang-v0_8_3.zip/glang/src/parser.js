// Glang Parser
// Turns the token stream from the lexer into an AST (Abstract Syntax Tree).
// Uses recursive descent with standard precedence climbing for expressions.
//
// Precedence (low to high):
//   or
//   and
//   not
//   == != < <= > >=
//   + -
//   * /
//   unary (-x)
//   call / primary

const { TokenType, GlangSyntaxError } = require("./lexer.js");

// --- AST Node constructors -------------------------------------------------
// Plain objects with a `type` discriminator. Keeps things simple and easy
// for the interpreter to pattern-match on (via switch statements).

const Node = {
  Program: (body) => ({ type: "Program", body }),
  Let: (name, value, line) => ({ type: "Let", name, value, line }),
  Const: (name, value, line) => ({ type: "Const", name, value, line }),
  Assign: (name, value, line) => ({ type: "Assign", name, value, line }),
  IndexAssign: (object, index, value, line) => ({ type: "IndexAssign", object, index, value, line }),
  PropertyAssign: (object, property, value, line) => ({ type: "PropertyAssign", object, property, value, line }),
  FnDecl: (name, params, body, line) => ({ type: "FnDecl", name, params, body, line }),
  Return: (value, line) => ({ type: "Return", value, line }),
  If: (condition, thenBranch, elseBranch, line) => ({ type: "If", condition, thenBranch, elseBranch, line }),
  Repeat: (count, body, line) => ({ type: "Repeat", count, body, line }),
  While: (condition, body, line) => ({ type: "While", condition, body, line }),
  Break: (line) => ({ type: "Break", line }),
  Continue: (line) => ({ type: "Continue", line }),
  ForIn: (varName, iterable, body, line) => ({ type: "ForIn", varName, iterable, body, line }),
  Try: (tryBlock, catchVar, catchBlock, finallyBlock, line) => ({ type: "Try", tryBlock, catchVar, catchBlock, finallyBlock, line }),
  Throw: (value, line) => ({ type: "Throw", value, line }),
  Import: (module, alias, line) => ({ type: "Import", module, alias, line }),
  ExprStatement: (expr) => ({ type: "ExprStatement", expr }),

  Binary: (left, op, right, line) => ({ type: "Binary", left, op, right, line }),
  Ternary: (condition, thenExpr, elseExpr, line) => ({ type: "Ternary", condition, thenExpr, elseExpr, line }),
  Interpolation: (parts, line) => ({ type: "Interpolation", parts, line }),
  Unary: (op, right, line) => ({ type: "Unary", op, right, line }),
  Logical: (left, op, right, line) => ({ type: "Logical", left, op, right, line }),
  Call: (callee, args, line) => ({ type: "Call", callee, args, line }),
  Variable: (name, line) => ({ type: "Variable", name, line }),
  ListLit: (elements, line) => ({ type: "ListLit", elements, line }),
  DictLit: (pairs, line) => ({ type: "DictLit", pairs, line }),
  ListComp: (expr, varName, iterable, condition, line) => ({ type: "ListComp", expr, varName, iterable, condition, line }),
  DictComp: (keyExpr, valueExpr, varName, iterable, condition, line) => ({ type: "DictComp", keyExpr, valueExpr, varName, iterable, condition, line }),
  Index: (object, index, line) => ({ type: "Index", object, index, line }),

  NumberLit: (value) => ({ type: "NumberLit", value }),
  StringLit: (value) => ({ type: "StringLit", value }),
  BoolLit: (value) => ({ type: "BoolLit", value }),
  CurrencyLit: (amount, currency) => ({ type: "CurrencyLit", amount, currency }),
  PercentLit: (value) => ({ type: "PercentLit", value }),
};

// How deep expression parsing (nested parens, brackets, ternaries, etc.)
// is allowed to recurse before we give up with a friendly error. Kept
// well below Node's real stack limit — found by fuzz testing that code
// like `((((((...1...))))))` thousands of parens deep otherwise blows
// the real JS call stack and leaks a raw "Maximum call stack size
// exceeded" RangeError instead of a normal Glang syntax error.
const MAX_EXPR_DEPTH = 300;

class Parser {
  constructor(tokens) {
    this.tokens = tokens;
    this.pos = 0;
    this.exprDepth = 0;
  }

  // --- Helpers ---------------------------------------------------------

  peek(offset = 0) {
    return this.tokens[this.pos + offset];
  }

  previous() {
    return this.tokens[this.pos - 1];
  }

  isAtEnd() {
    return this.peek().type === TokenType.EOF;
  }

  check(type) {
    if (this.isAtEnd()) return type === TokenType.EOF;
    return this.peek().type === type;
  }

  advance() {
    if (!this.isAtEnd()) this.pos++;
    return this.previous();
  }

  match(...types) {
    for (const type of types) {
      if (this.check(type)) {
        this.advance();
        return true;
      }
    }
    return false;
  }

  expect(type, message, hint) {
    if (this.check(type)) return this.advance();
    const tok = this.peek();
    throw new GlangSyntaxError(message, tok.line, hint);
  }

  // Skips any number of blank NEWLINE tokens (e.g. between statements)
  skipNewlines() {
    while (this.match(TokenType.NEWLINE)) {}
  }

  // --- Entry point -------------------------------------------------------

  parse() {
    const body = [];
    this.skipNewlines();
    while (!this.isAtEnd()) {
      body.push(this.statement());
      this.skipNewlines();
    }
    return Node.Program(body);
  }

  // --- Statements ----------------------------------------------------------

  statement() {
    if (this.check(TokenType.INDENT)) {
      const tok = this.peek();
      throw new GlangSyntaxError(
        "This line is indented more than expected.",
        tok.line,
        "Indentation in Glang should only increase right after a line ending in ':' (like after 'fn', 'if', or 'repeat'). Check that this line's spacing matches the line above it."
      );
    }
    if (this.check(TokenType.IMPORT)) return this.importStatement();
    if (this.check(TokenType.LET)) return this.letStatement();
    if (this.check(TokenType.CONST)) return this.constStatement();
    if (this.check(TokenType.FN)) return this.fnDeclaration();
    if (this.check(TokenType.RETURN)) return this.returnStatement();
    if (this.check(TokenType.IF)) return this.ifStatement();
    if (this.check(TokenType.REPEAT)) return this.repeatStatement();
    if (this.check(TokenType.WHILE)) return this.whileStatement();
    if (this.check(TokenType.BREAK)) return this.breakStatement();
    if (this.check(TokenType.CONTINUE)) return this.continueStatement();
    if (this.check(TokenType.FOR)) return this.forInStatement();
    if (this.check(TokenType.TRY)) return this.tryStatement();
    if (this.check(TokenType.THROW)) return this.throwStatement();

    // Assignment (x = 5) or plain expression statement (show("hi"))
    return this.expressionOrAssignment();
  }

  importStatement() {
    const line = this.peek().line;
    this.advance(); // consume 'import'

    // import finance
    // import tax as t
    // import "path/to/module.grw"
    // import "path/to/module.grw" as mymod
    let moduleName;
    let alias = null;

    if (this.check(TokenType.STRING)) {
      // import "path/to/file.grw"
      moduleName = this.advance().value;
    } else if (this.check(TokenType.IDENTIFIER)) {
      // import finance   OR   import finance as fin
      moduleName = this.advance().value;
    } else {
      throw new GlangSyntaxError(
        "Expected a module name after 'import'.",
        this.peek().line,
        "Examples: import finance   or   import tax   or   import \"./mymodule.grw\""
      );
    }

    // Optional: as alias
    if (this.check(TokenType.IDENTIFIER) && this.peek().value === "as") {
      this.advance(); // consume 'as'
      const aliasTok = this.expect(
        TokenType.IDENTIFIER,
        "Expected an alias name after 'as'.",
        "Example: import finance as fin"
      );
      alias = aliasTok.value;
    }

    this.endStatement();
    return Node.Import(moduleName, alias, line);
  }

  letStatement() {
    const line = this.peek().line;
    this.advance(); // consume 'let'
    const nameTok = this.expect(
      TokenType.IDENTIFIER,
      "Expected a variable name after 'let'.",
      "For example: let balance = $500"
    );
    this.expect(
      TokenType.EQUAL,
      `Expected '=' after the variable name "${nameTok.value}".`,
      `Every 'let' needs a value, like: let ${nameTok.value} = 5`
    );
    const value = this.expression();
    this.endStatement();
    return Node.Let(nameTok.value, value, line);
  }

  constStatement() {
    const line = this.peek().line;
    this.advance(); // consume 'const'
    const nameTok = this.expect(
      TokenType.IDENTIFIER,
      "Expected a constant name after 'const'.",
      "For example: const TAX_RATE = 8%"
    );
    this.expect(
      TokenType.EQUAL,
      `Expected '=' after the constant name "${nameTok.value}".`,
      `Every 'const' needs a value, like: const ${nameTok.value} = 5`
    );
    const value = this.expression();
    this.endStatement();
    return Node.Const(nameTok.value, value, line);
  }

  fnDeclaration() {
    const line = this.peek().line;
    this.advance(); // consume 'fn'
    const nameTok = this.expect(
      TokenType.IDENTIFIER,
      "Expected a function name after 'fn'.",
      "For example: fn greet():"
    );
    this.expect(
      TokenType.LPAREN,
      `Expected '(' after the function name "${nameTok.value}".`,
      `Try: fn ${nameTok.value}():`
    );

    const params = [];
    let seenDefault = false;
    if (!this.check(TokenType.RPAREN)) {
      do {
        const paramTok = this.expect(
          TokenType.IDENTIFIER,
          "Expected a parameter name.",
          "Parameters go inside the parentheses, separated by commas, like: fn add(a, b)"
        );
        let defaultExpr = null;
        if (this.match(TokenType.EQUAL)) {
          defaultExpr = this.expression();
          seenDefault = true;
        } else if (seenDefault) {
          throw new GlangSyntaxError(
            `Parameter "${paramTok.value}" is missing a default value.`,
            paramTok.line,
            `Once one parameter has a default (like "greeting = \"Hello\""), every parameter after it needs one too. Try: fn ${nameTok.value}(..., ${paramTok.value} = <default value>)`
          );
        }
        params.push({ name: paramTok.value, default: defaultExpr });
      } while (this.match(TokenType.COMMA));
    }

    this.expect(
      TokenType.RPAREN,
      "Expected ')' to close the parameter list.",
      null
    );
    this.expect(
      TokenType.COLON,
      `Expected ':' after the function signature.`,
      `Functions need a colon before their body, like: fn ${nameTok.value}():`
    );

    const body = this.block();
    return Node.FnDecl(nameTok.value, params, body, line);
  }

  returnStatement() {
    const line = this.peek().line;
    this.advance(); // consume 'return'
    let value = null;
    if (!this.check(TokenType.NEWLINE) && !this.isAtEnd()) {
      value = this.expression();
    }
    this.endStatement();
    return Node.Return(value, line);
  }

  ifStatement() {
    const line = this.peek().line;
    this.advance(); // consume 'if'
    const condition = this.expression();
    this.expect(
      TokenType.COLON,
      "Expected ':' after the if condition.",
      "For example: if age > 18:"
    );
    const thenBranch = this.block();

    let elseBranch = null;
    const checkpoint = this.pos;
    this.skipNewlines();
    if (this.check(TokenType.ELIF)) {
      // 'elif' is sugar for 'else:' containing a single nested 'if' —
      // parse it as one and wrap it as the else branch.
      const nestedIf = this.elifChain();
      elseBranch = [nestedIf];
    } else if (this.check(TokenType.ELSE)) {
      this.advance();
      this.expect(
        TokenType.COLON,
        "Expected ':' after 'else'.",
        "For example: else:"
      );
      elseBranch = this.block();
    } else {
      this.pos = checkpoint;
    }

    return Node.If(condition, thenBranch, elseBranch, line);
  }

  // Parses 'elif <cond>: <block>' (and any further chained elif/else),
  // producing the same shape as a fresh 'if' statement.
  elifChain() {
    const line = this.peek().line;
    this.advance(); // consume 'elif'
    const condition = this.expression();
    this.expect(
      TokenType.COLON,
      "Expected ':' after the elif condition.",
      "For example: elif age >= 13:"
    );
    const thenBranch = this.block();

    let elseBranch = null;
    const checkpoint = this.pos;
    this.skipNewlines();
    if (this.check(TokenType.ELIF)) {
      elseBranch = [this.elifChain()];
    } else if (this.check(TokenType.ELSE)) {
      this.advance();
      this.expect(
        TokenType.COLON,
        "Expected ':' after 'else'.",
        "For example: else:"
      );
      elseBranch = this.block();
    } else {
      this.pos = checkpoint;
    }

    return Node.If(condition, thenBranch, elseBranch, line);
  }

  repeatStatement() {
    const line = this.peek().line;
    this.advance(); // consume 'repeat'
    const count = this.expression();
    this.expect(
      TokenType.TIMES,
      "Expected 'times' after the repeat count.",
      "For example: repeat 5 times:"
    );
    this.expect(
      TokenType.COLON,
      "Expected ':' after 'repeat N times'.",
      "For example: repeat 5 times:"
    );
    const body = this.block();
    return Node.Repeat(count, body, line);
  }

  whileStatement() {
    const line = this.peek().line;
    this.advance(); // consume 'while'
    const condition = this.expression();
    this.expect(
      TokenType.COLON,
      "Expected ':' after the while condition.",
      "For example: while balance > $0:"
    );
    const body = this.block();
    return Node.While(condition, body, line);
  }

  breakStatement() {
    const line = this.peek().line;
    this.advance(); // consume 'break'
    this.endStatement();
    return Node.Break(line);
  }

  continueStatement() {
    const line = this.peek().line;
    this.advance(); // consume 'continue'
    this.endStatement();
    return Node.Continue(line);
  }

  forInStatement() {
    const line = this.peek().line;
    this.advance(); // consume 'for'
    const nameTok = this.expect(
      TokenType.IDENTIFIER,
      "Expected a variable name after 'for'.",
      "For example: for item in expenses:"
    );
    this.expect(
      TokenType.IN,
      `Expected 'in' after "${nameTok.value}".`,
      `For example: for ${nameTok.value} in expenses:`
    );
    const iterable = this.expression();
    this.expect(
      TokenType.COLON,
      "Expected ':' after the list to loop over.",
      "For example: for item in expenses:"
    );
    const body = this.block();
    return Node.ForIn(nameTok.value, iterable, body, line);
  }

  tryStatement() {
    const line = this.peek().line;
    this.advance(); // consume 'try'
    this.expect(
      TokenType.COLON,
      "Expected ':' after 'try'.",
      "For example: try:"
    );
    const tryBlock = this.block();

    let catchVar = null;
    let catchBlock = null;
    let finallyBlock = null;

    let checkpoint = this.pos;
    this.skipNewlines();
    if (this.check(TokenType.CATCH)) {
      this.advance();
      if (this.check(TokenType.IDENTIFIER)) {
        catchVar = this.advance().value;
      }
      this.expect(
        TokenType.COLON,
        "Expected ':' after 'catch'.",
        "For example: catch err:  (or just: catch: if you don't need the error value)"
      );
      catchBlock = this.block();
    } else {
      this.pos = checkpoint;
    }

    checkpoint = this.pos;
    this.skipNewlines();
    if (this.check(TokenType.FINALLY)) {
      this.advance();
      this.expect(
        TokenType.COLON,
        "Expected ':' after 'finally'.",
        "For example: finally:"
      );
      finallyBlock = this.block();
    } else {
      this.pos = checkpoint;
    }

    if (!catchBlock && !finallyBlock) {
      throw new GlangSyntaxError(
        "A 'try' block needs a 'catch' and/or a 'finally' after it.",
        line,
        "For example:\ntry:\n    risky_thing()\ncatch err:\n    show(\"Something went wrong: \" + err.message)"
      );
    }

    return Node.Try(tryBlock, catchVar, catchBlock, finallyBlock, line);
  }

  throwStatement() {
    const line = this.peek().line;
    this.advance(); // consume 'throw'
    const value = this.expression();
    this.endStatement();
    return Node.Throw(value, line);
  }

  // Parses an indented block: NEWLINE INDENT statement* DEDENT
  block() {
    this.expect(
      TokenType.NEWLINE,
      "Expected a new line after ':'.",
      "The body of this block should start on the next line, indented."
    );
    this.expect(
      TokenType.INDENT,
      "Expected an indented block here.",
      "After a ':', the next line needs to be indented (e.g. 4 spaces) to show what's inside this block."
    );
    const statements = [];
    while (!this.check(TokenType.DEDENT) && !this.isAtEnd()) {
      this.skipNewlines();
      if (this.check(TokenType.DEDENT) || this.isAtEnd()) break;
      statements.push(this.statement());
      this.skipNewlines();
    }
    this.expect(
      TokenType.DEDENT,
      "Expected this block to end (indentation should decrease back).",
      null
    );
    return statements;
  }

  // Disambiguates `name = value` (assignment) from a plain expression
  // statement like `show("hi")` or `x + 1`.
  expressionOrAssignment() {
    const line = this.peek().line;
    const expr = this.expression();

    if (this.match(TokenType.EQUAL)) {
      if (expr.type === "Index") {
        const value = this.expression();
        this.endStatement();
        return Node.IndexAssign(expr.object, expr.index, value, line);
      }
      if (expr.type === "PropertyAccess") {
        const value = this.expression();
        this.endStatement();
        return Node.PropertyAssign(expr.object, expr.property, value, line);
      }
      if (expr.type !== "Variable") {
        const tok = this.previous();
        throw new GlangSyntaxError(
          "The left side of '=' must be a variable, list index, or dictionary key.",
          tok.line,
          "If you're trying to create a new variable, use 'let', e.g. let x = 5"
        );
      }
      const value = this.expression();
      this.endStatement();
      return Node.Assign(expr.name, value, line);
    }

    this.endStatement();
    return Node.ExprStatement(expr);
  }

  // Statements end at a NEWLINE, EOF, or DEDENT (e.g. last line in a block).
  endStatement() {
    if (this.check(TokenType.NEWLINE)) {
      this.advance();
      return;
    }
    if (this.isAtEnd() || this.check(TokenType.DEDENT)) return;
    const tok = this.peek();
    throw new GlangSyntaxError(
      `Unexpected ${this.describeToken(tok)} here — did you mean to end the line before this?`,
      tok.line,
      "Each statement in Glang should be on its own line."
    );
  }

  describeToken(tok) {
    if (tok.type === TokenType.EOF) return "end of file";
    if (tok.type === TokenType.NEWLINE) return "the end of the line";
    if (tok.type === TokenType.INDENT) return "extra indentation";
    if (tok.type === TokenType.DEDENT) return "a decrease in indentation";
    return `"${tok.value}"`;
  }

  // --- Expressions (precedence climbing) ----------------------------------

  expression() {
    this.exprDepth++;
    if (this.exprDepth > MAX_EXPR_DEPTH) {
      const tok = this.peek();
      this.exprDepth--;
      throw new GlangSyntaxError(
        `This expression is nested too deeply (over ${MAX_EXPR_DEPTH} levels of (), [], or nested conditions).`,
        tok.line,
        "This is almost always a mistake — like extra unmatched parentheses — rather than something you meant to write. Check for a stray '(' or '[' with no matching close nearby."
      );
    }
    try {
      return this.ternaryExpr();
    } finally {
      this.exprDepth--;
    }
  }

  // Ternary/inline conditional: `<expr> if <cond> else <expr>`
  // Right-associative, and sits just above 'or' in precedence so it can
  // wrap a full boolean expression on either side.
  ternaryExpr() {
    const expr = this.orExpr();
    if (this.check(TokenType.IF)) {
      const line = this.peek().line;
      this.advance(); // consume 'if'
      const condition = this.orExpr();
      this.expect(
        TokenType.ELSE,
        "Expected 'else' to complete this inline if/else.",
        "For example: \"adult\" if age >= 18 else \"minor\""
      );
      const elseExpr = this.ternaryExpr();
      return Node.Ternary(condition, expr, elseExpr, line);
    }
    return expr;
  }

  orExpr() {
    let expr = this.andExpr();
    while (this.match(TokenType.OR)) {
      const line = this.previous().line;
      const right = this.andExpr();
      expr = Node.Logical(expr, "or", right, line);
    }
    return expr;
  }

  andExpr() {
    let expr = this.notExpr();
    while (this.match(TokenType.AND)) {
      const line = this.previous().line;
      const right = this.notExpr();
      expr = Node.Logical(expr, "and", right, line);
    }
    return expr;
  }

  notExpr() {
    if (this.match(TokenType.NOT)) {
      const line = this.previous().line;
      const right = this.notExpr();
      return Node.Unary("not", right, line);
    }
    return this.equality();
  }

  equality() {
    let expr = this.comparison();
    while (this.match(TokenType.EQUAL_EQUAL, TokenType.NOT_EQUAL)) {
      const op = this.previous();
      const right = this.comparison();
      expr = Node.Binary(expr, op.value, right, op.line);
    }
    return expr;
  }

  comparison() {
    let expr = this.additive();
    while (
      this.match(
        TokenType.LESS,
        TokenType.LESS_EQUAL,
        TokenType.GREATER,
        TokenType.GREATER_EQUAL
      )
    ) {
      const op = this.previous();
      const right = this.additive();
      expr = Node.Binary(expr, op.value, right, op.line);
    }
    return expr;
  }

  additive() {
    let expr = this.multiplicative();
    while (this.match(TokenType.PLUS, TokenType.MINUS)) {
      const op = this.previous();
      const right = this.multiplicative();
      expr = Node.Binary(expr, op.value, right, op.line);
    }
    return expr;
  }

  multiplicative() {
    let expr = this.unary();
    while (this.match(TokenType.STAR, TokenType.SLASH)) {
      const op = this.previous();
      const right = this.unary();
      expr = Node.Binary(expr, op.value, right, op.line);
    }
    return expr;
  }

  unary() {
    if (this.match(TokenType.MINUS)) {
      const line = this.previous().line;
      const right = this.unary();
      return Node.Unary("-", right, line);
    }
    return this.call();
  }

  call() {
    let expr = this.primary();
    while (true) {
      if (this.match(TokenType.LPAREN)) {
        expr = this.finishCall(expr);
      } else if (this.match(TokenType.LBRACKET)) {
        expr = this.finishIndex(expr);
      } else if (this.match(TokenType.DOT)) {
        const propTok = this.expect(
          TokenType.IDENTIFIER,
          "Expected a property name after '.'.",
          "For example: my_stock.price or my_stock.pe"
        );
        expr = { type: "PropertyAccess", object: expr, property: propTok.value, line: propTok.line };
      } else {
        break;
      }
    }
    return expr;
  }

  // Parses the shared tail of a list/dict comprehension:
  // `for var in iterable (if condition)`. Assumes the current token is
  // 'for'.
  parseCompClause() {
    this.advance(); // consume 'for'
    const varTok = this.expect(
      TokenType.IDENTIFIER,
      "Expected a variable name after 'for' in this comprehension.",
      "For example: [x * 2 for x in numbers]"
    );
    this.expect(
      TokenType.IN,
      `Expected 'in' after "${varTok.value}" in this comprehension.`,
      `For example: [x * 2 for ${varTok.value} in numbers]`
    );
    // Parsed with orExpr() rather than the full expression() so a
    // trailing 'if' here is read as the comprehension's own filter
    // clause, not swallowed as a ternary `x if cond else y` on the
    // iterable itself. Wrap the iterable in parentheses if you genuinely
    // need a ternary there, e.g. for x in (a if cond else b):
    const iterable = this.orExpr();
    let condition = null;
    if (this.check(TokenType.IF)) {
      this.advance();
      condition = this.expression();
    }
    return { varName: varTok.value, iterable, condition };
  }

  finishIndex(object) {
    const line = this.previous().line;
    const index = this.expression();
    this.expect(
      TokenType.RBRACKET,
      "Expected ']' to close this index.",
      "Every '[' needs a matching ']', like: my_list[0]"
    );
    return Node.Index(object, index, line);
  }

  finishCall(callee) {
    const line = this.previous().line;
    const args = [];
    if (!this.check(TokenType.RPAREN)) {
      do {
        // Named argument: `name = value` — only when the identifier is
        // immediately followed by a single '=' (not '=='), so plain
        // expressions like `a == b` or a bareword variable aren't
        // mistaken for one.
        if (this.check(TokenType.IDENTIFIER) && this.peek(1) && this.peek(1).type === TokenType.EQUAL) {
          const nameTok = this.advance(); // consume the parameter name
          this.advance(); // consume '='
          const value = this.expression();
          args.push({ name: nameTok.value, value, line: nameTok.line });
        } else {
          const argLine = this.peek().line;
          const value = this.expression();
          args.push({ name: null, value, line: argLine });
        }
      } while (this.match(TokenType.COMMA));
    }
    this.expect(
      TokenType.RPAREN,
      "Expected ')' to close the argument list.",
      null
    );
    return Node.Call(callee, args, line);
  }

  // Splits an f-string's raw text into literal chunks and `{expr}`
  // expression chunks, parsing each expression with its own mini
  // lexer/parser pass. `{{` and `}}` escape to literal `{` and `}`.
  parseInterpolation(raw, line) {
    // Lazy require to avoid a circular dependency at module-load time
    // (lexer.js <- parser.js, and parser.js needs itself here for
    // sub-expressions inside f-strings).
    const { Lexer } = require("./lexer.js");

    const parts = [];
    let literal = "";
    let i = 0;

    const flushLiteral = () => {
      if (literal.length > 0) {
        parts.push({ kind: "str", value: literal });
        literal = "";
      }
    };

    while (i < raw.length) {
      const ch = raw[i];
      if (ch === "{" && raw[i + 1] === "{") {
        literal += "{";
        i += 2;
        continue;
      }
      if (ch === "}" && raw[i + 1] === "}") {
        literal += "}";
        i += 2;
        continue;
      }
      if (ch === "{") {
        flushLiteral();
        let depth = 1;
        let exprSrc = "";
        i++; // consume '{'
        while (i < raw.length && depth > 0) {
          if (raw[i] === "{") depth++;
          if (raw[i] === "}") {
            depth--;
            if (depth === 0) break;
          }
          exprSrc += raw[i];
          i++;
        }
        if (depth !== 0) {
          throw new GlangSyntaxError(
            `This interpolated text has a "{" that's never closed with "}".`,
            line,
            `Make sure every "{" inside an f-string has a matching "}", like f"Total: {amount}".`
          );
        }
        i++; // consume '}'
        if (exprSrc.trim().length === 0) {
          throw new GlangSyntaxError(
            `Found an empty "{}" inside interpolated text.`,
            line,
            `Put an expression inside, like f"Total: {amount}", or use "{{" and "}}" for literal braces.`
          );
        }
        const subTokens = new Lexer(exprSrc).tokenize();
        const subParser = new Parser(subTokens);
        const exprNode = subParser.expression();
        parts.push({ kind: "expr", value: exprNode });
        continue;
      }
      if (ch === "}") {
        throw new GlangSyntaxError(
          `Found a "}" inside interpolated text with no matching "{".`,
          line,
          `Use "}}" if you want a literal "}".`
        );
      }
      literal += ch;
      i++;
    }
    flushLiteral();

    return Node.Interpolation(parts, line);
  }

  primary() {
    const tok = this.peek();

    if (this.match(TokenType.NUMBER)) {
      return Node.NumberLit(this.previous().value);
    }
    if (this.match(TokenType.STRING)) {
      return Node.StringLit(this.previous().value);
    }
    if (this.match(TokenType.FSTRING)) {
      const tok = this.previous();
      return this.parseInterpolation(tok.value, tok.line);
    }
    if (this.match(TokenType.CURRENCY)) {
      const v = this.previous().value;
      return Node.CurrencyLit(v.amount, v.currency);
    }
    if (this.match(TokenType.PERCENT)) {
      return Node.PercentLit(this.previous().value);
    }
    if (this.match(TokenType.TRUE)) {
      return Node.BoolLit(true);
    }
    if (this.match(TokenType.FALSE)) {
      return Node.BoolLit(false);
    }
    if (this.match(TokenType.IDENTIFIER)) {
      return Node.Variable(this.previous().value, this.previous().line);
    }
    if (this.match(TokenType.LPAREN)) {
      const expr = this.expression();
      this.expect(
        TokenType.RPAREN,
        "Expected ')' to close this group.",
        "Every '(' needs a matching ')'."
      );
      return expr;
    }
    if (this.match(TokenType.LBRACKET)) {
      const startLine = this.previous().line;
      const elements = [];
      if (!this.check(TokenType.RBRACKET)) {
        const first = this.expression();
        if (this.check(TokenType.FOR)) {
          // List comprehension: [expr for var in iterable (if condition)]
          const { varName, iterable, condition } = this.parseCompClause();
          this.expect(
            TokenType.RBRACKET,
            "Expected ']' to close this list comprehension.",
            "For example: [x * 2 for x in numbers]"
          );
          return Node.ListComp(first, varName, iterable, condition, startLine);
        }
        elements.push(first);
        while (this.match(TokenType.COMMA)) {
          elements.push(this.expression());
        }
      }
      this.expect(
        TokenType.RBRACKET,
        "Expected ']' to close this list.",
        "Every '[' needs a matching ']', like: [1, 2, 3]"
      );
      return Node.ListLit(elements, startLine);
    }
    if (this.match(TokenType.LBRACE)) {
      const startLine = this.previous().line;
      const pairs = [];
      if (!this.check(TokenType.RBRACE)) {
        // Try a dict comprehension first: `key_expr: value_expr for var in iterable`.
        // Unlike a normal dict entry, the key here is a real expression
        // (often the loop variable itself), not the bareword-key sugar
        // below — so we speculatively parse it as a full expression and
        // roll back if it turns out to just be a normal dict literal.
        const checkpoint = this.pos;
        let comp = null;
        try {
          const keyExpr = this.expression();
          if (this.check(TokenType.COLON)) {
            this.advance();
            const valueExpr = this.expression();
            if (this.check(TokenType.FOR)) {
              const { varName, iterable, condition } = this.parseCompClause();
              comp = Node.DictComp(keyExpr, valueExpr, varName, iterable, condition, startLine);
            }
          }
        } catch (e) {
          // Not a valid comprehension attempt — fall through and parse
          // this as a normal dictionary literal instead.
        }
        if (comp) {
          this.expect(
            TokenType.RBRACE,
            "Expected '}' to close this dictionary comprehension.",
            "For example: {n: n * n for n in numbers}"
          );
          return comp;
        }
        this.pos = checkpoint;

        do {
          // Blank lines are allowed between entries since {} suppresses NEWLINE
          if (this.check(TokenType.RBRACE)) break;
          let key;
          if (this.check(TokenType.STRING)) {
            key = this.advance().value;
          } else if (this.check(TokenType.IDENTIFIER)) {
            // Bareword key sugar: {name: "Alex"} same as {"name": "Alex"}
            key = this.advance().value;
          } else {
            const tok = this.peek();
            throw new GlangSyntaxError(
              `Expected a key here (a word or "text in quotes").`,
              tok.line,
              `Dictionary keys look like: {name: "Alex", age: 30}`
            );
          }
          this.expect(
            TokenType.COLON,
            `Expected ':' after the key "${key}".`,
            `Dictionary entries look like: ${key}: value`
          );
          const value = this.expression();
          pairs.push({ key, value });
        } while (this.match(TokenType.COMMA));
      }
      this.expect(
        TokenType.RBRACE,
        "Expected '}' to close this dictionary.",
        "Every '{' needs a matching '}', like: {name: \"Alex\", age: 30}"
      );
      return Node.DictLit(pairs, startLine);
    }

    throw new GlangSyntaxError(
      `Didn't expect ${this.describeToken(tok)} here.`,
      tok.line,
      "Check for a missing value, or an extra symbol nearby."
    );
  }
}

module.exports = { Parser, Node };
