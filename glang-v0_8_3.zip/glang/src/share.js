// Glang Share — Phase 5 Part 1
// glang share myapp.grw → generates myapp.html
// Uses the REAL Glang interpreter (browserified) so behaviour is
// identical between glang run, glang app, and the shared HTML file.

const fs   = require("fs");
const path = require("path");

function buildShareHTML(appTitle, glangSource) {
  // Load the pre-built browser bundle (real interpreter)
  const bundlePath = path.join(__dirname, "browser-bundle.js");
  if (!fs.existsSync(bundlePath)) {
    throw new Error(
      "Browser bundle not found. Run: npm run build-browser\n" +
      "(or: ./node_modules/.bin/browserify src/browser-glang.js -o src/browser-bundle.js --standalone GlangRuntime)"
    );
  }
  const bundle = fs.readFileSync(bundlePath, "utf8");

  // Safely escape the .grw source for embedding in a JS template literal
  const escaped = glangSource
    .replace(/\\/g, "\\\\")
    .replace(/`/g, "\\`")
    .replace(/\$/g, "\\$");

  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>${appTitle} — Glang</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<style>
  :root{
    --bg:#0f1117;--surface:#1a1d2e;--surface2:#242740;
    --accent:#6c63ff;--accent2:#00d4aa;--text:#e8eaf0;
    --text2:#9ca3b0;--border:#2d3150;--red:#ff6b6b;--green:#51cf66;
  }
  *{box-sizing:border-box;margin:0;padding:0;}
  body{background:var(--bg);color:var(--text);font-family:'Segoe UI',system-ui,sans-serif;min-height:100vh;}

  /* Header */
  .header{background:linear-gradient(135deg,#1a1d2e,#242740);border-bottom:1px solid var(--border);padding:16px 32px;display:flex;align-items:center;gap:12px;}
  .logo{font-size:20px;font-weight:700;color:var(--accent);letter-spacing:-0.5px;}
  .app-title{font-size:18px;font-weight:600;color:var(--text);}
  .badge{background:var(--accent);color:white;font-size:10px;font-weight:700;padding:2px 8px;border-radius:10px;text-transform:uppercase;}
  .share-badge{margin-left:auto;background:var(--accent2);color:#0f1117;font-size:10px;font-weight:700;padding:2px 8px;border-radius:10px;}

  /* Layout */
  .layout{display:grid;grid-template-columns:290px 1fr;min-height:calc(100vh - 57px);}
  .sidebar{background:var(--surface);border-right:1px solid var(--border);padding:24px 20px;overflow-y:auto;}
  .sidebar h3{font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:var(--text2);margin-bottom:16px;}
  .main{padding:28px 32px;overflow-y:auto;}

  /* Form */
  .field{margin-bottom:16px;}
  .field label{display:block;font-size:13px;font-weight:500;color:var(--text2);margin-bottom:6px;}
  .field input,.field select{
    width:100%;background:var(--surface2);border:1px solid var(--border);
    border-radius:8px;padding:10px 12px;color:var(--text);font-size:14px;
    transition:border-color .2s;
  }
  .field input:focus,.field select:focus{outline:none;border-color:var(--accent);}
  .run-btn{
    width:100%;background:linear-gradient(135deg,var(--accent),#8b5cf6);
    color:white;border:none;border-radius:8px;padding:12px;font-size:14px;
    font-weight:600;cursor:pointer;transition:opacity .2s;margin-top:8px;
  }
  .run-btn:hover{opacity:.9;}
  .run-btn:disabled{opacity:.5;cursor:not-allowed;}
  .no-inputs{text-align:center;color:var(--text2);font-size:13px;padding:16px 0;}
  .powered{font-size:11px;color:var(--text2);margin-top:24px;text-align:center;}
  .powered span{color:var(--accent);font-weight:600;}

  /* UI Elements */
  .cards-row{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:16px;margin-bottom:20px;}
  .card{background:var(--surface);border:1px solid var(--border);border-radius:12px;padding:20px;}
  .card-title{font-size:12px;font-weight:600;text-transform:uppercase;letter-spacing:.5px;color:var(--text2);margin-bottom:8px;}
  .card-value{font-size:24px;font-weight:700;color:var(--accent2);word-break:break-all;}
  .card-sub{font-size:12px;color:var(--text2);margin-top:4px;}

  .text-line{color:var(--text);font-size:14px;padding:3px 0;font-family:'Courier New',monospace;}
  .heading-el{font-size:18px;font-weight:700;color:var(--text);margin:20px 0 12px;padding-bottom:8px;border-bottom:1px solid var(--border);}
  hr.divider-el{border:none;border-top:1px solid var(--border);margin:16px 0;}

  .table-wrap{background:var(--surface);border:1px solid var(--border);border-radius:12px;overflow:hidden;margin-bottom:20px;}
  table{width:100%;border-collapse:collapse;font-size:13px;}
  thead th{background:var(--surface2);color:var(--text2);font-weight:600;text-transform:uppercase;font-size:11px;letter-spacing:.5px;padding:12px 16px;text-align:left;}
  tbody td{padding:11px 16px;border-top:1px solid var(--border);color:var(--text);}
  tbody tr:hover{background:var(--surface2);}

  .chart-wrap{background:var(--surface);border:1px solid var(--border);border-radius:12px;padding:20px;margin-bottom:20px;}
  .chart-label{font-size:13px;font-weight:600;color:var(--text2);margin-bottom:12px;}
  canvas{max-height:280px;}

  .error-box{background:rgba(255,107,107,.1);border:1px solid var(--red);border-radius:10px;padding:16px 20px;margin-bottom:16px;}
  .error-title{color:var(--red);font-weight:600;font-size:14px;margin-bottom:4px;}
  .error-hint{color:var(--text2);font-size:13px;}

  .placeholder{text-align:center;color:var(--text2);font-size:14px;padding:60px 20px;}
  .placeholder-icon{font-size:40px;margin-bottom:12px;}

  /* Responsive */
  @media(max-width:768px){
    .layout{grid-template-columns:1fr;}
    .sidebar{border-right:none;border-bottom:1px solid var(--border);}
  }
</style>
</head>
<body>

<div class="header">
  <div class="logo">Glang</div>
  <div class="app-title">${appTitle}</div>
  <div class="badge">Finance App</div>
  <div class="share-badge">📤 Shared</div>
</div>

<div class="layout">
  <div class="sidebar">
    <h3>Inputs</h3>
    <div id="fields"></div>
    <button class="run-btn" id="runBtn" onclick="run()">▶ Run Analysis</button>
    <div class="powered">Built with <span>Glang</span> · by Grewal</div>
  </div>
  <div class="main" id="output">
    <div class="placeholder">
      <div class="placeholder-icon">📊</div>
      <div>Fill in the inputs and click <strong>Run Analysis</strong></div>
    </div>
  </div>
</div>

<!-- Real Glang interpreter (same as glang run / glang app) -->
<script>
${bundle}
</script>

<script>
// The .grw source embedded at share time
const SOURCE = \`${escaped}\`;

// Discover input fields via a dry scan run
window._discoveredFields = [];
(function() {
  const { runInBrowser } = GlangRuntime;
  const { inputFields } = runInBrowser(SOURCE, {});
  window._discoveredFields = inputFields;
})();

// Build the sidebar form
function buildForm() {
  const container = document.getElementById("fields");
  const fields = window._discoveredFields;

  if (!fields || fields.length === 0) {
    container.innerHTML = '<div class="no-inputs">No inputs in this app.<br>Just click Run Analysis.</div>';
    return;
  }

  container.innerHTML = fields.map(f => {
    if (f.type === "select") {
      const opts = (f.options || []).map(o => '<option value="'+o+'">'+o+'</option>').join("");
      return '<div class="field"><label>'+f.name+'</label><select id="field_'+f.key+'">'+opts+'</select></div>';
    }
    const placeholder = f.type === "money" ? "e.g. 500000"
                      : f.type === "percent" ? "e.g. 8.5"
                      : f.type === "number" ? "e.g. 10"
                      : "Enter value";
    const defaultVal = f.default || "";
    return '<div class="field"><label>'+f.name+'</label><input id="field_'+f.key+'" placeholder="'+placeholder+'" value="'+defaultVal+'" /></div>';
  }).join("");
}

// Collect current input values
function collectInputs() {
  const inputs = {};
  (window._discoveredFields || []).forEach(f => {
    const el = document.getElementById("field_" + f.key);
    if (el) inputs[f.key] = el.value;
  });
  return inputs;
}

// Active chart instances (need to destroy before re-render)
let activeCharts = [];

// Render UI elements into the main panel
function render(elements) {
  activeCharts.forEach(c => c.destroy());
  activeCharts = [];

  const out = document.getElementById("output");
  let html = "";
  let cardBuffer = [];

  function flushCards() {
    if (!cardBuffer.length) return;
    html += '<div class="cards-row">' + cardBuffer.join("") + '</div>';
    cardBuffer = [];
  }

  elements.forEach((el, i) => {
    if (el.type !== "card") flushCards();
    switch (el.type) {
      case "card":
        cardBuffer.push(
          '<div class="card">' +
          '<div class="card-title">' + escHtml(el.title) + '</div>' +
          '<div class="card-value">' + escHtml(el.value) + '</div>' +
          (el.sub ? '<div class="card-sub">' + escHtml(el.sub) + '</div>' : '') +
          '</div>'
        );
        break;
      case "text":
        html += '<div class="text-line">' + escHtml(el.content) + '</div>';
        break;
      case "heading":
        html += '<div class="heading-el">' + escHtml(el.text) + '</div>';
        break;
      case "divider":
        html += '<hr class="divider-el">';
        break;
      case "table":
        html += '<div class="table-wrap"><table><thead><tr>';
        el.headers.forEach(h => { html += '<th>' + escHtml(h) + '</th>'; });
        html += '</tr></thead><tbody>';
        el.rows.forEach(row => {
          html += '<tr>';
          row.forEach(cell => { html += '<td>' + escHtml(cell) + '</td>'; });
          html += '</tr>';
        });
        html += '</tbody></table></div>';
        break;
      case "chart":
        html += '<div class="chart-wrap"><div class="chart-label">' + escHtml(el.label) + '</div><canvas id="chart_' + i + '"></canvas></div>';
        break;
      case "error":
        html += '<div class="error-box"><div class="error-title">⚠ ' + escHtml(el.msg) + '</div>' +
                (el.hint ? '<div class="error-hint">Try this: ' + escHtml(el.hint) + '</div>' : '') +
                '</div>';
        break;
    }
  });

  flushCards();
  out.innerHTML = html || '<div class="placeholder"><div class="placeholder-icon">📭</div><div>No output — check your .grw file</div></div>';

  // Mount Chart.js charts
  elements.forEach((el, i) => {
    if (el.type !== "chart") return;
    const canvas = document.getElementById("chart_" + i);
    if (!canvas || !el.data || !el.data.length) return;
    const up    = el.data[el.data.length - 1] >= el.data[0];
    const color = up ? "rgba(0,212,170,1)" : "rgba(255,107,107,1)";
    const fill  = up ? "rgba(0,212,170,0.08)" : "rgba(255,107,107,0.08)";
    const chart = new Chart(canvas, {
      type: el.kind === "bar" ? "bar" : "line",
      data: {
        labels: el.data.map((_, i) => i + 1),
        datasets: [{
          label: el.label,
          data: el.data,
          borderColor: color,
          backgroundColor: fill,
          borderWidth: 2,
          pointRadius: el.data.length > 60 ? 0 : 3,
          fill: true,
          tension: 0.3,
        }],
      },
      options: {
        responsive: true,
        plugins: { legend: { display: false } },
        scales: {
          x: { display: false },
          y: { grid: { color: "rgba(255,255,255,0.05)" }, ticks: { color: "#9ca3b0" } },
        },
      },
    });
    activeCharts.push(chart);
  });
}

// Run the Glang program with current inputs
function run() {
  const btn = document.getElementById("runBtn");
  btn.disabled = true;
  btn.textContent = "Running…";

  // Use setTimeout so the UI updates before computation blocks
  setTimeout(() => {
    try {
      const inputs = collectInputs();
      const { elements } = GlangRuntime.runInBrowser(SOURCE, inputs);
      render(elements);
    } catch (e) {
      render([{ type: "error", msg: e.message || String(e) }]);
    } finally {
      btn.disabled = false;
      btn.textContent = "▶ Run Analysis";
    }
  }, 10);
}

// XSS-safe HTML escaping
function escHtml(str) {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

// Init
buildForm();
</script>
</body>
</html>`;
}

function shareApp(filePath) {
  const resolved = path.resolve(filePath);
  if (!fs.existsSync(resolved)) {
    console.error(`Glang: file not found — "${filePath}"`);
    process.exit(1);
  }

  const source   = fs.readFileSync(resolved, "utf8");
  const filename = path.basename(resolved, ".grw");
  const appTitle = filename.replace(/_/g, " ").replace(/\b\w/g, c => c.toUpperCase());
  const outPath  = path.join(path.dirname(resolved), filename + ".html");

  let html;
  try {
    html = buildShareHTML(appTitle, source);
  } catch (e) {
    console.error("\nError building share:", e.message);
    process.exit(1);
  }

  fs.writeFileSync(outPath, html, "utf8");
  const kb = (html.length / 1024).toFixed(1);

  console.log(`\n✓ Shared: ${path.basename(outPath)}  (${kb} KB)`);
  console.log(`  Location: ${outPath}`);
  console.log(`  Open in any browser — no installation, no internet needed`);
  console.log(`  Works: email it, USB, WhatsApp, GitHub Pages, Google Drive\n`);
}

module.exports = { shareApp, _buildShareHTML: buildShareHTML };
