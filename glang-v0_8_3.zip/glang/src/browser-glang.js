// browser-glang.js — entry point for browserify bundling
// This file takes the real Glang interpreter and exposes it as a global
// window.Glang object so the share HTML can use the exact same code
// that runs on the server. No separate mini-interpreter — one codebase.

const { Lexer, GlangSyntaxError } = require("./lexer.js");
const { Parser } = require("./parser.js");
const {
  Interpreter,
  GlangRuntimeError,
  GlangCurrency,
  GlangList,
  GlangPercent,
  GlangStock,
} = require("./interpreter.js");

// App-mode UI collector (same as app.js but standalone for browser)
class UICollector {
  constructor() { this.elements = []; }
  reset() { this.elements = []; }
  text(content)            { this.elements.push({ type: "text", content: String(content) }); }
  card(title, value, sub)  { this.elements.push({ type: "card", title, value, sub: sub || "" }); }
  table(headers, rows)     { this.elements.push({ type: "table", headers, rows }); }
  chart(label, data, kind) { this.elements.push({ type: "chart", label, data, kind: kind || "line" }); }
  heading(text)            { this.elements.push({ type: "heading", text }); }
  divider()                { this.elements.push({ type: "divider" }); }
  alert(msg, kind)         { this.elements.push({ type: "error", msg, kind }); }
}

// Browser-safe AppInterpreter — same logic as app.js but without http/fs
class BrowserInterpreter extends Interpreter {
  constructor(ui, inputs) {
    super();
    this.ui = ui;
    this.inputs = inputs || {};
    this._inputFields = [];
    this._selectOptions = {};
    this._scanOnly = false;
    this._setupAppBuiltins();
  }

  _plain(value) {
    if (value instanceof GlangCurrency) return value.toString();
    if (value instanceof GlangPercent) {
      const pct = Math.round((value.value * 100 + Number.EPSILON) * 100) / 100;
      return `${pct}%`;
    }
    if (value instanceof GlangList) return value.items.map(v => this._plain(v)).join(", ");
    if (value instanceof GlangStock) return value.toString();
    if (value === null || value === undefined) return "—";
    return String(value);
  }

  _parseInput(raw, type) {
    type = (type || "").toLowerCase();
    if (type === "money" || type === "currency") {
      const amt = parseFloat(String(raw).replace(/[^0-9.]/g, ""));
      return new GlangCurrency(isNaN(amt) ? 0 : amt, "INR");
    }
    if (type === "percent" || type === "percentage") {
      const pct = parseFloat(String(raw).replace(/[^0-9.]/g, ""));
      return new GlangPercent(isNaN(pct) ? 0 : pct / 100);
    }
    if (type === "number") {
      const n = parseFloat(raw);
      return isNaN(n) ? 0 : n;
    }
    return String(raw || "");
  }

  _defaultForType(type) {
    if (this._scanOnly) {
      if (type === "money" || type === "currency") return "100000";
      if (type === "percent" || type === "percentage") return "8";
      if (type === "number") return "10";
      return "value";
    }
    return "0";
  }

  _setupAppBuiltins() {
    const ui = this.ui;
    const self = this;

    this.globals.define("show", {
      __builtin__: true, name: "show",
      call: (args) => { ui.text(args.map(v => self._plain(v)).join(" ")); return null; },
    });

    this.globals.define("show_card", {
      __builtin__: true, name: "show_card",
      call: (args, line) => {
        if (args.length < 2) throw new GlangRuntimeError("show_card() needs a title and a value.", line, null);
        ui.card(self._plain(args[0]), self._plain(args[1]), args[2] ? self._plain(args[2]) : "");
        return null;
      },
    });

    this.globals.define("show_table", {
      __builtin__: true, name: "show_table",
      call: (args, line) => {
        if (args.length < 2) throw new GlangRuntimeError("show_table() needs headers and rows.", line, null);
        const [headers, rows] = args;
        if (!(headers instanceof GlangList)) throw new GlangRuntimeError("show_table() first value must be a list.", line, null);
        if (!(rows instanceof GlangList)) throw new GlangRuntimeError("show_table() second value must be a list.", line, null);
        const h = headers.items.map(v => self._plain(v));
        const r = rows.items.map(row => row instanceof GlangList ? row.items.map(v => self._plain(v)) : [self._plain(row)]);
        ui.table(h, r);
        return null;
      },
    });

    this.globals.define("show_chart", {
      __builtin__: true, name: "show_chart",
      call: (args, line) => {
        if (args.length < 2) throw new GlangRuntimeError("show_chart() needs a label and data.", line, null);
        const [label, data, kind] = args;
        if (!(data instanceof GlangList)) throw new GlangRuntimeError("show_chart() data must be a list.", line, null);
        const points = data.items.map(v => v instanceof GlangCurrency ? v.amount : (typeof v === "number" ? v : null)).filter(v => v !== null);
        ui.chart(self._plain(label), points, kind ? self._plain(kind) : "line");
        return null;
      },
    });

    this.globals.define("show_bar_chart", {
      __builtin__: true, name: "show_bar_chart",
      call: (args, line) => {
        if (args.length < 2) throw new GlangRuntimeError("show_bar_chart() needs a label and data.", line, null);
        const [label, data] = args;
        if (!(data instanceof GlangList)) throw new GlangRuntimeError("show_bar_chart() data must be a list.", line, null);
        const points = data.items.map(v => v instanceof GlangCurrency ? v.amount : (typeof v === "number" ? v : null)).filter(v => v !== null);
        ui.chart(self._plain(label), points, "bar");
        return null;
      },
    });

    this.globals.define("show_heading", {
      __builtin__: true, name: "show_heading",
      call: (args, line) => {
        if (!args[0]) throw new GlangRuntimeError("show_heading() needs text.", line, null);
        ui.heading(self._plain(args[0]));
        return null;
      },
    });

    this.globals.define("divider", {
      __builtin__: true, name: "divider",
      call: () => { ui.divider(); return null; },
    });

    this.globals.define("input", {
      __builtin__: true, name: "input",
      call: (args, line) => {
        if (args.length < 2) throw new GlangRuntimeError("input() needs a name and a type.", line, null);
        const name     = self._plain(args[0]);
        const type     = self._plain(args[1]).toLowerCase();
        const default_ = args[2] !== undefined ? self._plain(args[2]) : null;
        const key      = name.toLowerCase().replace(/[^a-z0-9]/g, "_");

        if (!self._inputFields.find(f => f.key === key)) {
          self._inputFields.push({ name, type, key, default: default_ });
        }

        if (self.inputs[key] !== undefined && self.inputs[key] !== "") {
          return self._parseInput(self.inputs[key], type);
        }
        return self._parseInput(default_ || self._defaultForType(type), type);
      },
    });

    this.globals.define("select", {
      __builtin__: true, name: "select",
      call: (args, line) => {
        if (args.length < 2) throw new GlangRuntimeError("select() needs a name and options.", line, null);
        const name    = self._plain(args[0]);
        const optList = args[1];
        if (!(optList instanceof GlangList)) throw new GlangRuntimeError("select() options must be a list.", line, null);
        const key     = name.toLowerCase().replace(/[^a-z0-9]/g, "_");
        const options = optList.items.map(v => self._plain(v));

        if (!self._inputFields.find(f => f.key === key)) {
          self._inputFields.push({ name, type: "select", key, default: options[0], options });
        }

        if (self.inputs[key] !== undefined && self.inputs[key] !== "") {
          return String(self.inputs[key]);
        }
        return options[0] || "";
      },
    });
  }
}

function runInBrowser(source, inputs) {
  const ui = new UICollector();
  let inputFields = [];

  // Pass 1: scan for input fields with safe defaults
  try {
    const tokens = new Lexer(source).tokenize();
    const ast    = new Parser(tokens).parse();
    const scanner = new BrowserInterpreter(new UICollector(), {});
    scanner._scanOnly = true;
    scanner.interpret(ast);
    inputFields = scanner._inputFields || [];
  } catch (e) { /* ignore */ }

  // Pass 2: real run with actual inputs
  try {
    const tokens = new Lexer(source).tokenize();
    const ast    = new Parser(tokens).parse();
    const interp = new BrowserInterpreter(ui, inputs || {});
    interp.interpret(ast);
    for (const f of (interp._inputFields || [])) {
      if (!inputFields.find(x => x.key === f.key)) inputFields.push(f);
    }
  } catch (err) {
    const line = err.line || 0;
    const hint = err.hint ? ` — ${err.hint}` : "";
    if (err instanceof GlangSyntaxError || err instanceof GlangRuntimeError) {
      ui.alert(`Line ${line}: ${err.message}${hint}`, "error");
    } else {
      ui.alert("Internal error: " + (err.message || String(err)), "error");
    }
  }

  return { elements: ui.elements, inputFields };
}

// Expose as global for the browser
if (typeof window !== "undefined") {
  window.GlangRuntime = { runInBrowser };
}

module.exports = { runInBrowser, BrowserInterpreter, UICollector };
