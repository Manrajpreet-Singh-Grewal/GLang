// Glang Docs — Phase 5
// glang docs → generates GLANG.md (complete language reference)

const fs   = require("fs");
const path = require("path");

const pkg = require("../package.json");

const DOCS = `# Glang Language Reference

> **Glang v${pkg.version}** — A programming language for finance.  
> Built by Manrajpreet Singh Grewal. File extension: \`.grw\`

---

## Quick Start

\`\`\`
let loan = ₹500000
let rate = 8.5%
let years = 20
show("Monthly EMI: " + str(emi(loan, rate, years)))
\`\`\`

Run it:
\`\`\`bash
glang run myfile.grw         # script mode
glang app myfile.grw         # web app at localhost:4000
glang share myfile.grw       # export to standalone HTML
\`\`\`

---

## Types

| Type | Example | Notes |
|---|---|---|
| Number | \`42\` \`3.14\` | Plain numbers |
| Text | \`"hello"\` | Strings in double quotes |
| True/False | \`true\` \`false\` | Booleans |
| Money | \`₹500000\` \`$1000\` \`€250\` \`£800\` | Currency with symbol |
| Percentage | \`8.5%\` \`12%\` | Stored as decimal (8.5% = 0.085) |
| List | \`[1, 2, 3]\` \`[₹100, ₹200]\` | Zero-indexed |

### Currency symbols
| Symbol | Currency |
|---|---|
| ₹ | Indian Rupee (INR) |
| $ | US Dollar (USD) |
| € | Euro (EUR) |
| £ | British Pound (GBP) |

### Type rules for math
| Operation | Result |
|---|---|
| \`₹1000 * 8%\` | \`₹80\` (currency × percent → currency) |
| \`₹1000 + ₹500\` | \`₹1500\` (same currency only) |
| \`₹1000 + $500\` | **Error** — must convert first |
| \`5% + 3%\` | \`8%\` (percent + percent) |
| \`100 * 5%\` | \`5\` (number × percent → number) |

---

## Variables

\`\`\`
let balance = ₹100000
let rate = 8%
let name = "Rahul"
let active = true

# Reassign (no 'let' needed)
balance = ₹150000
\`\`\`

---

## Functions

\`\`\`
fn greet(name):
    show("Hello, " + name)

fn compound(principal, rate, years):
    return principal * (1 + rate) ^ years

greet("Rahul")
let amount = compound(₹100000, 8%, 5)
\`\`\`

---

## Control Flow

### If / Else
\`\`\`
if balance > ₹100000:
    show("High balance")
else:
    show("Low balance")
\`\`\`

### Repeat N times
\`\`\`
repeat 12 times:
    show("Month")
\`\`\`

### For each item in list
\`\`\`
let stocks = ["TCS", "INFY", "HDFC"]
for sym in stocks:
    show(sym)
\`\`\`

---

## Lists

\`\`\`
let prices = [₹3200, ₹1400, ₹2900]

show(prices[0])           # ₹3,200.00 (first item)
show(prices.length)       # 3

# Multi-line lists work too
let data = [
    ₹10000,
    ₹20000,
    ₹30000
]
\`\`\`

---

## Built-in Finance Functions

### Core Finance

| Function | What it does | Example |
|---|---|---|
| \`emi(principal, rate, years)\` | Monthly EMI on a loan | \`emi(₹500000, 8.5%, 20)\` |
| \`simple_interest(p, r, y)\` | Simple interest earned | \`simple_interest(₹10000, 6%, 3)\` |
| \`compound(p, r, y)\` | Final amount after compounding | \`compound(₹10000, 8%, 5)\` |
| \`compound_interest(p, r, y)\` | Interest earned (not total) | \`compound_interest(₹10000, 8%, 5)\` |
| \`total_loan_cost(p, r, y)\` | Total paid over loan tenure | \`total_loan_cost(₹500000, 8.5%, 20)\` |
| \`loan_interest_paid(p, r, y)\` | Total interest paid to bank | \`loan_interest_paid(₹500000, 8.5%, 20)\` |
| \`loan_schedule(p, r, y)\` | Month-by-month amortization | \`loan_schedule(₹500000, 8.5%, 5)\` |

### SIP & Investment

| Function | What it does | Example |
|---|---|---|
| \`sip(monthly, rate, years)\` | SIP corpus at maturity | \`sip(₹10000, 12%, 15)\` |
| \`sip_invested(monthly, years)\` | Total amount invested in SIP | \`sip_invested(₹10000, 15)\` |
| \`sip_goal(target, rate, years)\` | Monthly SIP needed to reach target | \`sip_goal(₹5000000, 12%, 20)\` |
| \`fv(principal, rate, years)\` | Future value | \`fv(₹100000, 8%, 5)\` |
| \`pv(future, rate, years)\` | Present value | \`pv(₹146000, 8%, 5)\` |
| \`cagr(initial, final, years)\` | Compound annual growth rate | \`cagr(₹100000, ₹350000, 5)\` |
| \`roi(buy_price, sell_price)\` | Return on investment | \`roi(₹50000, ₹75000)\` |
| \`irr(investment, cashflows)\` | Internal rate of return | \`irr(₹100000, [₹40000, ₹50000])\` |
| \`npv(rate, cashflows, cost?)\` | Net present value | \`npv(10%, [₹30000, ₹40000], ₹80000)\` |
| \`inflation_adjust(amount, rate, years)\` | Real value after inflation | \`inflation_adjust(₹1000000, 6%, 10)\` |
| \`weighted_average(values, weights)\` | Weighted average cost | \`weighted_average([₹100, ₹150], [3, 1])\` |

### Tax (India, New Regime FY2024-25)

| Function | What it does | Example |
|---|---|---|
| \`tax(income)\` | Income tax payable (incl. 4% cess) | \`tax(₹1200000)\` |
| \`take_home(income)\` | Annual take-home after tax | \`take_home(₹1200000)\` |

### Business Analysis

| Function | What it does | Example |
|---|---|---|
| \`break_even(fixed, price, variable)\` | Units needed to break even | \`break_even(₹500000, ₹200, ₹80)\` |
| \`percent_change(old, new)\` | Percentage change | \`percent_change(₹1000, ₹1200)\` |

### Formatting

| Function | What it does | Example |
|---|---|---|
| \`format_inr(amount)\` | ₹ amount → lakh/crore notation | \`format_inr(₹12500000)\` → \`"1.25 crore"\` |
| \`str(value)\` | Convert any value to text | \`str(₹500)\` → \`"₹500.00"\` |
| \`num(value)\` | Convert text to number | \`num("42")\` → \`42\` |
| \`round(value, decimals)\` | Round a number | \`round(3.14159, 2)\` → \`3.14\` |
| \`abs(value)\` | Absolute value | \`abs(-50)\` → \`50\` |

### List Functions

| Function | What it does | Example |
|---|---|---|
| \`total(list)\` | Sum of all values | \`total([₹100, ₹200, ₹300])\` |
| \`average(list)\` | Average of all values | \`average([₹100, ₹200])\` |
| \`max_val(list)\` | Largest value | \`max_val([₹100, ₹500, ₹200])\` |
| \`min_val(list)\` | Smallest value | \`min_val([₹100, ₹500, ₹200])\` |
| \`length(list)\` | Number of items | \`length([1, 2, 3])\` → \`3\` |
| \`append(list, value)\` | Add item to list | \`append(my_list, ₹500)\` |
| \`moving_average(list, window)\` | Moving average | \`moving_average(prices, 20)\` |
| \`sort(list)\` | Sort ascending | \`sort([3, 1, 2])\` → \`[1, 2, 3]\` |
| \`sort_desc(list)\` | Sort descending | \`sort_desc([1, 3, 2])\` → \`[3, 2, 1]\` |
| \`reverse(list)\` | Reverse order | \`reverse([1, 2, 3])\` → \`[3, 2, 1]\` |
| \`unique(list)\` | Remove duplicates | \`unique([1, 1, 2])\` → \`[1, 2]\` |
| \`slice(list, start, end)\` | Sub-list | \`slice([1,2,3,4], 1, 3)\` → \`[2, 3]\` |
| \`first(list)\` | First item | \`first([1, 2, 3])\` → \`1\` |
| \`last(list)\` | Last item | \`last([1, 2, 3])\` → \`3\` |
| \`flatten(list)\` | Flatten nested lists | \`flatten([[1,2],[3]])\` → \`[1, 2, 3]\` |
| \`zip(list1, list2)\` | Pair up two lists | \`zip([1,2], ["a","b"])\` → \`[[1,"a"],[2,"b"]]\` |
| \`count_if(list, condition)\` | Count items matching a condition | \`count_if(prices, "> 1000")\` |
| \`index_of(list, value)\` | Position of a value, or -1 | \`index_of([1,2,3], 2)\` → \`1\` |
| \`is_empty(list)\` | Whether a list/dict/text is empty | \`is_empty([])\` → \`true\` |

### Text Functions

| Function | What it does | Example |
|---|---|---|
| \`upper(text)\` | Uppercase | \`upper("hello")\` → \`"HELLO"\` |
| \`lower(text)\` | Lowercase | \`lower("HELLO")\` → \`"hello"\` |
| \`trim(text)\` | Remove leading/trailing whitespace | \`trim("  hi  ")\` → \`"hi"\` |
| \`split(text, sep)\` | Split into a list | \`split("a,b,c", ",")\` → \`["a","b","c"]\` |
| \`join(list, sep)\` | Join a list into text | \`join(["a","b"], "-")\` → \`"a-b"\` |
| \`contains(text_or_list, value)\` | Whether it contains a value | \`contains("hello", "ell")\` → \`true\` |
| \`replace(text, from, to)\` | Replace all occurrences | \`replace("a,b", ",", "-")\` → \`"a-b"\` |
| \`substring(text, start, end)\` | Extract part of text | \`substring("hello", 0, 3)\` → \`"hel"\` |
| \`starts_with(text, prefix)\` | Whether text starts with prefix | \`starts_with("hello", "he")\` → \`true\` |
| \`ends_with(text, suffix)\` | Whether text ends with suffix | \`ends_with("hello", "lo")\` → \`true\` |
| \`pad_left(text, length, char)\` | Pad text on the left | \`pad_left("5", 3, "0")\` → \`"005"\` |
| \`pad_right(text, length, char)\` | Pad text on the right | \`pad_right("5", 3, "0")\` → \`"500"\` |
| \`repeat_text(text, n)\` | Repeat text n times | \`repeat_text("ab", 3)\` → \`"ababab"\` |

### Math & Date Functions

| Function | What it does | Example |
|---|---|---|
| \`floor(value)\` | Round down | \`floor(3.7)\` → \`3\` |
| \`ceil(value)\` | Round up | \`ceil(3.2)\` → \`4\` |
| \`sqrt(value)\` | Square root | \`sqrt(16)\` → \`4\` |
| \`power(base, exp)\` | Exponentiation | \`power(2, 10)\` → \`1024\` |
| \`min(a, b, ...)\` | Smallest of the arguments | \`min(3, 1, 2)\` → \`1\` |
| \`max(a, b, ...)\` | Largest of the arguments | \`max(3, 1, 2)\` → \`3\` |
| \`log(value)\` | Natural logarithm | \`log(2.718)\` → \`≈1\` |
| \`safe_divide(a, b, fallback)\` | Division with a fallback for divide-by-zero | \`safe_divide(10, 0, 0)\` → \`0\` |
| \`today()\` | Today's date | \`today()\` → \`"2026-08-05"\` |
| \`current_month()\` | Current month number | \`current_month()\` → \`8\` |
| \`current_year()\` | Current year | \`current_year()\` → \`2026\` |
| \`days_between(date1, date2)\` | Days between two dates | \`days_between("2026-01-01", "2026-02-01")\` → \`31\` |
| \`years_between(date1, date2)\` | Years between two dates | \`years_between("2020-01-01", "2026-01-01")\` → \`6\` |
| \`format_date(date, format)\` | Format a date string | \`format_date("2026-08-05", "DD/MM/YYYY")\` |

### Type-Checking Functions

| Function | What it does | Example |
|---|---|---|
| \`is_money(value)\` | Whether a value is currency | \`is_money($5)\` → \`true\` |
| \`is_number(value)\` | Whether a value is a plain number | \`is_number(5)\` → \`true\` |
| \`is_text(value)\` | Whether a value is text | \`is_text("hi")\` → \`true\` |
| \`is_list(value)\` | Whether a value is a list | \`is_list([1,2])\` → \`true\` |
| \`is_percent(value)\` | Whether a value is a percentage | \`is_percent(5%)\` → \`true\` |

### Currency Conversion

| Function | What it does | Example |
|---|---|---|
| \`convert(amount, to: "INR")\` | Convert between currencies | **Not yet available** — currently raises a friendly "not available yet" error. Planned for a future release; live conversion is not shipped in v${pkg.version}. |

### Dictionary Functions

Dictionaries store key-value pairs: \`let person = {name: "Alex", age: 30}\`.
Read a value with \`person.name\` or \`person["name"]\`. Set one with
\`person.city = "Delhi"\` or \`person["city"] = "Delhi"\` (works for new
keys too). \`for key in person:\` loops over the keys.

| Function | What it does | Example |
|---|---|---|
| \`keys(dict)\` | List of all keys | \`keys({a: 1, b: 2})\` → \`[a, b]\` |
| \`values(dict)\` | List of all values | \`values({a: 1, b: 2})\` → \`[1, 2]\` |
| \`has_key(dict, key)\` | Whether a key exists | \`has_key({a: 1}, "a")\` → \`true\` |
| \`dict_get(dict, key, fallback)\` | Read a key, or a fallback if missing | \`dict_get({a: 1}, "z", 0)\` → \`0\` |
| \`is_dict(value)\` | Whether a value is a dictionary | \`is_dict({a: 1})\` → \`true\` |

---

## Standard Library Modules

Bring in extra functions with \`import module_name\`. These are written in
Glang itself (see \`packages/stdlib/\`), not built into the interpreter.

### \`import finance\`

| Function | What it does |
|---|---|
| \`loan_affordability(income, existing_emi, rate, years)\` | Max loan you can afford |
| \`debt_to_income(total_debt_payments, income)\` | Debt-to-income ratio |
| \`rule_of_72(rate)\` | Years to double money, approx. |
| \`real_return(nominal_rate, inflation_rate)\` | Inflation-adjusted return |
| \`savings_rate(savings, income)\` | Percentage of income saved |
| \`emergency_fund_needed(monthly_expenses, months)\` | Target emergency fund |
| \`emi_to_income_ratio(emi, income)\` | EMI burden as a % of income |
| \`total_wealth(assets, liabilities)\` | Net worth |
| \`annualized_return(total_return, years)\` | Annualized version of a total return |
| \`doubling_time(rate)\` | Exact years to double money |

### \`import tax\` (India)

| Function | What it does |
|---|---|
| \`old_regime_tax(income)\` | Tax under the old regime |
| \`new_regime_tax(income)\` | Tax under the new regime |
| \`hra_exemption(basic, hra_received, rent_paid, is_metro)\` | HRA exemption amount |
| \`standard_deduction(income)\` | Standard deduction applied |
| \`best_regime(income)\` | Which regime is cheaper |
| \`tax_saved_80c(investment_amount)\` | Tax saved via 80C investments |
| \`gst_amount(amount, rate)\` | GST amount on a price |
| \`total_with_gst(amount, rate)\` | Price including GST |

### \`import stocks\`

| Function | What it does |
|---|---|
| \`price_to_book(price, book_value)\` | P/B ratio |
| \`earnings_per_share(net_income, shares)\` | EPS |
| \`dividend_yield(annual_dividend, price)\` | Dividend yield |
| \`intrinsic_value(eps, growth_rate)\` | Rough intrinsic value estimate |
| \`sharpe_ratio_approx(return_, risk_free, std_dev)\` | Approximate Sharpe ratio |
| \`is_oversold(rsi)\` | Whether RSI suggests oversold |
| \`is_overbought(rsi)\` | Whether RSI suggests overbought |
| \`position_size(capital, risk_pct, stop_loss_pct)\` | Suggested position size |
| \`portfolio_return(buy_prices, sell_prices, qtys)\` | Overall portfolio return |

### \`import math\`

| Function | What it does |
|---|---|
| \`power(base, exp)\` | Exponentiation |
| \`percentage_of(part, whole)\` | What % one number is of another |
| \`increase_by(value, pct)\` | Increase a value by a percentage |
| \`decrease_by(value, pct)\` | Decrease a value by a percentage |
| \`clamp(value, min, max)\` | Constrain a value to a range |
| \`interpolate(a, b, t)\` | Linear interpolation between two values |
| \`sum_list(list)\` | Sum of a list |
| \`mean(list)\` | Average of a list |

---

## Stock Market (Phase 3)

\`\`\`
let s = stock("TCS")        # create a stock object
show(s.price)               # current price
show(s.name)                # full company name
show(s.pe)                  # PE ratio (or "N/A")
show(s.high52)              # 52-week high
show(s.low52)               # 52-week low
show(s.change)              # today's price change
show(s.change_pct)          # today's % change
show(s.volume)              # trading volume
show(s.sector)              # e.g. "IT", "Banking"
show(s.exchange)            # e.g. "NSE", "NASDAQ"
\`\`\`

### Supported symbols (live via Yahoo Finance)
- **Indian (NSE):** TCS, RELIANCE, INFY, HDFC, SBIN, WIPRO, BAJFINANCE, ICICIBANK, TATAMOTORS, HCLTECH, MARUTI
- **US (NASDAQ/NYSE):** AAPL, GOOGL, MSFT, AMZN, TSLA, META
- **Any valid Yahoo Finance ticker:** Add .NS for NSE, .BSE for BSE

### Stock analysis functions

| Function | What it does |
|---|---|
| \`history(stock("TCS"), 30)\` | Last 30 days of closing prices as a list |
| \`moving_average(prices, 20)\` | 20-day moving average |
| \`compare_stocks([s1, s2])\` | Side-by-side comparison table |
| \`top_gainer([s1, s2, s3])\` | Best performer today |
| \`top_loser([s1, s2, s3])\` | Worst performer today |
| \`portfolio_value([s1, s2])\` | Total market value |
| \`portfolio_pnl(symbols, buys, qtys)\` | Full P&L table |
| \`stock_return("TCS", ₹3200)\` | Your return since buying |

---

## App Mode (Phase 4)

Run \`glang app myfile.grw\` to turn any script into a web app.

### App-only functions

| Function | What it does |
|---|---|
| \`input("Label", "money")\` | Number input for money |
| \`input("Label", "percent")\` | Number input for percentage |
| \`input("Label", "number")\` | Plain number input |
| \`input("Label", "text")\` | Text input |
| \`select("Label", ["A","B"])\` | Dropdown selector |
| \`show_card("Title", value)\` | Highlighted metric card |
| \`show_table(headers, rows)\` | Data table |
| \`show_chart("Label", data)\` | Line chart |
| \`show_bar_chart("Label", data)\` | Bar chart |
| \`show_heading("Text")\` | Section heading |
| \`divider()\` | Horizontal rule |

### Sharing
\`\`\`bash
glang share myfile.grw    # → myfile.html (works in any browser, no install)
\`\`\`

---

## CLI Commands

| Command | What it does |
|---|---|
| \`glang run file.grw\` | Run a Glang script |
| \`glang app file.grw\` | Start web app at localhost:4000 |
| \`glang share file.grw\` | Export self-contained HTML |
| \`glang new my-project\` | Scaffold a new project |
| \`glang docs\` | Generate this reference file |
| \`glang help\` | Show help |
| \`glang version\` | Show version |

---

## Error Messages

Glang gives plain-English errors with fixes:
\`\`\`
Oops! Something's not right in myfile.grw, line 3:

  3 |  show(name + age)

  Hold on! You tried to combine a word ("Alex") and a number (10) using +.

  Try this: Convert first — use str(age) to turn the number into text.
\`\`\`

---

*Glang v${pkg.version} — Built by Manrajpreet Singh Grewal*
`;

function generateDocs(outPath) {
  const resolved = path.resolve(outPath || "GLANG.md");
  fs.writeFileSync(resolved, DOCS, "utf8");
  const kb = (DOCS.length / 1024).toFixed(1);
  console.log(`\n✓ Docs written: ${resolved}  (${kb} KB)`);
  console.log(`  Open in any Markdown viewer, GitHub, or VS Code\n`);
}

module.exports = { generateDocs };
