// Glang Execution Sandbox
// Runs a .grw program's app-mode execution (runApp) inside a worker_thread
// with a wall-clock timeout and a memory cap, instead of running it
// directly on whatever thread called in.
//
// Why this exists: `glang app` starts an HTTP server that runs whatever
// .grw file it's pointed at, once per request. Without this, a script
// that runs forever (or allocates without bound) runs on the *same*
// thread as the HTTP server itself — one bad request can hang or crash
// the whole thing for every other user. Each call to runSandboxed():
//   - runs in its own Worker (separate V8 isolate — no shared state
//     between concurrent requests, so nothing can bleed between sessions)
//   - is killed if it runs past `timeoutMs` (default 5s)
//   - is killed if it exceeds `memoryMb` of heap (default 128MB)
// Either limit being hit surfaces as a normal, friendly alert element —
// exactly like a Glang syntax or runtime error would — not a server crash.

const path = require("path");
const { Worker } = require("worker_threads");

const DEFAULT_TIMEOUT_MS = Number(process.env.GLANG_APP_TIMEOUT_MS) || 5000;
const DEFAULT_MEMORY_MB = Number(process.env.GLANG_APP_MEMORY_MB) || 128;

function timeoutAlert(timeoutMs) {
  return [{
    type: "alert",
    kind: "error",
    msg: `This program took longer than ${(timeoutMs / 1000).toFixed(1)}s to run, so it was stopped.`,
    hint: "Check for a loop that never ends — for example a \"while\" condition that never becomes false, or a huge \"repeat ... times\" count.",
  }];
}

function memoryAlert(memoryMb) {
  return [{
    type: "alert",
    kind: "error",
    msg: `This program used more than ${memoryMb}MB of memory, so it was stopped.`,
    hint: "Check for a list that keeps growing inside a loop, or a very large repeat/while loop building up data without bound.",
  }];
}

function internalAlert(message) {
  return [{ type: "alert", kind: "error", msg: `Internal Glang error: ${message}` }];
}

// Runs `source` (app-mode .grw code) in an isolated worker thread.
// Resolves with { elements, inputFields } — same shape as runApp() —
// even when the run was stopped by a limit, so callers don't need a
// separate error path.
function runSandboxed(source, filename, inputs, options = {}) {
  const timeoutMs = options.timeoutMs || DEFAULT_TIMEOUT_MS;
  const memoryMb = options.memoryMb || DEFAULT_MEMORY_MB;

  return new Promise((resolve) => {
    let settled = false;
    let worker;

    const finish = (elements, inputFields = []) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      if (worker) {
        worker.removeAllListeners();
        worker.terminate().catch(() => {});
      }
      resolve({ elements, inputFields });
    };

    const timer = setTimeout(() => finish(timeoutAlert(timeoutMs)), timeoutMs);

    try {
      worker = new Worker(path.join(__dirname, "sandbox-worker.js"), {
        workerData: { source, filename, inputs },
        resourceLimits: {
          maxOldGenerationSizeMb: memoryMb,
          maxYoungGenerationSizeMb: Math.max(16, Math.floor(memoryMb / 4)),
        },
      });
    } catch (err) {
      finish(internalAlert(err.message));
      return;
    }

    worker.on("message", (msg) => {
      if (msg.ok) {
        finish(msg.result.elements, msg.result.inputFields);
      } else {
        finish(internalAlert(msg.error));
      }
    });

    worker.on("error", (err) => {
      const isMemory = /heap|memory|allocation failed/i.test(err.message || "");
      finish(isMemory ? memoryAlert(memoryMb) : internalAlert(err.message));
    });

    worker.on("exit", (code) => {
      if (!settled && code !== 0) {
        finish(internalAlert(`the program stopped unexpectedly (exit code ${code})`));
      }
    });
  });
}

module.exports = { runSandboxed, DEFAULT_TIMEOUT_MS, DEFAULT_MEMORY_MB };
