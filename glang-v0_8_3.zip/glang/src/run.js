#!/usr/bin/env node
// Glang CLI runner
// Usage: node src/run.js path/to/file.grw

const fs = require("fs");
const path = require("path");
const { Lexer, GlangSyntaxError } = require("./lexer.js");
const { Parser } = require("./parser.js");
const { Interpreter, GlangRuntimeError } = require("./interpreter.js");

const RESET = "\x1b[0m";
const RED = "\x1b[31m";
const YELLOW = "\x1b[33m";
const CYAN = "\x1b[36m";
const BOLD = "\x1b[1m";
const DIM = "\x1b[2m";

function renderError(err, source, filename) {
  const lines = source.split("\n");
  const lineText = lines[err.line - 1] || "";

  console.error("");
  console.error(`${RED}${BOLD}Oops! Something's not right in ${filename}, line ${err.line}:${RESET}`);
  console.error("");
  if (lineText.trim().length > 0) {
    console.error(`${DIM}  ${err.line} |${RESET}  ${lineText}`);
    console.error("");
  }
  console.error(`  ${err.message}`);
  if (err.hint) {
    console.error("");
    console.error(`  ${CYAN}Try this:${RESET} ${err.hint}`);
  }
  console.error("");
}

function main() {
  const filePath = process.argv[2];
  if (!filePath) {
    console.error("Usage: glang run <file.grw>");
    process.exit(1);
  }

  const resolvedPath = path.resolve(filePath);
  if (!fs.existsSync(resolvedPath)) {
    console.error(`${RED}Couldn't find the file "${filePath}".${RESET}`);
    console.error(`${CYAN}Try this:${RESET} Check the file path and make sure it ends in .grw`);
    process.exit(1);
  }

  const filename = path.basename(resolvedPath);
  const source = fs.readFileSync(resolvedPath, "utf8");

  let tokens;
  try {
    tokens = new Lexer(source).tokenize();
  } catch (err) {
    if (err instanceof GlangSyntaxError) {
      renderError(err, source, filename);
      process.exit(1);
    }
    throw err;
  }

  let ast;
  try {
    ast = new Parser(tokens).parse();
  } catch (err) {
    if (err instanceof GlangSyntaxError) {
      renderError(err, source, filename);
      process.exit(1);
    }
    throw err;
  }

  try {
    new Interpreter().interpret(ast, resolvedPath);
  } catch (err) {
    if (err instanceof GlangRuntimeError) {
      renderError(err, source, filename);
      process.exit(1);
    }
    // Unexpected internal error — show it plainly so we (or AI) can debug,
    // but make clear it's not the user's fault.
    console.error(`${RED}${BOLD}Internal Glang error (this is a bug in Glang, not your code):${RESET}`);
    console.error(err.stack || err.message);
    process.exit(1);
  }
}

main();
