// Glang Site Generator — Phase 5 Part 2
// glang site myapp.grw → generates a complete website folder
// Output: myapp-site/
//   index.html    → landing page
//   app.html      → the working app (same as glang share)
//   embed.js      → embeddable widget for other sites

const fs   = require("fs");
const path = require("path");

function generateSite(filePath, options = {}) {
  const resolved = path.resolve(filePath);
  if (!fs.existsSync(resolved)) {
    console.error(`Glang: file not found — "${filePath}"`);
    process.exit(1);
  }

  const source   = fs.readFileSync(resolved, "utf8");
  const filename = path.basename(resolved, ".grw");
  const appTitle = options.title || filename.replace(/_/g, " ").replace(/\b\w/g, c => c.toUpperCase());
  const desc     = options.desc  || `A financial calculator built with Glang`;
  const author   = options.author || "Grewal";
  const outDir   = path.resolve(options.out || filename + "-site");

  fs.mkdirSync(outDir, { recursive: true });

  // 1. Generate the app HTML (same as glang share, uses real interpreter)
  const { shareApp } = require("./share.js");
  // Temporarily redirect output
  const appHtmlPath = path.join(outDir, "app.html");
  const bundlePath  = path.join(__dirname, "browser-bundle.js");
  if (!fs.existsSync(bundlePath)) {
    console.error("Browser bundle not found. Run: npm run build-browser");
    process.exit(1);
  }
  const bundle  = fs.readFileSync(bundlePath, "utf8");
  const escaped = source.replace(/\\/g, "\\\\").replace(/`/g, "\\`").replace(/\$/g, "\\$");

  // Write app.html (full app)
  fs.writeFileSync(appHtmlPath, buildAppHTML(appTitle, escaped, bundle), "utf8");

  // 2. Generate landing page
  fs.writeFileSync(path.join(outDir, "index.html"), buildLandingHTML(appTitle, desc, author, filename), "utf8");

  // 3. Generate embed widget
  fs.writeFileSync(path.join(outDir, "embed.js"), buildEmbedJS(appTitle, escaped, bundle), "utf8");

  // 4. Generate simple README
  fs.writeFileSync(path.join(outDir, "README.md"), buildSiteReadme(appTitle, desc, outDir), "utf8");

  const totalSize = ["index.html", "app.html", "embed.js", "README.md"]
    .reduce((sum, f) => sum + (fs.statSync(path.join(outDir, f)).size || 0), 0);

  console.log(`\n✓ Site generated: ${outDir}/`);
  console.log(`  index.html  — landing page`);
  console.log(`  app.html    — the working app`);
  console.log(`  embed.js    — embeddable widget`);
  console.log(`  Total size: ${(totalSize / 1024).toFixed(0)} KB\n`);
  console.log(`Deploy options:`);
  console.log(`  GitHub Pages: push the folder, enable Pages in repo settings`);
  console.log(`  Netlify:      drag-and-drop the folder at netlify.com/drop`);
  console.log(`  Vercel:       run "npx vercel" inside the folder\n`);
}

// ── Landing Page HTML ─────────────────────────────────────────────────────
function buildLandingHTML(appTitle, desc, author, filename) {
  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>${appTitle}</title>
<meta name="description" content="${desc}">
<style>
  :root{--bg:#0f1117;--surface:#1a1d2e;--surface2:#242740;--accent:#6c63ff;--accent2:#00d4aa;--text:#e8eaf0;--text2:#9ca3b0;--border:#2d3150;}
  *{box-sizing:border-box;margin:0;padding:0;}
  body{background:var(--bg);color:var(--text);font-family:'Segoe UI',system-ui,sans-serif;min-height:100vh;}

  /* Nav */
  nav{background:var(--surface);border-bottom:1px solid var(--border);padding:16px 32px;display:flex;align-items:center;justify-content:space-between;}
  .nav-logo{font-size:18px;font-weight:700;color:var(--accent);}
  .nav-links{display:flex;gap:24px;}
  .nav-links a{color:var(--text2);text-decoration:none;font-size:14px;transition:color .2s;}
  .nav-links a:hover{color:var(--text);}

  /* Hero */
  .hero{text-align:center;padding:100px 32px 80px;background:linear-gradient(180deg,var(--surface) 0%,var(--bg) 100%);}
  .hero-badge{display:inline-block;background:rgba(108,99,255,.15);color:var(--accent);border:1px solid rgba(108,99,255,.3);border-radius:20px;padding:4px 14px;font-size:12px;font-weight:600;text-transform:uppercase;letter-spacing:1px;margin-bottom:20px;}
  .hero h1{font-size:52px;font-weight:800;line-height:1.15;margin-bottom:20px;background:linear-gradient(135deg,var(--text) 0%,var(--accent2) 100%);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;}
  .hero p{font-size:18px;color:var(--text2);max-width:560px;margin:0 auto 40px;line-height:1.6;}
  .cta-row{display:flex;gap:16px;justify-content:center;flex-wrap:wrap;}
  .btn-primary{background:linear-gradient(135deg,var(--accent),#8b5cf6);color:white;padding:14px 32px;border-radius:10px;text-decoration:none;font-size:15px;font-weight:600;transition:opacity .2s;}
  .btn-primary:hover{opacity:.9;}
  .btn-secondary{background:transparent;color:var(--text);border:1px solid var(--border);padding:14px 32px;border-radius:10px;text-decoration:none;font-size:15px;font-weight:500;transition:border-color .2s;}
  .btn-secondary:hover{border-color:var(--accent);}

  /* Preview */
  .preview{padding:60px 32px;max-width:900px;margin:0 auto;}
  .preview h2{font-size:28px;font-weight:700;text-align:center;margin-bottom:12px;}
  .preview p{text-align:center;color:var(--text2);margin-bottom:40px;}
  .app-frame{background:var(--surface);border:1px solid var(--border);border-radius:16px;overflow:hidden;box-shadow:0 20px 60px rgba(0,0,0,.4);}
  .frame-bar{background:var(--surface2);padding:12px 16px;display:flex;align-items:center;gap:8px;border-bottom:1px solid var(--border);}
  .dot{width:10px;height:10px;border-radius:50%;}
  .dot-red{background:#ff5f56;}.dot-yellow{background:#ffbd2e;}.dot-green{background:#27c93f;}
  .frame-url{background:var(--bg);border-radius:6px;padding:4px 12px;font-size:12px;color:var(--text2);margin-left:8px;}
  .frame-content{padding:32px;font-family:monospace;font-size:13px;color:var(--text2);line-height:1.8;max-height:280px;overflow:hidden;position:relative;}
  .frame-content::after{content:'';position:absolute;bottom:0;left:0;right:0;height:80px;background:linear-gradient(transparent,var(--surface));}
  .keyword{color:var(--accent);}
  .value{color:var(--accent2);}
  .comment{color:#5c6370;}
  .string{color:#98c379;}

  /* Features */
  .features{padding:60px 32px;max-width:1000px;margin:0 auto;}
  .features h2{font-size:28px;font-weight:700;text-align:center;margin-bottom:48px;}
  .features-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:24px;}
  .feature-card{background:var(--surface);border:1px solid var(--border);border-radius:12px;padding:28px;}
  .feature-icon{font-size:28px;margin-bottom:12px;}
  .feature-card h3{font-size:16px;font-weight:600;margin-bottom:8px;}
  .feature-card p{font-size:14px;color:var(--text2);line-height:1.6;}

  /* Built with */
  .built-with{text-align:center;padding:60px 32px;border-top:1px solid var(--border);}
  .built-with p{color:var(--text2);font-size:14px;}
  .built-with a{color:var(--accent);text-decoration:none;font-weight:600;}

  /* Responsive */
  @media(max-width:600px){
    .hero h1{font-size:36px;}
    nav{padding:12px 16px;}
    .preview,.features{padding:40px 16px;}
  }
</style>
</head>
<body>

<nav>
  <div class="nav-logo">Glang</div>
  <div class="nav-links">
    <a href="app.html">Open App</a>
    <a href="https://github.com/grewal/glang" target="_blank">GitHub</a>
  </div>
</nav>

<section class="hero">
  <div class="hero-badge">Built with Glang</div>
  <h1>${appTitle}</h1>
  <p>${desc}</p>
  <div class="cta-row">
    <a class="btn-primary" href="app.html">Open App →</a>
    <a class="btn-secondary" href="#features">Learn More</a>
  </div>
</section>

<section class="preview">
  <h2>See the Code</h2>
  <p>Built in Glang — the programming language designed for finance</p>
  <div class="app-frame">
    <div class="frame-bar">
      <div class="dot dot-red"></div>
      <div class="dot dot-yellow"></div>
      <div class="dot dot-green"></div>
      <div class="frame-url">${filename}.grw</div>
    </div>
    <div class="frame-content">
      <span class="comment"># ${appTitle} — built with Glang</span><br>
      <br>
      <span class="keyword">let</span> loan = <span class="value">₹500000</span><br>
      <span class="keyword">let</span> rate = <span class="value">8.5%</span><br>
      <span class="keyword">let</span> years = <span class="value">20</span><br>
      <br>
      show_card(<span class="string">"Monthly EMI"</span>, emi(loan, rate, years))<br>
      show_card(<span class="string">"Total Cost"</span>, total_loan_cost(loan, rate, years))<br>
      <br>
      <span class="keyword">let</span> s = stock(<span class="string">"TCS"</span>)<br>
      show(s.name + <span class="string">": "</span> + str(s.price))<br>
    </div>
  </div>
</section>

<section class="features" id="features">
  <h2>What makes this special</h2>
  <div class="features-grid">
    <div class="feature-card">
      <div class="feature-icon">💰</div>
      <h3>Native Finance Types</h3>
      <p>₹, $, €, £ and % are real types. <code>₹500000 * 8.5%</code> just works — no imports, no type juggling.</p>
    </div>
    <div class="feature-card">
      <div class="feature-icon">📊</div>
      <h3>Built-in Calculations</h3>
      <p>EMI, SIP, CAGR, NPV, IRR, tax — all built in. One line of code for any financial calculation.</p>
    </div>
    <div class="feature-card">
      <div class="feature-icon">📈</div>
      <h3>Live Stock Data</h3>
      <p>Access NSE & NASDAQ data with <code>stock("TCS").price</code>. No API keys, no setup.</p>
    </div>
    <div class="feature-card">
      <div class="feature-icon">🌐</div>
      <h3>Runs Anywhere</h3>
      <p>Script, web app, or shareable HTML — the same .grw file works in all three modes.</p>
    </div>
    <div class="feature-card">
      <div class="feature-icon">🇮🇳</div>
      <h3>India-First</h3>
      <p>Indian tax slabs, ₹ formatting (lakh/crore), NSE stocks — built for the Indian finance professional.</p>
    </div>
    <div class="feature-card">
      <div class="feature-icon">📦</div>
      <h3>Importable Modules</h3>
      <p><code>import finance</code>, <code>import tax</code>, <code>import stocks</code> — extend with community packages.</p>
    </div>
  </div>
</section>

<div class="built-with">
  <p>Built by <strong>${author}</strong> with <a href="https://github.com/grewal/glang" target="_blank">Glang</a> — the programming language for finance</p>
</div>

</body>
</html>`;
}

// ── App HTML (same as share but embedded in site) ─────────────────────────
function buildAppHTML(appTitle, escapedSource, bundle) {
  // Reuse the share HTML builder
  const shareModule = require("./share.js");
  // share.js reads from file system — we need to build HTML directly
  // Use the same template but pass source directly
  const fs = require("fs");
  const tmp = require("os").tmpdir() + "/_glang_site_tmp.grw";
  // Write unescaped source back temporarily
  const unescaped = escapedSource
    .replace(/\\`/g, "`")
    .replace(/\\\$/g, "$")
    .replace(/\\\\/g, "\\");
  fs.writeFileSync(tmp, unescaped, "utf8");
  const html = shareModule._buildShareHTML ? shareModule._buildShareHTML(appTitle, unescaped, bundle) : null;
  fs.unlinkSync(tmp);

  if (html) return html;

  // Fallback: redirect to the share approach
  return `<!DOCTYPE html><html><head><meta http-equiv="refresh" content="0;url=app.html"></head><body>Loading...</body></html>`;
}

// ── Embed widget JS ───────────────────────────────────────────────────────
function buildEmbedJS(appTitle, escapedSource, bundle) {
  return `// Glang Embed Widget — ${appTitle}
// Add to any website:
// <div id="glang-widget"></div>
// <script src="embed.js"></script>

(function() {
  const TITLE = ${JSON.stringify(appTitle)};
  const SOURCE = \`${escapedSource}\`;

  // Load the Glang runtime
  ${bundle}

  // Find or create mount point
  const mount = document.getElementById("glang-widget") || document.body;

  // Inject styles
  const style = document.createElement("style");
  style.textContent = \`
    .glang-widget{background:#1a1d2e;border:1px solid #2d3150;border-radius:12px;overflow:hidden;font-family:'Segoe UI',system-ui,sans-serif;max-width:600px;}
    .glang-widget-header{background:#242740;padding:12px 16px;display:flex;align-items:center;gap:8px;}
    .glang-widget-logo{font-size:14px;font-weight:700;color:#6c63ff;}
    .glang-widget-title{font-size:14px;font-weight:600;color:#e8eaf0;}
    .glang-widget-body{padding:20px;}
    .glang-widget-field{margin-bottom:12px;}
    .glang-widget-field label{display:block;font-size:12px;color:#9ca3b0;margin-bottom:4px;}
    .glang-widget-field input{width:100%;background:#0f1117;border:1px solid #2d3150;border-radius:6px;padding:8px 10px;color:#e8eaf0;font-size:13px;}
    .glang-widget-btn{width:100%;background:linear-gradient(135deg,#6c63ff,#8b5cf6);color:white;border:none;border-radius:6px;padding:10px;font-size:13px;font-weight:600;cursor:pointer;margin-top:8px;}
    .glang-widget-output{margin-top:16px;font-size:13px;color:#e8eaf0;}
    .glang-widget-card{background:#242740;border-radius:8px;padding:12px;margin-bottom:8px;}
    .glang-widget-card-title{font-size:11px;color:#9ca3b0;text-transform:uppercase;letter-spacing:.5px;}
    .glang-widget-card-value{font-size:20px;font-weight:700;color:#00d4aa;}
    .glang-widget-text{font-size:13px;color:#e8eaf0;padding:2px 0;font-family:monospace;}
  \`;
  document.head.appendChild(style);

  // Build widget HTML
  mount.innerHTML = \`
    <div class="glang-widget">
      <div class="glang-widget-header">
        <span class="glang-widget-logo">Glang</span>
        <span class="glang-widget-title">\${TITLE}</span>
      </div>
      <div class="glang-widget-body">
        <div id="glang-fields"></div>
        <button class="glang-widget-btn" onclick="glangRun()">▶ Calculate</button>
        <div class="glang-widget-output" id="glang-output"></div>
      </div>
    </div>
  \`;

  // Discover fields
  let fields = [];
  try {
    const { runInBrowser } = GlangRuntime;
    const { inputFields } = runInBrowser(SOURCE, {});
    fields = inputFields;
  } catch(e) {}

  // Build form
  const fieldsDiv = document.getElementById("glang-fields");
  if (fieldsDiv && fields.length) {
    fieldsDiv.innerHTML = fields.map(f =>
      \`<div class="glang-widget-field"><label>\${f.name}</label><input id="gf_\${f.key}" placeholder="\${f.type === 'money' ? 'e.g. 500000' : 'e.g. 8.5'}" value="\${f.default || ''}" /></div>\`
    ).join("");
  }

  window.glangRun = function() {
    const inputs = {};
    fields.forEach(f => {
      const el = document.getElementById("gf_" + f.key);
      if (el) inputs[f.key] = el.value;
    });
    try {
      const { runInBrowser } = GlangRuntime;
      const { elements } = runInBrowser(SOURCE, inputs);
      const out = document.getElementById("glang-output");
      if (!out) return;
      out.innerHTML = elements.map(el => {
        if (el.type === "card") return \`<div class="glang-widget-card"><div class="glang-widget-card-title">\${el.title}</div><div class="glang-widget-card-value">\${el.value}</div></div>\`;
        if (el.type === "text") return \`<div class="glang-widget-text">\${el.content}</div>\`;
        return "";
      }).join("");
    } catch(e) {
      const out = document.getElementById("glang-output");
      if (out) out.innerHTML = \`<div style="color:#ff6b6b;font-size:13px;">\${e.message}</div>\`;
    }
  };
})();`;
}

// ── README ────────────────────────────────────────────────────────────────
function buildSiteReadme(appTitle, desc, outDir) {
  return `# ${appTitle} — Site

Generated by \`glang site\`.

## Files

- \`index.html\` — Landing page
- \`app.html\`   — The working calculator app
- \`embed.js\`   — Embeddable widget for other websites
- \`README.md\`  — This file

## Deploy

**Netlify (fastest):** Drag this folder to [netlify.com/drop](https://netlify.com/drop)

**GitHub Pages:**
1. Push this folder to a GitHub repo
2. Go to Settings → Pages → Deploy from branch

**Vercel:**
\`\`\`bash
cd ${path.basename(outDir)}
npx vercel
\`\`\`

## Embed on another website

Add to any HTML page:
\`\`\`html
<div id="glang-widget"></div>
<script src="embed.js"></script>
\`\`\`
`;
}

module.exports = { generateSite };
