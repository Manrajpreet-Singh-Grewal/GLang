// Glang Scaffold — Phase 5
// glang new my-project → creates a ready-to-run Glang project

const fs   = require("fs");
const path = require("path");

const BOLD  = "\x1b[1m";
const CYAN  = "\x1b[36m";
const GREEN = "\x1b[32m";
const RESET = "\x1b[0m";

const TEMPLATES = {
  "loan-calculator": {
    desc: "Home/personal loan EMI + interest breakdown",
    file: "loan_calculator.grw",
    code: `# Loan Calculator — built with Glang
# Run as script:  glang run loan_calculator.grw
# Run as web app: glang app loan_calculator.grw
# Share as HTML:  glang share loan_calculator.grw

let principal = input("Loan Amount", "money")
let rate      = input("Annual Interest Rate", "percent")
let years     = input("Tenure (years)", "number")

show_heading("Loan Summary")
show_card("Monthly EMI",      emi(principal, rate, years),            "per month")
show_card("Total Payable",    total_loan_cost(principal, rate, years), format_inr(total_loan_cost(principal, rate, years)))
show_card("Total Interest",   loan_interest_paid(principal, rate, years), "paid to bank")

divider()
show_heading("Amortization (first 12 months)")
let schedule = loan_schedule(principal, rate, years)
let month = 0
for entry in schedule:
    if month < 12:
        show(entry)
    month = month + 1
`,
  },
  "portfolio-tracker": {
    desc: "Stock portfolio P&L tracker with live prices",
    file: "portfolio.grw",
    code: `# Portfolio Tracker — built with Glang
# Edit my_stocks, bought_at, quantity below with your actual holdings
# Run: glang app portfolio.grw

let my_stocks = ["TCS",    "RELIANCE", "INFY",   "HDFC"]
let bought_at = [₹3200,   ₹2700,      ₹1400,    ₹1580]
let quantity  = [10,       15,          20,        12]

show_heading("My Portfolio")

let total_invested = ₹0
let total_current  = ₹0
let i = 0

for sym in my_stocks:
    let s       = stock(sym)
    let buy     = bought_at[i]
    let qty     = quantity[i]
    let invested = buy * qty
    let current  = s.price * qty
    let returns  = percent_change(buy, s.price)

    show(s.name + " — " + str(qty) + " shares")
    show("  Buy: " + str(buy) + " | Now: " + str(s.price) + " | Return: " + str(returns))
    show("")

    total_invested = total_invested + invested
    total_current  = total_current + current
    i = i + 1

divider()
show_card("Total Invested",    total_invested, format_inr(total_invested))
show_card("Current Value",     total_current,  format_inr(total_current))
show_card("Overall Return",    percent_change(total_invested, total_current), "gain/loss")

divider()
show_heading("Market Today")
compare_stocks([stock("TCS"), stock("RELIANCE"), stock("INFY"), stock("HDFC"), stock("SBIN")])
`,
  },
  "sip-planner": {
    desc: "Retirement & SIP goal planning calculator",
    file: "sip_planner.grw",
    code: `# SIP Retirement Planner — built with Glang
# glang app sip_planner.grw

let monthly_sip    = input("Monthly SIP Amount", "money")
let expected_return = input("Expected Annual Return", "percent")
let years          = input("Investment Duration (years)", "number")
let goal           = input("Target Corpus", "money")
let inflation      = input("Expected Inflation", "percent")

show_heading("SIP Projection")

let corpus         = sip(monthly_sip, expected_return, years)
let invested       = sip_invested(monthly_sip, years)
let real_value     = inflation_adjust(corpus, inflation, years)
let monthly_needed = sip_goal(goal, expected_return, years)

show_card("Corpus at Maturity",    corpus,         format_inr(corpus))
show_card("Total Invested",        invested,        format_inr(invested))
show_card("Real Value (adj.)",     real_value,      "inflation adjusted")
show_card("SIP for Your Goal",     monthly_needed,  "per month")

divider()
show_heading("Year-wise Growth")
let balance = ₹0
let year = 1
repeat years times:
    balance = sip(monthly_sip, expected_return, year)
    show("Year " + str(year) + ": " + str(balance) + " (" + format_inr(balance) + ")")
    year = year + 1
`,
  },
  "tax-calculator": {
    desc: "Indian income tax calculator (new regime)",
    file: "tax_calculator.grw",
    code: `# Indian Tax Calculator — built with Glang (FY 2024-25, New Regime)
# glang app tax_calculator.grw

let gross_salary = input("Annual Gross Salary", "money")

show_heading("Tax Breakdown (New Regime FY2024-25)")

let tax_amount = tax(gross_salary)
let take_home  = take_home(gross_salary)
let monthly_th = take_home(gross_salary) + (take_home(gross_salary) * -1) + take_home(gross_salary)

show_card("Annual Tax",       tax_amount,  "including 4% cess")
show_card("Annual Take Home", take_home,   format_inr(take_home))

divider()
show_heading("Tax at Different Salary Levels")
show_table(
    ["Salary", "Tax", "Take Home", "Effective Rate"],
    [
        [str(₹600000),  str(tax(₹600000)),  str(take_home(₹600000)),  str(percent_change(₹600000,  ₹600000 + (tax(₹600000) * -1)))],
        [str(₹1000000), str(tax(₹1000000)), str(take_home(₹1000000)), str(percent_change(₹1000000, ₹1000000 + (tax(₹1000000) * -1)))],
        [str(₹1500000), str(tax(₹1500000)), str(take_home(₹1500000)), str(percent_change(₹1500000, ₹1500000 + (tax(₹1500000) * -1)))],
        [str(₹2000000), str(tax(₹2000000)), str(take_home(₹2000000)), str(percent_change(₹2000000, ₹2000000 + (tax(₹2000000) * -1)))],
        [str(₹3000000), str(tax(₹3000000)), str(take_home(₹3000000)), str(percent_change(₹3000000, ₹3000000 + (tax(₹3000000) * -1)))],
    ]
)
`,
  },
};

const README_TEMPLATE = (name, templateKey, templateDesc) => `# ${name}

A financial app built with **Glang** — the programming language for finance.

## What this does
${templateDesc}

## Run it

\`\`\`bash
# As a command-line script
glang run ${TEMPLATES[templateKey].file}

# As a web app (opens in browser)
glang app ${TEMPLATES[templateKey].file}

# Share as a single HTML file (no installation needed)
glang share ${TEMPLATES[templateKey].file}
\`\`\`

## Customise it

Open \`${TEMPLATES[templateKey].file}\` in any text editor and change the numbers or add your own calculations. The [Glang language reference](GLANG.md) has all the built-in functions.

## Built with Glang

Glang is a programming language designed for finance — with native currency types (₹ \$ € £), percentage types, and built-in financial functions (EMI, SIP, CAGR, NPV, and more).
`;

function scaffold(projectName) {
  const templateKey = Object.keys(TEMPLATES)[0]; // default: loan-calculator
  scaffold_with(projectName, templateKey);
}

function scaffold_with(projectName, templateKey) {
  const template = TEMPLATES[templateKey] || TEMPLATES["loan-calculator"];
  const dir = path.resolve(projectName);

  if (fs.existsSync(dir)) {
    console.error(`Folder "${projectName}" already exists.`);
    process.exit(1);
  }

  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(path.join(dir, template.file), template.code, "utf8");
  fs.writeFileSync(path.join(dir, "README.md"), README_TEMPLATE(projectName, templateKey, template.desc), "utf8");

  console.log(`\n${GREEN}✓ Created: ${projectName}/${RESET}`);
  console.log(`  ${CYAN}${template.file}${RESET}  — ${template.desc}`);
  console.log(`  README.md`);
  console.log(`\n${BOLD}Get started:${RESET}`);
  console.log(`  cd ${projectName}`);
  console.log(`  glang run ${template.file}        # run as script`);
  console.log(`  glang app ${template.file}        # run as web app`);
  console.log(`  glang share ${template.file}      # export shareable HTML`);
  console.log(`\n${BOLD}Available templates:${RESET}`);
  Object.entries(TEMPLATES).forEach(([k, t]) => {
    console.log(`  glang new ${projectName} --template ${k}  # ${t.desc}`);
  });
  console.log("");
}

module.exports = { scaffold, scaffold_with, TEMPLATES };
