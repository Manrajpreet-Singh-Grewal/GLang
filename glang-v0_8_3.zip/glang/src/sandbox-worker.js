// Glang Sandbox Worker
// Runs inside a worker_thread (see sandbox.js), never on the main server
// thread. Each request to `glang app` gets a brand new Worker with its own
// V8 isolate and heap, so:
//   - one student's script can't see or touch another's variables/state
//     (each Worker is a fully separate JS environment)
//   - a memory-hungry script hits the isolate's own heap limit (set by the
//     caller via resourceLimits) instead of the shared server process's
//   - a runaway script can be killed with worker.terminate() from the
//     controller without taking the server down with it
//
// This file does the minimum possible: run the program, hand back the
// result (or an error) over postMessage. All the sandboxing itself lives
// in how the Worker is *constructed* — see sandbox.js.

const { parentPort, workerData } = require("worker_threads");
const { runApp } = require("./app.js");

try {
  const { source, filename, inputs } = workerData;
  const result = runApp(source, filename, inputs || {});
  parentPort.postMessage({ ok: true, result });
} catch (err) {
  // runApp() already catches Glang syntax/runtime errors internally and
  // turns them into alert elements, so reaching here means something
  // unexpected happened (an actual bug, or the process running out of
  // resources mid-call). Report it rather than letting the worker crash
  // silently.
  parentPort.postMessage({ ok: false, error: (err && err.message) || String(err) });
}
