const { GlangSyntaxError } = require("./lexer.js");
const fs = require("fs");
const path = require("path");

// Glang Interpreter
// A tree-walking interpreter: walks the AST produced by the parser and
// executes it directly. This is Phase 1 — fast to build, easy to debug,
// and lets us prove out language semantics (especially the currency/percent
// type rules and the plain-English error system) before building a bytecode
// VM in Phase 2.

const CURRENCY_SYMBOL_BY_CODE = {
  USD: "$",
  INR: "₹",
  EUR: "€",
  GBP: "£",
};

// --- Runtime value wrappers --------------------------------------------
// Glang values are either: JS number, JS string, JS boolean, GlangCurrency,
// GlangPercent, or GlangFunction. We wrap currency/percent so we can carry
// type info (e.g. which currency) through arithmetic.

class GlangCurrency {
  constructor(amount, currency) {
    this.amount = amount;
    this.currency = currency;
  }
  toString() {
    const symbol = CURRENCY_SYMBOL_BY_CODE[this.currency] || "";
    // Round to 2 decimal places for display, like real money
    const rounded = Math.round((this.amount + Number.EPSILON) * 100) / 100;
    const sign = rounded < 0 ? "-" : "";
    const formatted = Math.abs(rounded).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    return `${sign}${symbol}${formatted}`;
  }
}

class GlangPercent {
  constructor(value) {
    this.value = value; // stored as a decimal, e.g. 5% -> 0.05
  }
  toString() {
    const pct = Math.round((this.value * 100 + Number.EPSILON) * 100) / 100;
    return `${pct}%`;
  }
}

class GlangFunction {
  constructor(decl, closure) {
    this.decl = decl; // FnDecl AST node
    this.closure = closure; // Environment captured at definition time
  }
}

class GlangList {
  constructor(items) {
    this.items = items; // plain JS array of Glang values
  }
  toString() {
    return "[" + this.items.map(describeValue).join(", ") + "]";
  }
}

// Dictionary / key-value object, e.g. {name: "Alex", age: 30}
// Keys are always plain JS strings (bareword or quoted keys both normalize
// to strings); values can be any Glang value.
class GlangDict {
  constructor(map) {
    this.map = map; // JS Map<string, GlangValue>
  }
  toString() {
    const entries = [...this.map.entries()].map(
      ([k, v]) => `${k}: ${describeValue(v)}`
    );
    return "{" + entries.join(", ") + "}";
  }
}

// Module namespace — created when you do: import finance as fin
// Allows fin.function_name() syntax
class GlangNamespace {
  constructor(name, exports) {
    this.name = name;       // module name e.g. "finance"
    this.exports = exports; // Map of exported names → values
  }
  get(key) {
    return this.exports.get ? this.exports.get(key) : this.exports[key];
  }
  toString() { return `<module "${this.name}">`; }
}

// Sentinel used to unwind the call stack on `return`
class ReturnSignal {
  constructor(value) {
    this.value = value;
  }
}

// Sentinels used to unwind loop bodies on `break` / `continue`
class BreakSignal {}
class ContinueSignal {}

// ── PHASE 3: Stock type ──────────────────────────────────────────────────
// GlangStock wraps a stock symbol. Data is fetched synchronously via
// Yahoo Finance when the user accesses properties like .price or .pe.
// On the user's machine (no network restrictions) this gives live data.
// In restricted environments it falls back to realistic mock data with a warning.

const MOCK_STOCKS = {
  "TCS":        { price: 3842.50, prev: 3798.20, pe: 28.4, high52: 4592.25, low52: 3311.80, volume: 1823456, marketCap: 1389000000000, currency: "INR", name: "Tata Consultancy Services", sector: "IT", exchange: "NSE" },
  "RELIANCE":   { price: 2934.75, prev: 2901.30, pe: 23.1, high52: 3217.90, low52: 2220.30, volume: 5621000, marketCap: 1987000000000, currency: "INR", name: "Reliance Industries",       sector: "Energy", exchange: "NSE" },
  "INFY":       { price: 1678.40, prev: 1645.90, pe: 24.7, high52: 1953.90, low52: 1358.35, volume: 3912000, marketCap: 697000000000,  currency: "INR", name: "Infosys",                    sector: "IT", exchange: "NSE" },
  "HDFC":       { price: 1723.60, prev: 1698.75, pe: 19.8, high52: 1880.00, low52: 1363.55, volume: 2341000, marketCap: 1302000000000, currency: "INR", name: "HDFC Bank",                  sector: "Banking", exchange: "NSE" },
  "SBIN":       { price: 812.35,  prev: 798.60,  pe: 11.2, high52: 912.10,  low52: 543.20,  volume: 18234000,marketCap: 725000000000,  currency: "INR", name: "State Bank of India",        sector: "Banking", exchange: "NSE" },
  "WIPRO":      { price: 489.70,  prev: 502.15,  pe: 20.3, high52: 571.85,  low52: 376.45,  volume: 4512000, marketCap: 256000000000,  currency: "INR", name: "Wipro",                      sector: "IT", exchange: "NSE" },
  "BAJFINANCE": { price: 7123.45, prev: 7089.20, pe: 32.6, high52: 8190.00, low52: 6187.90, volume: 892000,  marketCap: 428000000000,  currency: "INR", name: "Bajaj Finance",              sector: "Finance", exchange: "NSE" },
  "ICICIBANK":  { price: 1312.80, prev: 1287.45, pe: 17.4, high52: 1438.20, low52: 998.75,  volume: 9823000, marketCap: 924000000000,  currency: "INR", name: "ICICI Bank",                 sector: "Banking", exchange: "NSE" },
  "TATAMOTORS": { price: 923.60,  prev: 889.30,  pe: 14.2, high52: 1179.05, low52: 782.35,  volume: 8934000, marketCap: 339000000000,  currency: "INR", name: "Tata Motors",               sector: "Auto", exchange: "NSE" },
  "HCLTECH":    { price: 1567.80, prev: 1589.40, pe: 26.1, high52: 1978.45, low52: 1235.10, volume: 3241000, marketCap: 425000000000,  currency: "INR", name: "HCL Technologies",          sector: "IT", exchange: "NSE" },
  "MARUTI":     { price: 12340.50,prev:12180.25, pe: 28.9, high52: 13680.00,low52: 9460.30, volume: 412000,  marketCap: 383000000000,  currency: "INR", name: "Maruti Suzuki",             sector: "Auto", exchange: "NSE" },
  "AAPL":       { price: 213.45,  prev: 209.82,  pe: 33.2, high52: 237.23,  low52: 164.08,  volume: 52341000,marketCap: 3270000000000, currency: "USD", name: "Apple Inc.",                 sector: "Technology", exchange: "NASDAQ" },
  "GOOGL":      { price: 178.92,  prev: 175.40,  pe: 24.8, high52: 208.70,  low52: 130.67,  volume: 18234000,marketCap: 2210000000000, currency: "USD", name: "Alphabet Inc.",              sector: "Technology", exchange: "NASDAQ" },
  "MSFT":       { price: 432.17,  prev: 428.90,  pe: 36.1, high52: 468.35,  low52: 309.45,  volume: 21456000,marketCap: 3213000000000, currency: "USD", name: "Microsoft Corp.",            sector: "Technology", exchange: "NASDAQ" },
};

// Generates realistic mock historical prices using random walk seeded from symbol
function generateMockHistory(basePrice, days, symbol) {
  const seed = symbol.split("").reduce((a, c) => a + c.charCodeAt(0), 0);
  let price = basePrice * 0.85; // start ~15% below current
  const history = [];
  for (let i = days; i >= 0; i--) {
    const pseudoRandom = Math.sin(seed * (i + 1) * 0.1) * 0.5 + 0.5;
    const change = (pseudoRandom - 0.48) * 0.02;
    price = price * (1 + change);
    history.push(Math.round(price * 100) / 100);
  }
  history[history.length - 1] = basePrice; // ensure last = current price
  return history;
}

// Only letters, digits, '.', and '-' are legitimate in a stock ticker
// (e.g. "TCS", "RELIANCE.NS", "BRK-B"). Anything else is rejected before
// it ever touches a URL or a subprocess call, so a symbol can never be
// used to smuggle shell metacharacters through to curl.
const TICKER_PATTERN = /^[A-Za-z0-9.\-]{1,20}$/;

function assertSafeTicker(symbol, line) {
  if (!TICKER_PATTERN.test(symbol)) {
    throw new GlangRuntimeError(
      `"${symbol}" isn't a valid stock symbol.`,
      line,
      `Stock symbols can only contain letters, numbers, ".", and "-", like "TCS" or "RELIANCE.NS".`
    );
  }
}

// Fetch a URL without ever going through a shell: execFileSync runs the
// binary directly with an argument array, so nothing in `url` (which is
// partly built from user-controlled input) can be interpreted as shell
// syntax, no matter what characters it contains.
function curlGet(url, timeoutMs) {
  const { execFileSync } = require("child_process");
  return execFileSync(
    "curl",
    ["-s", "--max-time", String(Math.ceil(timeoutMs / 1000)), url, "-H", "User-Agent: Mozilla/5.0"],
    { timeout: timeoutMs }
  ).toString();
}

class GlangStock {
  constructor(symbol, line) {
    this.symbol = symbol;
    this.line = line;
    this._data = null;
    this._isMock = false;
    this._history = {};
  }

  _fetch() {
    if (this._data) return;
    assertSafeTicker(this.symbol, this.line);
    try {
      const ticker = this.symbol.includes(".") ? this.symbol : this.symbol + ".NS";
      const url = `https://query1.finance.yahoo.com/v8/finance/chart/${ticker}?interval=1d&range=5d`;
      const result = curlGet(url, 6000);
      const json = JSON.parse(result);
      const meta = json.chart.result[0].meta;
      const prev = meta.chartPreviousClose || meta.previousClose || meta.regularMarketPrice;
      this._data = {
        price:     meta.regularMarketPrice,
        prev:      prev,
        pe:        meta.trailingPE || null,
        high52:    meta.fiftyTwoWeekHigh,
        low52:     meta.fiftyTwoWeekLow,
        volume:    meta.regularMarketVolume,
        marketCap: meta.marketCap || null,
        currency:  meta.currency === "INR" ? "INR" : "USD",
        name:      meta.longName || meta.shortName || this.symbol,
        sector:    meta.sector || "Unknown",
        exchange:  meta.exchangeName || "NSE",
      };
    } catch (e) {
      const key = this.symbol.replace(".NS", "").replace(".BSE", "");
      if (MOCK_STOCKS[key]) {
        this._data = { ...MOCK_STOCKS[key] };
        this._isMock = true;
      } else {
        throw new GlangRuntimeError(
          `Couldn't find stock data for "${this.symbol}".`,
          this.line,
          `Try a known symbol like "TCS", "RELIANCE", "INFY", "HDFC", "SBIN", "AAPL", "MSFT".`
        );
      }
    }
  }

  _fetchHistory(days) {
    if (this._history[days]) return this._history[days];
    assertSafeTicker(this.symbol, this.line);
    try {
      const ticker = this.symbol.includes(".") ? this.symbol : this.symbol + ".NS";
      const url = `https://query1.finance.yahoo.com/v8/finance/chart/${ticker}?interval=1d&range=${days}d`;
      const result = curlGet(url, 9000);
      const json = JSON.parse(result);
      const closes = json.chart.result[0].indicators.quote[0].close;
      this._history[days] = closes.filter(Boolean).map(p => Math.round(p * 100) / 100);
    } catch (e) {
      this._fetch();
      this._history[days] = generateMockHistory(this._data.price, days, this.symbol);
    }
    return this._history[days];
  }

  getPrice()    { this._fetch(); return this._data.price; }
  getPrev()     { this._fetch(); return this._data.prev; }
  getChange()   { this._fetch(); return this._data.price - this._data.prev; }
  getChangePct(){ this._fetch(); return (this._data.price - this._data.prev) / this._data.prev; }
  getPE()       { this._fetch(); return this._data.pe; }
  getHigh52()   { this._fetch(); return this._data.high52; }
  getLow52()    { this._fetch(); return this._data.low52; }
  getVolume()   { this._fetch(); return this._data.volume; }
  getMarketCap(){ this._fetch(); return this._data.marketCap; }
  getCurrency() { this._fetch(); return this._data.currency; }
  getName()     { this._fetch(); return this._data.name; }
  getSector()   { this._fetch(); return this._data.sector; }
  getExchange() { this._fetch(); return this._data.exchange; }
  isMock()      { this._fetch(); return this._isMock; }
  getHistory(days) { return this._fetchHistory(days); }

  toString() {
    try {
      this._fetch();
      const c = new GlangCurrency(this._data.price, this._data.currency);
      const chg = this.getChangePct() * 100;
      const sign = chg >= 0 ? "+" : "";
      return `${this.symbol} @ ${c.toString()} (${sign}${chg.toFixed(2)}%)${this._isMock ? " [demo]" : ""}`;
    } catch(e) { return `stock("${this.symbol}")`; }
  }
}

// --- The error type the whole language is built around ------------------
// Every runtime error carries: a clear message, the line it happened on,
// and a hint suggesting a fix. The CLI renderer (see runner) turns this
// into the "Oops! ... Try this instead: ... Why? ..." format.

class GlangRuntimeError extends Error {
  constructor(message, line, hint) {
    super(message);
    this.name = "GlangRuntimeError";
    this.line = line;
    this.hint = hint;
  }
}

// Wraps a value thrown by user code (`throw "message"` or `throw {...}`)
// so it can travel up through JS's exception machinery and be told apart
// from a genuine Glang engine error when it reaches a `catch`.
class GlangThrownValue extends Error {
  constructor(value, line) {
    super(typeof value === "string" ? value : "Glang value thrown");
    this.name = "GlangThrownValue";
    this.value = value;
    this.line = line;
  }
}

// --- Environment (variable scoping) --------------------------------------

class Environment {
  constructor(parent = null) {
    this.vars = new Map();
    this.consts = null; // lazily-created Set of names declared with 'const'
    this.parent = parent;
  }

  define(name, value) {
    this.vars.set(name, value);
  }

  defineConst(name, value) {
    this.vars.set(name, value);
    if (!this.consts) this.consts = new Set();
    this.consts.add(name);
  }

  get(name, line) {
    if (this.vars.has(name)) return this.vars.get(name);
    if (this.parent) return this.parent.get(name, line);
    throw new GlangRuntimeError(
      `There's no variable called "${name}" yet.`,
      line,
      `Did you forget to create it first with "let ${name} = ..." — or is there a typo in the name?`
    );
  }

  assign(name, value, line) {
    if (this.vars.has(name)) {
      if (this.consts && this.consts.has(name)) {
        throw new GlangRuntimeError(
          `"${name}" is a constant and can't be changed.`,
          line,
          `Constants are declared with "const" and always keep their first value. Use "let ${name} = ..." instead if you need it to change.`
        );
      }
      this.vars.set(name, value);
      return;
    }
    if (this.parent) {
      this.parent.assign(name, value, line);
      return;
    }
    throw new GlangRuntimeError(
      `Can't update "${name}" because it doesn't exist yet.`,
      line,
      `Create it first with "let ${name} = ..." before changing it.`
    );
  }
}

// --- Type naming, for friendly error messages -----------------------------

function typeName(value) {
  if (typeof value === "number") return "a number";
  if (typeof value === "string") return "a word (text)";
  if (typeof value === "boolean") return "true/false";
  if (value instanceof GlangCurrency) return `money (${value.currency})`;
  if (value instanceof GlangPercent) return "a percentage";
  if (value instanceof GlangFunction) return "a function";
  if (value instanceof GlangList) return "a list";
  if (value instanceof GlangDict) return "a dictionary";
  if (value instanceof GlangStock) return `a stock (${value.symbol})`;
  if (value instanceof GlangNamespace) return `module "${value.name}"`;
  return "something unexpected";
}

function describeValue(value) {
  if (value instanceof GlangCurrency) return value.toString();
  if (value instanceof GlangPercent) return value.toString();
  if (value instanceof GlangList) return value.toString();
  if (value instanceof GlangDict) return value.toString();
  if (typeof value === "string") return `"${value}"`;
  return String(value);
}

// --- Interpreter --------------------------------------------------------

// How many nested function calls Glang allows before it gives up with a
// friendly error. This is intentionally well below Node's real call-stack
// limit so we always catch runaway recursion ourselves and explain it,
// instead of letting a raw "Maximum call stack size exceeded" RangeError
// (with a Node/JS stack trace) leak out to the user.
const MAX_CALL_DEPTH = 500;
const MAX_LOOP_ITERATIONS = 10000000; // 10 million — generous, but catches infinite `while` loops

class Interpreter {
  constructor(options = {}) {
    this.globals = new Environment();
    this.callDepth = 0;
    // Module system state (see execImport): resolves local `.grw` imports
    // relative to the importing file's own directory (not process cwd),
    // caches each module's exports per absolute path so a module shared
    // by several files only runs once, and detects import cycles.
    this.moduleCache = new Map();       // absolute path -> exports Map
    this.moduleImportStack = [];        // absolute paths currently loading
    this.baseDirStack = [process.cwd()]; // resolution base for relative imports/paths
    // File I/O (read_file/write_file/etc.) is only registered for the
    // plain CLI interpreter. `glang app` runs scripts inside a sandboxed
    // worker specifically so untrusted/shared scripts can't touch the
    // host filesystem (see AppInterpreter in src/app.js, which passes
    // allowFileIO: false) — giving those scripts file access would
    // undermine that sandboxing entirely. See CHANGELOG.md for the full
    // reasoning.
    this.allowFileIO = options.allowFileIO !== false;
    this.setupBuiltins();
  }

  // Directory that relative imports/file paths should currently resolve
  // against — the running script's own directory by default, or the
  // directory of whichever module is currently being loaded.
  currentBaseDir() {
    return this.baseDirStack[this.baseDirStack.length - 1];
  }

  setupBuiltins() {

    // ── Helpers ──────────────────────────────────────────────────────────
    const requireArgs = (name, args, count, line, example) => {
      if (args.length !== count) {
        throw new GlangRuntimeError(
          `${name}() expects ${count} value${count === 1 ? "" : "s"}, but got ${args.length}.`,
          line, example
        );
      }
    };

    const requireCurrency = (name, val, argLabel, line) => {
      if (!(val instanceof GlangCurrency)) {
        throw new GlangRuntimeError(
          `${name}() needs ${argLabel} to be a money value (like ₹50000 or $1000), but got ${typeName(val)}.`,
          line, `Example: ${name}(₹500000, 8.5%, 20)`
        );
      }
    };

    const requirePercent = (name, val, argLabel, line) => {
      if (!(val instanceof GlangPercent)) {
        throw new GlangRuntimeError(
          `${name}() needs ${argLabel} to be a percentage (like 8.5%), but got ${typeName(val)}.`,
          line, `Example: ${name}(₹500000, 8.5%, 20)`
        );
      }
    };

    const requireNumber = (name, val, argLabel, line) => {
      if (typeof val !== "number") {
        throw new GlangRuntimeError(
          `${name}() needs ${argLabel} to be a plain number, but got ${typeName(val)}.`,
          line, null
        );
      }
    };

    const requireList = (name, val, argLabel, line) => {
      if (!(val instanceof GlangList)) {
        throw new GlangRuntimeError(
          `${name}() needs ${argLabel} to be a list, but got ${typeName(val)}.`,
          line, `Example: ${name}([₹10000, ₹20000, ₹30000])`
        );
      }
    };

    const requireCurrencyList = (name, list, line) => {
      for (const item of list.items) {
        if (!(item instanceof GlangCurrency)) {
          throw new GlangRuntimeError(
            `${name}() needs a list of money values, but found ${typeName(item)} (${describeValue(item)}) inside the list.`,
            line, `Make sure every item in the list is a money value like ₹10000 or $500.`
          );
        }
      }
      if (list.items.length === 0) {
        throw new GlangRuntimeError(
          `${name}() received an empty list — needs at least one value.`,
          line, null
        );
      }
      const currencies = [...new Set(list.items.map(i => i.currency))];
      if (currencies.length > 1) {
        throw new GlangRuntimeError(
          `${name}() found mixed currencies in the list (${currencies.join(" and ")}) — all items must use the same currency.`,
          line, `Convert everything to one currency first.`
        );
      }
      return currencies[0];
    };

    // ── Core output / conversion ─────────────────────────────────────────

    this.globals.define("show", {
      __builtin__: true, name: "show",
      call: (args) => {
        console.log(args.map(describeValueAsPlainString).join(" "));
        return null;
      },
    });

    this.globals.define("str", {
      __builtin__: true, name: "str",
      call: (args, line) => {
        requireArgs("str", args, 1, line, `str(5) turns the number 5 into the word "5".`);
        return describeValueAsPlainString(args[0]);
      },
    });

    this.globals.define("num", {
      __builtin__: true, name: "num",
      call: (args, line) => {
        requireArgs("num", args, 1, line, `num("42") turns the text "42" into the number 42.`);
        const val = args[0];
        if (typeof val === "number") return val;
        if (typeof val === "string") {
          const n = parseFloat(val);
          if (isNaN(n)) throw new GlangRuntimeError(
            `num() couldn't convert "${val}" into a number.`,
            line, `Make sure the text looks like a number, e.g. "42" or "3.14".`
          );
          return n;
        }
        throw new GlangRuntimeError(
          `num() can only convert text to a number, but got ${typeName(val)}.`,
          line, null
        );
      },
    });

    this.globals.define("round", {
      __builtin__: true, name: "round",
      call: (args, line) => {
        if (args.length < 1 || args.length > 2) throw new GlangRuntimeError(
          `round() expects 1 or 2 values (number, optional decimal places), but got ${args.length}.`,
          line, `round(3.14159) or round(3.14159, 2)`
        );
        const val = args[0];
        const places = args.length === 2 ? args[1] : 0;
        requireNumber("round", places, "decimal places", line);
        const factor = Math.pow(10, places);
        if (typeof val === "number") return Math.round(val * factor) / factor;
        if (val instanceof GlangCurrency) return new GlangCurrency(Math.round(val.amount * factor) / factor, val.currency);
        throw new GlangRuntimeError(
          `round() needs a number or money value, but got ${typeName(val)}.`,
          line, null
        );
      },
    });

    this.globals.define("abs", {
      __builtin__: true, name: "abs",
      call: (args, line) => {
        requireArgs("abs", args, 1, line, `abs(-500) returns 500. abs(-₹200) returns ₹200.`);
        const val = args[0];
        if (typeof val === "number") return Math.abs(val);
        if (val instanceof GlangCurrency) return new GlangCurrency(Math.abs(val.amount), val.currency);
        throw new GlangRuntimeError(`abs() needs a number or money value, but got ${typeName(val)}.`, line, null);
      },
    });

    this.globals.define("random", {
      __builtin__: true, name: "random",
      call: (args, line) => {
        if (args.length === 0) return Math.random();
        if (args.length === 2) {
          const [lo, hi] = args;
          requireNumber("random", lo, "the first value", line);
          requireNumber("random", hi, "the second value", line);
          if (!Number.isInteger(lo) || !Number.isInteger(hi)) {
            throw new GlangRuntimeError(
              `random(min, max) needs two whole numbers, but got ${lo} and ${hi}.`,
              line, `Try random(1, 6) to roll a die, or use random() with no arguments for a decimal between 0 and 1.`
            );
          }
          if (lo > hi) {
            throw new GlangRuntimeError(
              `random(min, max) needs min to be less than or equal to max, but got random(${lo}, ${hi}).`,
              line, `Try random(${hi}, ${lo}) instead.`
            );
          }
          return lo + Math.floor(Math.random() * (hi - lo + 1));
        }
        throw new GlangRuntimeError(
          `random() expects 0 or 2 values (nothing, or a min and max), but got ${args.length}.`,
          line, `random() returns a decimal between 0 and 1. random(1, 6) returns a whole number between 1 and 6.`
        );
      },
    });

    this.globals.define("random_choice", {
      __builtin__: true, name: "random_choice",
      call: (args, line) => {
        requireArgs("random_choice", args, 1, line, `random_choice([1, 2, 3]) returns one item picked at random.`);
        const list = args[0];
        if (!(list instanceof GlangList)) {
          throw new GlangRuntimeError(
            `random_choice() needs a list, but got ${typeName(list)}.`,
            line, `Try something like random_choice(["heads", "tails"]).`
          );
        }
        if (list.items.length === 0) {
          throw new GlangRuntimeError(
            `random_choice() received an empty list — there's nothing to pick.`,
            line, null
          );
        }
        return list.items[Math.floor(Math.random() * list.items.length)];
      },
    });

    // ── STRING OPERATIONS ────────────────────────────────────────────────

    this.globals.define("upper", {
      __builtin__: true, name: "upper",
      call: (args, line) => {
        requireArgs("upper", args, 1, line, `upper("hello") → "HELLO"`);
        if (typeof args[0] !== "string") throw new GlangRuntimeError(
          `upper() needs a text value, but got ${typeName(args[0])}.`, line,
          `Try: upper("hello") or upper(my_text_variable)`);
        return args[0].toUpperCase();
      },
    });

    this.globals.define("lower", {
      __builtin__: true, name: "lower",
      call: (args, line) => {
        requireArgs("lower", args, 1, line, `lower("HELLO") → "hello"`);
        if (typeof args[0] !== "string") throw new GlangRuntimeError(
          `lower() needs a text value, but got ${typeName(args[0])}.`, line, null);
        return args[0].toLowerCase();
      },
    });

    this.globals.define("trim", {
      __builtin__: true, name: "trim",
      call: (args, line) => {
        requireArgs("trim", args, 1, line, `trim("  hello  ") → "hello"`);
        if (typeof args[0] !== "string") throw new GlangRuntimeError(
          `trim() needs a text value, but got ${typeName(args[0])}.`, line, null);
        return args[0].trim();
      },
    });

    this.globals.define("contains", {
      __builtin__: true, name: "contains",
      call: (args, line) => {
        requireArgs("contains", args, 2, line, `contains("hello world", "world") → true   or   contains([1,2,3], 2) → true`);
        const [haystack, needle] = args;
        if (typeof haystack === "string") {
          if (typeof needle !== "string") throw new GlangRuntimeError(
            `contains() on text needs a text value to search for, but got ${typeName(needle)}.`, line, null);
          return haystack.includes(needle);
        }
        if (haystack instanceof GlangList) {
          return haystack.items.some(item => {
            if (item instanceof GlangCurrency && needle instanceof GlangCurrency)
              return item.amount === needle.amount && item.currency === needle.currency;
            if (item instanceof GlangPercent && needle instanceof GlangPercent)
              return item.value === needle.value;
            return item === needle;
          });
        }
        throw new GlangRuntimeError(
          `contains() needs a text or list as its first value, but got ${typeName(haystack)}.`, line,
          `contains("hello", "ell") or contains([1,2,3], 2)`);
      },
    });

    this.globals.define("starts_with", {
      __builtin__: true, name: "starts_with",
      call: (args, line) => {
        requireArgs("starts_with", args, 2, line, `starts_with("hello", "he") → true`);
        const [text, prefix] = args;
        if (typeof text !== "string" || typeof prefix !== "string") throw new GlangRuntimeError(
          `starts_with() needs two text values.`, line, null);
        return text.startsWith(prefix);
      },
    });

    this.globals.define("ends_with", {
      __builtin__: true, name: "ends_with",
      call: (args, line) => {
        requireArgs("ends_with", args, 2, line, `ends_with("report.grw", ".grw") → true`);
        const [text, suffix] = args;
        if (typeof text !== "string" || typeof suffix !== "string") throw new GlangRuntimeError(
          `ends_with() needs two text values.`, line, null);
        return text.endsWith(suffix);
      },
    });

    this.globals.define("replace", {
      __builtin__: true, name: "replace",
      call: (args, line) => {
        requireArgs("replace", args, 3, line, `replace("hello world", "world", "Glang") → "hello Glang"`);
        const [text, from, to] = args;
        if (typeof text !== "string" || typeof from !== "string" || typeof to !== "string")
          throw new GlangRuntimeError(`replace() needs three text values.`, line,
            `replace(original_text, "what to find", "what to put instead")`);
        return text.split(from).join(to);
      },
    });

    this.globals.define("split", {
      __builtin__: true, name: "split",
      call: (args, line) => {
        requireArgs("split", args, 2, line, `split("a,b,c", ",") → ["a", "b", "c"]`);
        const [text, sep] = args;
        if (typeof text !== "string" || typeof sep !== "string") throw new GlangRuntimeError(
          `split() needs two text values (the text, then the separator).`, line,
          `split("TCS,INFY,HDFC", ",") → list of stock names`);
        return new GlangList(text.split(sep));
      },
    });

    this.globals.define("join", {
      __builtin__: true, name: "join",
      call: (args, line) => {
        requireArgs("join", args, 2, line, `join(["a", "b", "c"], ", ") → "a, b, c"`);
        const [list, sep] = args;
        if (!(list instanceof GlangList)) throw new GlangRuntimeError(
          `join() needs a list as its first value, but got ${typeName(list)}.`, line, null);
        if (typeof sep !== "string") throw new GlangRuntimeError(
          `join() needs a text separator as its second value, but got ${typeName(sep)}.`, line, null);
        return list.items.map(v => describeValueAsPlainString(v)).join(sep);
      },
    });

    this.globals.define("repeat_text", {
      __builtin__: true, name: "repeat_text",
      call: (args, line) => {
        requireArgs("repeat_text", args, 2, line, `repeat_text("=-", 3) → "=-=-=-=-"`);
        const [text, times] = args;
        if (typeof text !== "string") throw new GlangRuntimeError(
          `repeat_text() needs a text value first, but got ${typeName(text)}.`, line, null);
        requireNumber("repeat_text", times, "number of times", line);
        if (times < 0 || times > 10000) throw new GlangRuntimeError(
          `repeat_text() times must be between 0 and 10000.`, line, null);
        return text.repeat(times);
      },
    });

    this.globals.define("substring", {
      __builtin__: true, name: "substring",
      call: (args, line) => {
        if (args.length < 2 || args.length > 3) throw new GlangRuntimeError(
          `substring() needs 2 or 3 values: text, start, and optional end.`, line,
          `substring("hello", 1, 3) → "ell"   substring("hello", 2) → "llo"`);
        const [text, start, end] = args;
        if (typeof text !== "string") throw new GlangRuntimeError(
          `substring() needs a text value first, but got ${typeName(text)}.`, line, null);
        requireNumber("substring", start, "start position", line);
        if (end !== undefined) {
          requireNumber("substring", end, "end position", line);
          return text.slice(start, end);
        }
        return text.slice(start);
      },
    });

    this.globals.define("index_of", {
      __builtin__: true, name: "index_of",
      call: (args, line) => {
        requireArgs("index_of", args, 2, line, `index_of("hello", "l") → 2   Returns -1 if not found.`);
        const [text, search] = args;
        if (typeof text !== "string" || typeof search !== "string") throw new GlangRuntimeError(
          `index_of() needs two text values.`, line, null);
        return text.indexOf(search);
      },
    });

    this.globals.define("pad_left", {
      __builtin__: true, name: "pad_left",
      call: (args, line) => {
        if (args.length < 2 || args.length > 3) throw new GlangRuntimeError(
          `pad_left() expects 2 or 3 values: text, width, optional fill character.`, line,
          `pad_left("42", 6) → "    42"   pad_left("42", 6, "0") → "000042"`);
        const [text, width, fill] = args;
        const s = describeValueAsPlainString(text);
        requireNumber("pad_left", width, "width", line);
        const f = typeof fill === "string" ? fill : " ";
        return s.padStart(width, f);
      },
    });

    this.globals.define("pad_right", {
      __builtin__: true, name: "pad_right",
      call: (args, line) => {
        if (args.length < 2 || args.length > 3) throw new GlangRuntimeError(
          `pad_right() expects 2 or 3 values: text, width, optional fill character.`, line,
          `pad_right("Name", 10) → "Name      "   pad_right("Name", 8, ".") → "Name...."`);
        const [text, width, fill] = args;
        const s = describeValueAsPlainString(text);
        requireNumber("pad_right", width, "width", line);
        const f = typeof fill === "string" ? fill : " ";
        return s.padEnd(width, f);
      },
    });

    // ── LIST OPERATIONS ──────────────────────────────────────────────────

    this.globals.define("sort", {
      __builtin__: true, name: "sort",
      call: (args, line) => {
        requireArgs("sort", args, 1, line, `sort([3, 1, 2]) → [1, 2, 3]   sort([₹300, ₹100, ₹200]) → [₹100, ₹200, ₹300]`);
        const [list] = args;
        if (!(list instanceof GlangList)) throw new GlangRuntimeError(
          `sort() needs a list, but got ${typeName(list)}.`, line, null);
        const items = [...list.items];
        const getVal = v => v instanceof GlangCurrency ? v.amount
                          : v instanceof GlangPercent  ? v.value
                          : typeof v === "number"       ? v
                          : String(v);
        items.sort((a, b) => {
          const av = getVal(a), bv = getVal(b);
          if (typeof av === "string" && typeof bv === "string") return av.localeCompare(bv);
          return av - bv;
        });
        return new GlangList(items);
      },
    });

    this.globals.define("sort_desc", {
      __builtin__: true, name: "sort_desc",
      call: (args, line) => {
        requireArgs("sort_desc", args, 1, line, `sort_desc([1, 3, 2]) → [3, 2, 1]`);
        const [list] = args;
        if (!(list instanceof GlangList)) throw new GlangRuntimeError(
          `sort_desc() needs a list, but got ${typeName(list)}.`, line, null);
        const items = [...list.items];
        const getVal = v => v instanceof GlangCurrency ? v.amount
                          : v instanceof GlangPercent  ? v.value
                          : typeof v === "number"       ? v : String(v);
        items.sort((a, b) => getVal(b) - getVal(a));
        return new GlangList(items);
      },
    });

    this.globals.define("slice", {
      __builtin__: true, name: "slice",
      call: (args, line) => {
        if (args.length < 2 || args.length > 3) throw new GlangRuntimeError(
          `slice() needs 2 or 3 values: list, start, optional end.`, line,
          `slice([1,2,3,4,5], 1, 3) → [2, 3]   slice([1,2,3,4], 2) → [3, 4]`);
        const [list, start, end] = args;
        if (!(list instanceof GlangList)) throw new GlangRuntimeError(
          `slice() needs a list as its first value, but got ${typeName(list)}.`, line, null);
        requireNumber("slice", start, "start index", line);
        if (end !== undefined) {
          requireNumber("slice", end, "end index", line);
          return new GlangList(list.items.slice(start, end));
        }
        return new GlangList(list.items.slice(start));
      },
    });

    this.globals.define("reverse", {
      __builtin__: true, name: "reverse",
      call: (args, line) => {
        requireArgs("reverse", args, 1, line, `reverse([1, 2, 3]) → [3, 2, 1]`);
        const [list] = args;
        if (!(list instanceof GlangList)) throw new GlangRuntimeError(
          `reverse() needs a list, but got ${typeName(list)}.`, line, null);
        return new GlangList([...list.items].reverse());
      },
    });

    this.globals.define("unique", {
      __builtin__: true, name: "unique",
      call: (args, line) => {
        requireArgs("unique", args, 1, line, `unique([1, 2, 2, 3, 1]) → [1, 2, 3]`);
        const [list] = args;
        if (!(list instanceof GlangList)) throw new GlangRuntimeError(
          `unique() needs a list, but got ${typeName(list)}.`, line, null);
        const seen = new Set();
        const result = list.items.filter(item => {
          const key = item instanceof GlangCurrency ? `${item.currency}:${item.amount}`
                    : item instanceof GlangPercent  ? `pct:${item.value}`
                    : String(item);
          if (seen.has(key)) return false;
          seen.add(key);
          return true;
        });
        return new GlangList(result);
      },
    });

    this.globals.define("flatten", {
      __builtin__: true, name: "flatten",
      call: (args, line) => {
        requireArgs("flatten", args, 1, line, `flatten([[1,2],[3,4]]) → [1, 2, 3, 4]`);
        const [list] = args;
        if (!(list instanceof GlangList)) throw new GlangRuntimeError(
          `flatten() needs a list, but got ${typeName(list)}.`, line, null);
        const result = [];
        for (const item of list.items) {
          if (item instanceof GlangList) result.push(...item.items);
          else result.push(item);
        }
        return new GlangList(result);
      },
    });

    this.globals.define("first", {
      __builtin__: true, name: "first",
      call: (args, line) => {
        requireArgs("first", args, 1, line, `first([10, 20, 30]) → 10`);
        const [list] = args;
        if (!(list instanceof GlangList)) throw new GlangRuntimeError(
          `first() needs a list, but got ${typeName(list)}.`, line, null);
        if (list.items.length === 0) throw new GlangRuntimeError(
          `first() can't get the first item of an empty list.`, line, null);
        return list.items[0];
      },
    });

    this.globals.define("last", {
      __builtin__: true, name: "last",
      call: (args, line) => {
        requireArgs("last", args, 1, line, `last([10, 20, 30]) → 30`);
        const [list] = args;
        if (!(list instanceof GlangList)) throw new GlangRuntimeError(
          `last() needs a list, but got ${typeName(list)}.`, line, null);
        if (list.items.length === 0) throw new GlangRuntimeError(
          `last() can't get the last item of an empty list.`, line, null);
        return list.items[list.items.length - 1];
      },
    });

    this.globals.define("count_if", {
      __builtin__: true, name: "count_if",
      call: (args, line) => {
        // count_if(list, value) → count of items equal to value
        requireArgs("count_if", args, 2, line, `count_if(["a","b","a"], "a") → 2`);
        const [list, target] = args;
        if (!(list instanceof GlangList)) throw new GlangRuntimeError(
          `count_if() needs a list as its first value.`, line, null);
        return list.items.filter(item => {
          if (item instanceof GlangCurrency && target instanceof GlangCurrency)
            return item.amount === target.amount && item.currency === target.currency;
          return item === target;
        }).length;
      },
    });

    this.globals.define("zip", {
      __builtin__: true, name: "zip",
      call: (args, line) => {
        // zip([1,2,3], ["a","b","c"]) → [[1,"a"],[2,"b"],[3,"c"]]
        requireArgs("zip", args, 2, line, `zip([1,2,3], ["a","b","c"]) → [[1,"a"],[2,"b"],[3,"c"]]`);
        const [a, b] = args;
        if (!(a instanceof GlangList) || !(b instanceof GlangList)) throw new GlangRuntimeError(
          `zip() needs two lists.`, line, null);
        const len = Math.min(a.items.length, b.items.length);
        const result = [];
        for (let i = 0; i < len; i++) {
          result.push(new GlangList([a.items[i], b.items[i]]));
        }
        return new GlangList(result);
      },
    });

    // ── MATH BASICS ──────────────────────────────────────────────────────

    this.globals.define("floor", {
      __builtin__: true, name: "floor",
      call: (args, line) => {
        requireArgs("floor", args, 1, line, `floor(3.7) → 3   floor(₹3842.75) → ₹3842`);
        const [val] = args;
        if (typeof val === "number") return Math.floor(val);
        if (val instanceof GlangCurrency) return new GlangCurrency(Math.floor(val.amount), val.currency);
        throw new GlangRuntimeError(`floor() needs a number or money value, but got ${typeName(val)}.`, line, null);
      },
    });

    this.globals.define("ceil", {
      __builtin__: true, name: "ceil",
      call: (args, line) => {
        requireArgs("ceil", args, 1, line, `ceil(3.2) → 4   ceil(₹4339.12) → ₹4340`);
        const [val] = args;
        if (typeof val === "number") return Math.ceil(val);
        if (val instanceof GlangCurrency) return new GlangCurrency(Math.ceil(val.amount), val.currency);
        throw new GlangRuntimeError(`ceil() needs a number or money value, but got ${typeName(val)}.`, line, null);
      },
    });

    this.globals.define("sqrt", {
      __builtin__: true, name: "sqrt",
      call: (args, line) => {
        requireArgs("sqrt", args, 1, line, `sqrt(16) → 4   sqrt(2) → 1.414...`);
        const [val] = args;
        if (typeof val !== "number") throw new GlangRuntimeError(
          `sqrt() needs a plain number, but got ${typeName(val)}.`, line,
          `sqrt(16) → 4   sqrt(2) → 1.414`);
        if (val < 0) throw new GlangRuntimeError(
          `sqrt() can't take the square root of a negative number (${val}).`, line,
          `Make sure the value is 0 or positive.`);
        return Math.sqrt(val);
      },
    });

    this.globals.define("power", {
      __builtin__: true, name: "power",
      call: (args, line) => {
        requireArgs("power", args, 2, line, `power(2, 10) → 1024   power(1.08, 5) → 1.469`);
        const [base, exp] = args;
        if (typeof base !== "number" || typeof exp !== "number") throw new GlangRuntimeError(
          `power() needs two plain numbers, but got ${typeName(base)} and ${typeName(exp)}.`, line, null);
        return Math.pow(base, exp);
      },
    });

    this.globals.define("min", {
      __builtin__: true, name: "min",
      call: (args, line) => {
        if (args.length === 0) throw new GlangRuntimeError(`min() needs at least one value.`, line, null);
        // min(a, b, c) or min(list)
        const items = args.length === 1 && args[0] instanceof GlangList ? args[0].items : args;
        if (items.length === 0) throw new GlangRuntimeError(`min() received an empty list.`, line, null);
        const getVal = v => v instanceof GlangCurrency ? v.amount : v instanceof GlangPercent ? v.value : v;
        return items.reduce((best, cur) => getVal(cur) < getVal(best) ? cur : best);
      },
    });

    this.globals.define("max", {
      __builtin__: true, name: "max",
      call: (args, line) => {
        if (args.length === 0) throw new GlangRuntimeError(`max() needs at least one value.`, line, null);
        const items = args.length === 1 && args[0] instanceof GlangList ? args[0].items : args;
        if (items.length === 0) throw new GlangRuntimeError(`max() received an empty list.`, line, null);
        const getVal = v => v instanceof GlangCurrency ? v.amount : v instanceof GlangPercent ? v.value : v;
        return items.reduce((best, cur) => getVal(cur) > getVal(best) ? cur : best);
      },
    });

    this.globals.define("log", {
      __builtin__: true, name: "log",
      call: (args, line) => {
        // log(x) → natural log   log(x, base) → log base n
        if (args.length < 1 || args.length > 2) throw new GlangRuntimeError(
          `log() expects 1 or 2 values.`, line, `log(100) → natural log   log(100, 10) → log base 10`);
        const [val, base] = args;
        if (typeof val !== "number") throw new GlangRuntimeError(
          `log() needs a plain number, but got ${typeName(val)}.`, line, null);
        if (val <= 0) throw new GlangRuntimeError(
          `log() needs a positive number, but got ${val}.`, line, null);
        if (base !== undefined) {
          requireNumber("log", base, "the base", line);
          return Math.log(val) / Math.log(base);
        }
        return Math.log(val);
      },
    });

    this.globals.define("safe_divide", {
      __builtin__: true, name: "safe_divide",
      call: (args, line) => {
        requireArgs("safe_divide", args, 2, line, `safe_divide(10, 0) → 0 instead of crashing`);
        const [a, b] = args;
        const bval = b instanceof GlangCurrency ? b.amount : b instanceof GlangPercent ? b.value : b;
        if (bval === 0) {
          // Return 0 of the appropriate type
          if (a instanceof GlangCurrency) return new GlangCurrency(0, a.currency);
          if (a instanceof GlangPercent) return new GlangPercent(0);
          return 0;
        }
        if (a instanceof GlangCurrency && typeof b === "number") return new GlangCurrency(a.amount / b, a.currency);
        if (typeof a === "number" && typeof b === "number") return a / b;
        return typeof a === "number" ? a / bval : a;
      },
    });

    // ── TYPE CHECKING ────────────────────────────────────────────────────

    this.globals.define("is_number", {
      __builtin__: true, name: "is_number",
      call: (args, line) => {
        requireArgs("is_number", args, 1, line, `is_number(42) → true   is_number("hello") → false`);
        return typeof args[0] === "number";
      },
    });

    this.globals.define("is_text", {
      __builtin__: true, name: "is_text",
      call: (args, line) => {
        requireArgs("is_text", args, 1, line, `is_text("hello") → true   is_text(42) → false`);
        return typeof args[0] === "string";
      },
    });

    this.globals.define("is_money", {
      __builtin__: true, name: "is_money",
      call: (args, line) => {
        requireArgs("is_money", args, 1, line, `is_money(₹500) → true   is_money(42) → false`);
        return args[0] instanceof GlangCurrency;
      },
    });

    this.globals.define("is_percent", {
      __builtin__: true, name: "is_percent",
      call: (args, line) => {
        requireArgs("is_percent", args, 1, line, `is_percent(8%) → true   is_percent(8) → false`);
        return args[0] instanceof GlangPercent;
      },
    });

    this.globals.define("is_list", {
      __builtin__: true, name: "is_list",
      call: (args, line) => {
        requireArgs("is_list", args, 1, line, `is_list([1,2,3]) → true   is_list(42) → false`);
        return args[0] instanceof GlangList;
      },
    });

    this.globals.define("is_dict", {
      __builtin__: true, name: "is_dict",
      call: (args, line) => {
        requireArgs("is_dict", args, 1, line, `is_dict({name: "Alex"}) → true   is_dict(42) → false`);
        return args[0] instanceof GlangDict;
      },
    });

    this.globals.define("keys", {
      __builtin__: true, name: "keys",
      call: (args, line) => {
        requireArgs("keys", args, 1, line, `keys({name: "Alex", age: 30}) → ["name", "age"]`);
        if (!(args[0] instanceof GlangDict)) {
          throw new GlangRuntimeError(
            `keys() needs a dictionary, but got ${typeName(args[0])}.`,
            line, `Example: keys({name: "Alex", age: 30})`
          );
        }
        return new GlangList([...args[0].map.keys()]);
      },
    });

    this.globals.define("values", {
      __builtin__: true, name: "values",
      call: (args, line) => {
        requireArgs("values", args, 1, line, `values({name: "Alex", age: 30}) → ["Alex", 30]`);
        if (!(args[0] instanceof GlangDict)) {
          throw new GlangRuntimeError(
            `values() needs a dictionary, but got ${typeName(args[0])}.`,
            line, `Example: values({name: "Alex", age: 30})`
          );
        }
        return new GlangList([...args[0].map.values()]);
      },
    });

    this.globals.define("has_key", {
      __builtin__: true, name: "has_key",
      call: (args, line) => {
        requireArgs("has_key", args, 2, line, `has_key({name: "Alex"}, "name") → true`);
        const [dict, key] = args;
        if (!(dict instanceof GlangDict)) {
          throw new GlangRuntimeError(
            `has_key() needs a dictionary as the first value, but got ${typeName(dict)}.`,
            line, `Example: has_key({name: "Alex"}, "name")`
          );
        }
        if (typeof key !== "string") {
          throw new GlangRuntimeError(
            `has_key() needs the key to be text, but got ${typeName(key)}.`,
            line, null
          );
        }
        return dict.map.has(key);
      },
    });

    this.globals.define("dict_get", {
      __builtin__: true, name: "dict_get",
      call: (args, line) => {
        requireArgs("dict_get", args, 3, line, `dict_get({name: "Alex"}, "age", 0) → 0 (falls back since "age" isn't a key)`);
        const [dict, key, fallback] = args;
        if (!(dict instanceof GlangDict)) {
          throw new GlangRuntimeError(
            `dict_get() needs a dictionary as the first value, but got ${typeName(dict)}.`,
            line, null
          );
        }
        if (typeof key !== "string") {
          throw new GlangRuntimeError(
            `dict_get() needs the key to be text, but got ${typeName(key)}.`,
            line, null
          );
        }
        return dict.map.has(key) ? dict.map.get(key) : fallback;
      },
    });

    this.globals.define("is_empty", {
      __builtin__: true, name: "is_empty",
      call: (args, line) => {
        requireArgs("is_empty", args, 1, line, `is_empty([]) → true   is_empty("") → true   is_empty([1,2]) → false`);
        const [val] = args;
        if (typeof val === "string") return val.length === 0;
        if (val instanceof GlangList) return val.items.length === 0;
        if (val instanceof GlangDict) return val.map.size === 0;
        if (val === null || val === undefined) return true;
        return false;
      },
    });

    this.globals.define("type_of", {
      __builtin__: true, name: "type_of",
      call: (args, line) => {
        requireArgs("type_of", args, 1, line, `type_of(₹500) → "money"   type_of("hi") → "text"   type_of(42) → "number"`);
        const [val] = args;
        if (typeof val === "number") return "number";
        if (typeof val === "string") return "text";
        if (typeof val === "boolean") return "boolean";
        if (val instanceof GlangCurrency) return "money";
        if (val instanceof GlangPercent) return "percent";
        if (val instanceof GlangList) return "list";
        if (val instanceof GlangDict) return "dictionary";
        if (val instanceof GlangStock) return "stock";
        if (val instanceof GlangFunction) return "function";
        return "unknown";
      },
    });

    // ── DATE / TIME ──────────────────────────────────────────────────────

    this.globals.define("today", {
      __builtin__: true, name: "today",
      call: (args, line) => {
        const d = new Date();
        const pad = n => String(n).padStart(2, "0");
        return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`;
      },
    });

    this.globals.define("current_year", {
      __builtin__: true, name: "current_year",
      call: (args, line) => new Date().getFullYear(),
    });

    this.globals.define("current_month", {
      __builtin__: true, name: "current_month",
      call: (args, line) => new Date().getMonth() + 1,
    });

    this.globals.define("days_between", {
      __builtin__: true, name: "days_between",
      call: (args, line) => {
        requireArgs("days_between", args, 2, line, `days_between("2024-01-01", "2024-12-31") → 365`);
        const [from, to] = args;
        if (typeof from !== "string" || typeof to !== "string") throw new GlangRuntimeError(
          `days_between() needs two date strings in "YYYY-MM-DD" format.`, line, null);
        const a = new Date(from), b = new Date(to);
        if (isNaN(a) || isNaN(b)) throw new GlangRuntimeError(
          `days_between() couldn't understand the dates. Use "YYYY-MM-DD" format, e.g. "2024-01-15".`, line, null);
        return Math.round((b - a) / (1000 * 60 * 60 * 24));
      },
    });

    this.globals.define("years_between", {
      __builtin__: true, name: "years_between",
      call: (args, line) => {
        requireArgs("years_between", args, 2, line, `years_between("2020-01-01", "2025-01-01") → 5`);
        const [from, to] = args;
        if (typeof from !== "string" || typeof to !== "string") throw new GlangRuntimeError(
          `years_between() needs two date strings in "YYYY-MM-DD" format.`, line, null);
        const a = new Date(from), b = new Date(to);
        if (isNaN(a) || isNaN(b)) throw new GlangRuntimeError(
          `years_between() couldn't understand the dates. Use "YYYY-MM-DD" format.`, line, null);
        return Math.round((b - a) / (1000 * 60 * 60 * 24 * 365.25) * 100) / 100;
      },
    });

    this.globals.define("format_date", {
      __builtin__: true, name: "format_date",
      call: (args, line) => {
        requireArgs("format_date", args, 1, line, `format_date("2024-03-15") → "15 Mar 2024"`);
        const [dateStr] = args;
        if (typeof dateStr !== "string") throw new GlangRuntimeError(
          `format_date() needs a date string, but got ${typeName(dateStr)}.`, line, null);
        const d = new Date(dateStr);
        if (isNaN(d)) throw new GlangRuntimeError(
          `format_date() couldn't understand "${dateStr}". Use "YYYY-MM-DD" format.`, line, null);
        const months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
        return `${d.getDate()} ${months[d.getMonth()]} ${d.getFullYear()}`;
      },
    });

    // ── List utilities ───────────────────────────────────────────────────

    this.globals.define("length", {
      __builtin__: true, name: "length",
      call: (args, line) => {
        requireArgs("length", args, 1, line, `length([1, 2, 3]) → 3   length("hello") → 5`);
        const [val] = args;
        if (typeof val === "string") return val.length;
        if (val instanceof GlangList) return val.items.length;
        throw new GlangRuntimeError(
          `length() needs a list or text, but got ${typeName(val)}.`, line,
          `length([1, 2, 3]) → 3   length("hello") → 5`);
      },
    });

    this.globals.define("total", {
      __builtin__: true, name: "total",
      call: (args, line) => {
        requireArgs("total", args, 1, line, `total([₹500, ₹300]) → ₹800   total([1, 2, 3]) → 6`);
        requireList("total", args[0], "the first value", line);
        const list = args[0];
        if (list.items.length === 0) return 0;
        // Currency list
        if (list.items[0] instanceof GlangCurrency) {
          const currency = list.items[0].currency;
          const sum = list.items.reduce((acc, item) => {
            if (!(item instanceof GlangCurrency)) throw new GlangRuntimeError(
              `total() found a mix of types in the list.`, line, `All items must be the same type (all money or all numbers).`);
            return acc + item.amount;
          }, 0);
          return new GlangCurrency(sum, currency);
        }
        // Number list
        const sum = list.items.reduce((acc, item) => {
          if (typeof item !== "number") throw new GlangRuntimeError(
            `total() found a mix of types in the list.`, line, `All items must be the same type.`);
          return acc + item;
        }, 0);
        return sum;
      },
    });

    this.globals.define("average", {
      __builtin__: true, name: "average",
      call: (args, line) => {
        requireArgs("average", args, 1, line, `average([₹500, ₹300]) → ₹400   average([10, 20, 30]) → 20`);
        requireList("average", args[0], "the first value", line);
        const list = args[0];
        if (list.items.length === 0) throw new GlangRuntimeError(`average() can't average an empty list.`, line, null);
        if (list.items[0] instanceof GlangCurrency) {
          const currency = list.items[0].currency;
          const sum = list.items.reduce((acc, item) => acc + item.amount, 0);
          return new GlangCurrency(sum / list.items.length, currency);
        }
        const sum = list.items.reduce((acc, item) => acc + item, 0);
        return sum / list.items.length;
      },
    });

    this.globals.define("max_val", {
      __builtin__: true, name: "max_val",
      call: (args, line) => {
        requireArgs("max_val", args, 1, line, `max_val([₹500, ₹300, ₹800]) returns ₹800.`);
        requireList("max_val", args[0], "the first value", line);
        const list = args[0];
        requireCurrencyList("max_val", list, line);
        return list.items.reduce((a, b) => a.amount > b.amount ? a : b);
      },
    });

    this.globals.define("min_val", {
      __builtin__: true, name: "min_val",
      call: (args, line) => {
        requireArgs("min_val", args, 1, line, `min_val([₹500, ₹300, ₹800]) returns ₹300.`);
        requireList("min_val", args[0], "the first value", line);
        const list = args[0];
        requireCurrencyList("min_val", list, line);
        return list.items.reduce((a, b) => a.amount < b.amount ? a : b);
      },
    });

    this.globals.define("append", {
      __builtin__: true, name: "append",
      call: (args, line) => {
        requireArgs("append", args, 2, line, `append(my_list, ₹500) adds ₹500 to the end of my_list.`);
        requireList("append", args[0], "the first value", line);
        return new GlangList([...args[0].items, args[1]]);
      },
    });

    // ── Finance: Basic interest ──────────────────────────────────────────

    this.globals.define("simple_interest", {
      __builtin__: true, name: "simple_interest",
      call: (args, line) => {
        requireArgs("simple_interest", args, 3, line, `simple_interest(₹10000, 5%, 3) → interest on ₹10000 at 5% for 3 years.`);
        const [principal, rate, years] = args;
        requireCurrency("simple_interest", principal, "the principal (first value)", line);
        requirePercent("simple_interest", rate, "the rate (second value)", line);
        requireNumber("simple_interest", years, "the number of years (third value)", line);
        const interest = principal.amount * rate.value * years;
        return new GlangCurrency(interest, principal.currency);
      },
    });

    this.globals.define("compound", {
      __builtin__: true, name: "compound",
      call: (args, line) => {
        requireArgs("compound", args, 3, line, `compound(₹10000, 8%, 5) → final amount after compounding ₹10000 at 8% for 5 years.`);
        const [principal, rate, years] = args;
        requireCurrency("compound", principal, "the principal (first value)", line);
        requirePercent("compound", rate, "the rate (second value)", line);
        requireNumber("compound", years, "the number of years (third value)", line);
        const amount = principal.amount * Math.pow(1 + rate.value, years);
        return new GlangCurrency(amount, principal.currency);
      },
    });

    this.globals.define("compound_interest", {
      __builtin__: true, name: "compound_interest",
      call: (args, line) => {
        requireArgs("compound_interest", args, 3, line, `compound_interest(₹10000, 8%, 5) → only the interest earned, not the total.`);
        const [principal, rate, years] = args;
        requireCurrency("compound_interest", principal, "the principal (first value)", line);
        requirePercent("compound_interest", rate, "the rate (second value)", line);
        requireNumber("compound_interest", years, "the number of years (third value)", line);
        const interest = principal.amount * (Math.pow(1 + rate.value, years) - 1);
        return new GlangCurrency(interest, principal.currency);
      },
    });

    // ── Finance: EMI / Loans ─────────────────────────────────────────────

    this.globals.define("emi", {
      __builtin__: true, name: "emi",
      call: (args, line) => {
        // emi(principal, annual_rate, years)
        // Uses standard reducing-balance EMI formula: P*r*(1+r)^n / ((1+r)^n - 1)
        requireArgs("emi", args, 3, line, `emi(₹500000, 8.5%, 20) → monthly EMI on a ₹5 lakh loan at 8.5% for 20 years.`);
        const [principal, rate, years] = args;
        requireCurrency("emi", principal, "the loan amount (first value)", line);
        requirePercent("emi", rate, "the annual interest rate (second value)", line);
        requireNumber("emi", years, "the loan tenure in years (third value)", line);
        const monthlyRate = rate.value / 12;
        const months = years * 12;
        if (monthlyRate === 0) return new GlangCurrency(principal.amount / months, principal.currency);
        const emiAmount = principal.amount * monthlyRate * Math.pow(1 + monthlyRate, months)
          / (Math.pow(1 + monthlyRate, months) - 1);
        return new GlangCurrency(emiAmount, principal.currency);
      },
    });

    this.globals.define("total_loan_cost", {
      __builtin__: true, name: "total_loan_cost",
      call: (args, line) => {
        requireArgs("total_loan_cost", args, 3, line, `total_loan_cost(₹500000, 8.5%, 20) → total amount paid over the full loan period.`);
        const [principal, rate, years] = args;
        requireCurrency("total_loan_cost", principal, "the loan amount", line);
        requirePercent("total_loan_cost", rate, "the annual interest rate", line);
        requireNumber("total_loan_cost", years, "the loan tenure in years", line);
        const monthlyRate = rate.value / 12;
        const months = years * 12;
        if (monthlyRate === 0) return new GlangCurrency(principal.amount, principal.currency);
        const emiAmount = principal.amount * monthlyRate * Math.pow(1 + monthlyRate, months)
          / (Math.pow(1 + monthlyRate, months) - 1);
        return new GlangCurrency(emiAmount * months, principal.currency);
      },
    });

    this.globals.define("loan_interest_paid", {
      __builtin__: true, name: "loan_interest_paid",
      call: (args, line) => {
        requireArgs("loan_interest_paid", args, 3, line, `loan_interest_paid(₹500000, 8.5%, 20) → total interest paid over the loan period.`);
        const [principal, rate, years] = args;
        requireCurrency("loan_interest_paid", principal, "the loan amount", line);
        requirePercent("loan_interest_paid", rate, "the annual interest rate", line);
        requireNumber("loan_interest_paid", years, "the loan tenure in years", line);
        const monthlyRate = rate.value / 12;
        const months = years * 12;
        if (monthlyRate === 0) return new GlangCurrency(0, principal.currency);
        const emiAmount = principal.amount * monthlyRate * Math.pow(1 + monthlyRate, months)
          / (Math.pow(1 + monthlyRate, months) - 1);
        return new GlangCurrency((emiAmount * months) - principal.amount, principal.currency);
      },
    });

    // ── Finance: Investment returns ──────────────────────────────────────

    this.globals.define("cagr", {
      __builtin__: true, name: "cagr",
      call: (args, line) => {
        // cagr(start_value, end_value, years) → annualised growth rate
        requireArgs("cagr", args, 3, line, `cagr(₹100000, ₹350000, 5) → annualised growth rate over 5 years.`);
        const [start, end, years] = args;
        requireCurrency("cagr", start, "the starting value (first value)", line);
        requireCurrency("cagr", end, "the ending value (second value)", line);
        requireNumber("cagr", years, "the number of years (third value)", line);
        if (start.currency !== end.currency) throw new GlangRuntimeError(
          `cagr() needs both values in the same currency, but got ${start.currency} and ${end.currency}.`,
          line, `Convert one to match the other first.`
        );
        if (start.amount <= 0) throw new GlangRuntimeError(
          `cagr() needs a positive starting value, but got ${describeValue(start)}.`, line, null
        );
        const rate = Math.pow(end.amount / start.amount, 1 / years) - 1;
        return new GlangPercent(rate);
      },
    });

    this.globals.define("sip", {
      __builtin__: true, name: "sip",
      call: (args, line) => {
        // sip(monthly_investment, annual_rate, years) → total corpus at end
        // Standard SIP formula: P * [((1+r)^n - 1) / r] * (1+r)
        requireArgs("sip", args, 3, line, `sip(₹5000, 12%, 10) → corpus after investing ₹5000/month at 12% for 10 years.`);
        const [monthly, rate, years] = args;
        requireCurrency("sip", monthly, "the monthly investment (first value)", line);
        requirePercent("sip", rate, "the expected annual return (second value)", line);
        requireNumber("sip", years, "the investment period in years (third value)", line);
        const monthlyRate = rate.value / 12;
        const months = years * 12;
        if (monthlyRate === 0) return new GlangCurrency(monthly.amount * months, monthly.currency);
        const corpus = monthly.amount * ((Math.pow(1 + monthlyRate, months) - 1) / monthlyRate) * (1 + monthlyRate);
        return new GlangCurrency(corpus, monthly.currency);
      },
    });

    this.globals.define("sip_invested", {
      __builtin__: true, name: "sip_invested",
      call: (args, line) => {
        requireArgs("sip_invested", args, 2, line, `sip_invested(₹5000, 10) → total amount you actually put in over 10 years (₹5000 × 120 months).`);
        const [monthly, years] = args;
        requireCurrency("sip_invested", monthly, "the monthly investment", line);
        requireNumber("sip_invested", years, "the number of years", line);
        return new GlangCurrency(monthly.amount * years * 12, monthly.currency);
      },
    });

    this.globals.define("roi", {
      __builtin__: true, name: "roi",
      call: (args, line) => {
        // roi(cost, gain) → percentage return
        requireArgs("roi", args, 2, line, `roi(₹100000, ₹130000) → return on investment as a percentage.`);
        const [cost, gain] = args;
        requireCurrency("roi", cost, "the cost / amount invested (first value)", line);
        requireCurrency("roi", gain, "the gain / final value (second value)", line);
        if (cost.currency !== gain.currency) throw new GlangRuntimeError(
          `roi() needs both values in the same currency.`, line, null
        );
        if (cost.amount === 0) return new GlangPercent(0); // graceful zero — avoids crashing app on empty inputs
        return new GlangPercent((gain.amount - cost.amount) / cost.amount);
      },
    });

    this.globals.define("fv", {
      __builtin__: true, name: "fv",
      call: (args, line) => {
        // fv(present_value, rate, years) → future value
        requireArgs("fv", args, 3, line, `fv(₹100000, 7%, 10) → what ₹1 lakh will be worth in 10 years at 7% inflation/growth.`);
        const [pv, rate, years] = args;
        requireCurrency("fv", pv, "the present value (first value)", line);
        requirePercent("fv", rate, "the rate (second value)", line);
        requireNumber("fv", years, "the number of years (third value)", line);
        return new GlangCurrency(pv.amount * Math.pow(1 + rate.value, years), pv.currency);
      },
    });

    this.globals.define("pv", {
      __builtin__: true, name: "pv",
      call: (args, line) => {
        // pv(future_value, rate, years) → present value (what is it worth today?)
        requireArgs("pv", args, 3, line, `pv(₹200000, 7%, 10) → what ₹2 lakh in the future is worth in today's money.`);
        const [fvVal, rate, years] = args;
        requireCurrency("pv", fvVal, "the future value (first value)", line);
        requirePercent("pv", rate, "the discount rate (second value)", line);
        requireNumber("pv", years, "the number of years (third value)", line);
        return new GlangCurrency(fvVal.amount / Math.pow(1 + rate.value, years), fvVal.currency);
      },
    });

    this.globals.define("npv", {
      __builtin__: true, name: "npv",
      call: (args, line) => {
        // npv(discount_rate, cashflows_list) → NPV of future cash flows
        // npv(discount_rate, cashflows_list, initial_investment) → NPV minus upfront cost
        if (args.length < 2 || args.length > 3) {
          throw new GlangRuntimeError(
            `npv() expects 2 or 3 values, but got ${args.length}.`,
            line,
            `npv(10%, [₹30000, ₹40000, ₹50000]) or npv(10%, [₹30000, ₹40000], ₹100000) to subtract initial investment.`
          );
        }
        const [rate, cashflows, initialInvestment] = args;
        requirePercent("npv", rate, "the discount rate (first value)", line);
        requireList("npv", cashflows, "the list of cash flows (second value)", line);
        requireCurrencyList("npv", cashflows, line);
        const currency = cashflows.items[0].currency;
        let total = 0;
        cashflows.items.forEach((cf, i) => {
          total += cf.amount / Math.pow(1 + rate.value, i + 1);
        });
        if (initialInvestment !== undefined) {
          requireCurrency("npv", initialInvestment, "the initial investment (third value)", line);
          if (initialInvestment.currency !== currency) {
            throw new GlangRuntimeError(
              `npv() got mixed currencies — cash flows are in ${currency} but initial investment is in ${initialInvestment.currency}.`,
              line, "Use the same currency throughout."
            );
          }
          total -= initialInvestment.amount;
        }
        return new GlangCurrency(total, currency);
      },
    });

    this.globals.define("inflation_adjust", {
      __builtin__: true, name: "inflation_adjust",
      call: (args, line) => {
        // inflation_adjust(amount, inflation_rate, years) → real value after inflation
        requireArgs("inflation_adjust", args, 3, line, `inflation_adjust(₹50000, 6%, 10) → what ₹50000 today is really worth after 10 years of 6% inflation.`);
        const [amount, rate, years] = args;
        requireCurrency("inflation_adjust", amount, "the amount (first value)", line);
        requirePercent("inflation_adjust", rate, "the inflation rate (second value)", line);
        requireNumber("inflation_adjust", years, "the number of years (third value)", line);
        return new GlangCurrency(amount.amount / Math.pow(1 + rate.value, years), amount.currency);
      },
    });

    // ── Finance: Indian Tax (FY2024-25 new regime) ────────────────────────

    this.globals.define("tax", {
      __builtin__: true, name: "tax",
      call: (args, line) => {
        // tax(annual_income) → tax payable under Indian new tax regime FY2024-25
        // Slabs: 0-3L: 0%, 3-7L: 5%, 7-10L: 10%, 10-12L: 15%, 12-15L: 20%, 15L+: 30%
        requireArgs("tax", args, 1, line, `tax(₹850000) → income tax payable on ₹8.5 lakh annual income (Indian new regime FY2024-25).`);
        const [income] = args;
        requireCurrency("tax", income, "the annual income", line);
        if (income.currency !== "INR") throw new GlangRuntimeError(
          `tax() currently calculates Indian income tax and expects ₹ (INR), but got ${income.currency}.`,
          line, `Use ₹ for the amount, e.g. tax(₹850000).`
        );
        const amt = income.amount;
        // Rebate u/s 87A: no tax if income <= 7L
        if (amt <= 700000) return new GlangCurrency(0, "INR");
        const slabs = [
          [300000, 0],
          [400000, 0.05],  // 3L-7L
          [300000, 0.10],  // 7L-10L
          [200000, 0.15],  // 10L-12L
          [300000, 0.20],  // 12L-15L
        ];
        let remaining = amt;
        let taxAmt = 0;
        for (const [slabSize, slabRate] of slabs) {
          if (remaining <= 0) break;
          const taxable = Math.min(remaining, slabSize);
          taxAmt += taxable * slabRate;
          remaining -= slabSize;
        }
        if (remaining > 0) taxAmt += remaining * 0.30; // 30% above 15L
        // Add 4% health & education cess
        taxAmt = taxAmt * 1.04;
        return new GlangCurrency(taxAmt, "INR");
      },
    });

    this.globals.define("take_home", {
      __builtin__: true, name: "take_home",
      call: (args, line) => {
        requireArgs("take_home", args, 1, line, `take_home(₹1200000) → annual take-home salary after Indian income tax.`);
        const [income] = args;
        requireCurrency("take_home", income, "the annual income", line);
        if (income.currency !== "INR") throw new GlangRuntimeError(
          `take_home() currently works with Indian income (₹ only).`,
          line, `Use ₹ for the amount, e.g. take_home(₹1200000).`
        );
        // Reuse tax logic
        const taxFn = this.globals.get("tax", line);
        const taxAmt = taxFn.call([income], line);
        return new GlangCurrency(income.amount - taxAmt.amount, "INR");
      },
    });

    this.globals.define("convert", {
      __builtin__: true, name: "convert",
      call: (args, line) => {
        throw new GlangRuntimeError(
          "Live currency conversion isn't available yet in this version of Glang.",
          line,
          "Exchange rate support is coming in a future update — for now, work in a single currency."
        );
      },
    });

    // ── PHASE 2 ENHANCEMENTS ─────────────────────────────────────────────

    this.globals.define("irr", {
      __builtin__: true, name: "irr",
      call: (args, line) => {
        // irr(initial_investment, cashflows_list)
        // Internal Rate of Return — the discount rate that makes NPV = 0
        // Uses Newton-Raphson numerical method
        requireArgs("irr", args, 2, line, "irr(₹100000, [₹40000, ₹50000, ₹60000]) → IRR as a percentage");
        const [investment, cashflows] = args;
        requireCurrency("irr", investment, "the initial investment (first value)", line);
        requireList("irr", cashflows, "the list of cash flows (second value)", line);
        requireCurrencyList("irr", cashflows, line);

        // Build full cashflow array: -investment at t=0, then each inflow
        const cfs = [-investment.amount, ...cashflows.items.map(c => c.amount)];

        // Newton-Raphson: iterate until NPV ≈ 0
        let rate = 0.1; // initial guess: 10%
        for (let iter = 0; iter < 1000; iter++) {
          let npvVal = 0, dnpv = 0;
          for (let t = 0; t < cfs.length; t++) {
            npvVal += cfs[t] / Math.pow(1 + rate, t);
            dnpv  -= t * cfs[t] / Math.pow(1 + rate, t + 1);
          }
          const newRate = rate - npvVal / dnpv;
          if (Math.abs(newRate - rate) < 1e-8) { rate = newRate; break; }
          rate = newRate;
        }
        if (rate < -1 || rate > 100 || isNaN(rate)) {
          throw new GlangRuntimeError(
            "Could not calculate IRR — the cash flows may not have a valid internal rate of return.",
            line,
            "Make sure the initial investment is positive and the cash flows add up to more than the investment."
          );
        }
        return new GlangPercent(rate);
      },
    });

    this.globals.define("break_even", {
      __builtin__: true, name: "break_even",
      call: (args, line) => {
        // break_even(fixed_costs, price_per_unit, variable_cost_per_unit)
        // Returns the number of units needed to break even
        requireArgs("break_even", args, 3, line, "break_even(₹500000, ₹200, ₹80) → units needed to break even");
        const [fixed, price, variable] = args;
        requireCurrency("break_even", fixed, "fixed costs (first value)", line);
        requireCurrency("break_even", price, "price per unit (second value)", line);
        requireCurrency("break_even", variable, "variable cost per unit (third value)", line);
        const contribution = price.amount - variable.amount;
        if (contribution <= 0) {
          throw new GlangRuntimeError(
            "Break-even is impossible — your price per unit is not higher than your variable cost per unit.",
            line,
            "The selling price must be greater than the variable cost to ever break even."
          );
        }
        return Math.ceil(fixed.amount / contribution);
      },
    });

    this.globals.define("loan_schedule", {
      __builtin__: true, name: "loan_schedule",
      call: (args, line) => {
        // loan_schedule(principal, rate, years) → list of monthly payment breakdowns
        // Each item is a GlangCurrency representing principal paid that month
        // (Returns list of [month, principal_paid, interest_paid, balance] as strings for display)
        requireArgs("loan_schedule", args, 3, line, "loan_schedule(₹500000, 8.5%, 5) → amortization breakdown");
        const [principal, rate, years] = args;
        requireCurrency("loan_schedule", principal, "the loan amount (first value)", line);
        requirePercent("loan_schedule", rate, "the interest rate (second value)", line);
        requireNumber("loan_schedule", years, "the number of years (third value)", line);

        const P = principal.amount;
        const monthlyRate = rate.value / 12;
        const n = years * 12;
        const emiAmt = P * monthlyRate * Math.pow(1 + monthlyRate, n) / (Math.pow(1 + monthlyRate, n) - 1);

        const schedule = [];
        let balance = P;
        for (let m = 1; m <= n; m++) {
          const interestPaid = balance * monthlyRate;
          const principalPaid = emiAmt - interestPaid;
          balance -= principalPaid;
          // Store as a formatted string so show() renders it nicely
          const balanceDisplay = Math.max(0, balance);
          schedule.push(
            `Month ${m}: EMI ${new GlangCurrency(emiAmt, principal.currency)} | Principal ${new GlangCurrency(principalPaid, principal.currency)} | Interest ${new GlangCurrency(interestPaid, principal.currency)} | Balance ${new GlangCurrency(balanceDisplay, principal.currency)}`
          );
        }
        return new GlangList(schedule);
      },
    });

    this.globals.define("sip_goal", {
      __builtin__: true, name: "sip_goal",
      call: (args, line) => {
        // sip_goal(target_amount, rate, years) → monthly SIP needed to reach target
        requireArgs("sip_goal", args, 3, line, "sip_goal(₹5000000, 12%, 15) → monthly SIP needed to reach ₹50L");
        const [target, rate, years] = args;
        requireCurrency("sip_goal", target, "the target amount (first value)", line);
        requirePercent("sip_goal", rate, "the annual return rate (second value)", line);
        requireNumber("sip_goal", years, "the number of years (third value)", line);
        const mr = rate.value / 12;
        const n = years * 12;
        const monthly = target.amount * mr / ((Math.pow(1 + mr, n) - 1) * (1 + mr));
        return new GlangCurrency(monthly, target.currency);
      },
    });

    this.globals.define("percent_change", {
      __builtin__: true, name: "percent_change",
      call: (args, line) => {
        // percent_change(old_value, new_value) → percentage change
        requireArgs("percent_change", args, 2, line, "percent_change(₹100, ₹120) → 20% or percent_change(1000, 1150) → 15%");
        const [oldVal, newVal] = args;
        let oldAmt, newAmt;
        if (oldVal instanceof GlangCurrency && newVal instanceof GlangCurrency) {
          if (oldVal.currency !== newVal.currency) {
            throw new GlangRuntimeError(
              `percent_change() got mixed currencies (${oldVal.currency} and ${newVal.currency}).`,
              line, "Use the same currency for both values."
            );
          }
          oldAmt = oldVal.amount; newAmt = newVal.amount;
        } else if (typeof oldVal === "number" && typeof newVal === "number") {
          oldAmt = oldVal; newAmt = newVal;
        } else {
          throw new GlangRuntimeError(
            `percent_change() needs both values to be the same type (both money or both numbers).`,
            line, "Example: percent_change(₹100, ₹120) or percent_change(100, 120)"
          );
        }
        if (oldAmt === 0) throw new GlangRuntimeError("percent_change() can't divide by zero — the old value is 0.", line, null);
        return new GlangPercent((newAmt - oldAmt) / oldAmt);
      },
    });

    this.globals.define("format_inr", {
      __builtin__: true, name: "format_inr",
      call: (args, line) => {
        // format_inr(amount) → "5 lakh", "1.2 crore" etc.
        requireArgs("format_inr", args, 1, line, "format_inr(₹500000) → \"5 lakh\"");
        const [val] = args;
        requireCurrency("format_inr", val, "a money value", line);
        if (val.currency !== "INR") throw new GlangRuntimeError(
          `format_inr() is for Indian Rupees (₹) only, but got ${val.currency}.`, line, null
        );
        const amt = val.amount;
        if (amt >= 10000000) return `${(amt / 10000000).toFixed(2).replace(/\.?0+$/, "")} crore`;
        if (amt >= 100000)   return `${(amt / 100000).toFixed(2).replace(/\.?0+$/, "")} lakh`;
        if (amt >= 1000)     return `${(amt / 1000).toFixed(2).replace(/\.?0+$/, "")} thousand`;
        return val.toString();
      },
    });

    this.globals.define("weighted_average", {
      __builtin__: true, name: "weighted_average",
      call: (args, line) => {
        // weighted_average(values_list, weights_list) → weighted average
        requireArgs("weighted_average", args, 2, line, "weighted_average([₹100, ₹200], [3, 1]) → weighted avg price");
        const [values, weights] = args;
        requireList("weighted_average", values, "the values list (first)", line);
        requireList("weighted_average", weights, "the weights list (second)", line);
        if (values.items.length !== weights.items.length) {
          throw new GlangRuntimeError(
            `weighted_average() needs both lists to be the same length, but got ${values.items.length} values and ${weights.items.length} weights.`,
            line, "Every value needs a matching weight."
          );
        }
        let weightedSum = 0, totalWeight = 0;
        let isCurrency = false; let currency = null;
        for (let i = 0; i < values.items.length; i++) {
          const v = values.items[i];
          const w = weights.items[i];
          if (typeof w !== "number") throw new GlangRuntimeError("Weights must be plain numbers.", line, null);
          if (v instanceof GlangCurrency) { isCurrency = true; currency = v.currency; weightedSum += v.amount * w; }
          else if (typeof v === "number") { weightedSum += v * w; }
          else throw new GlangRuntimeError("Values must be numbers or money.", line, null);
          totalWeight += w;
        }
        if (totalWeight === 0) throw new GlangRuntimeError("Total weight is zero — can't compute weighted average.", line, null);
        const result = weightedSum / totalWeight;
        return isCurrency ? new GlangCurrency(result, currency) : result;
      },
    });

    // ── PHASE 3: STOCK MARKET ─────────────────────────────────────────────
    // stock(symbol) returns a GlangStock object with price, pe, 52w high/low etc.
    // On user's machine this fetches live data from Yahoo Finance.
    // The __stockFetcher can be swapped for live vs mock depending on environment.

    const self = this;

    this.globals.define("stock", {
      __builtin__: true, name: "stock",
      call: (args, line) => {
        requireArgs("stock", args, 1, line, 'stock("TCS") or stock("RELIANCE") → live stock data');
        const [sym] = args;
        if (typeof sym !== "string") {
          throw new GlangRuntimeError(
            'stock() needs a stock symbol as a word, like stock("TCS") or stock("RELIANCE.NS")',
            line, null
          );
        }
        // Return a GlangStock placeholder — actual data fetched lazily when properties accessed
        return new GlangStock(sym.toUpperCase(), line);
      },
    });

    this.globals.define("portfolio_value", {
      __builtin__: true, name: "portfolio_value",
      call: (args, line) => {
        requireArgs("portfolio_value", args, 1, line, "portfolio_value([stock(\"TCS\"), stock(\"INFY\")]) → total portfolio value");
        const [list] = args;
        requireList("portfolio_value", list, "a list of stocks", line);
        let total = 0; let currency = "INR";
        for (const item of list.items) {
          if (!(item instanceof GlangStock)) {
            throw new GlangRuntimeError(
              `portfolio_value() needs a list of stocks, but found ${typeName(item)}.`,
              line, 'Build a list with stock() calls: [stock("TCS"), stock("INFY")]'
            );
          }
          total += item.getPrice();
          currency = item.getCurrency();
        }
        return new GlangCurrency(total, currency);
      },
    });

    this.globals.define("stock_return", {
      __builtin__: true, name: "stock_return",
      call: (args, line) => {
        requireArgs("stock_return", args, 2, line, 'stock_return("TCS", ₹3200) → your return since you bought');
        const [sym, buyPrice] = args;
        if (typeof sym !== "string") throw new GlangRuntimeError('First value must be a stock symbol like "TCS"', line, null);
        requireCurrency("stock_return", buyPrice, "your buy price (second value)", line);
        const s = new GlangStock(sym.toUpperCase(), line);
        const currentPrice = new GlangCurrency(s.getPrice(), s.getCurrency());
        return new GlangPercent((currentPrice.amount - buyPrice.amount) / buyPrice.amount);
      },
    });

    // ── PHASE 3 ENHANCEMENTS ─────────────────────────────────────────────

    this.globals.define("history", {
      __builtin__: true, name: "history",
      call: (args, line) => {
        // history(stock, days) → list of closing prices as currency values
        requireArgs("history", args, 2, line, 'history(stock("TCS"), 30) → last 30 days of closing prices');
        const [s, days] = args;
        if (!(s instanceof GlangStock)) throw new GlangRuntimeError('history() needs a stock as its first value.', line, 'Try: history(stock("TCS"), 30)');
        requireNumber("history", days, "number of days (second value)", line);
        if (days < 1 || days > 365) throw new GlangRuntimeError('history() days must be between 1 and 365.', line, null);
        const prices = s.getHistory(Math.ceil(days));
        const currency = s.getCurrency();
        return new GlangList(prices.map(p => new GlangCurrency(p, currency)));
      },
    });

    this.globals.define("moving_average", {
      __builtin__: true, name: "moving_average",
      call: (args, line) => {
        // moving_average(prices_list, window) → list of moving averages
        requireArgs("moving_average", args, 2, line, 'moving_average(history(stock("TCS"), 50), 20) → 20-day moving average');
        const [prices, window] = args;
        requireList("moving_average", prices, "a list of prices (first value)", line);
        requireNumber("moving_average", window, "the window size (second value)", line);
        if (window < 1) throw new GlangRuntimeError('Moving average window must be at least 1.', line, null);
        if (window > prices.items.length) throw new GlangRuntimeError(
          `Moving average window (${window}) is larger than the number of prices (${prices.items.length}).`,
          line, `Use a smaller window, or fetch more history days.`
        );
        const isCurrency = prices.items[0] instanceof GlangCurrency;
        const currency = isCurrency ? prices.items[0].currency : null;
        const raw = prices.items.map(p => p instanceof GlangCurrency ? p.amount : p);
        const result = [];
        for (let i = window - 1; i < raw.length; i++) {
          const slice = raw.slice(i - window + 1, i + 1);
          const avg = slice.reduce((a, b) => a + b, 0) / window;
          result.push(isCurrency ? new GlangCurrency(avg, currency) : avg);
        }
        return new GlangList(result);
      },
    });

    this.globals.define("compare_stocks", {
      __builtin__: true, name: "compare_stocks",
      call: (args, line) => {
        // compare_stocks([stock1, stock2, ...]) → prints side-by-side table
        requireArgs("compare_stocks", args, 1, line, 'compare_stocks([stock("TCS"), stock("INFY")]) → side-by-side comparison');
        const [list] = args;
        requireList("compare_stocks", list, "a list of stocks", line);
        const header = `${"Stock".padEnd(16)} ${"Price".padEnd(12)} ${"Change".padEnd(10)} ${"PE".padEnd(8)} ${"52W High".padEnd(12)} ${"52W Low".padEnd(12)} Sector`;
        const divider = "─".repeat(header.length);
        console.log("\n" + header);
        console.log(divider);
        for (const s of list.items) {
          if (!(s instanceof GlangStock)) throw new GlangRuntimeError('compare_stocks() needs a list of stocks.', line, null);
          const pe = s.getPE();
          const chg = s.getChangePct() * 100;
          const sign = chg >= 0 ? "+" : "";
          const row = [
            s.symbol.padEnd(16),
            new GlangCurrency(s.getPrice(), s.getCurrency()).toString().padEnd(12),
            (`${sign}${chg.toFixed(2)}%`).padEnd(10),
            (pe !== null ? pe.toFixed(1) : "N/A").padEnd(8),
            new GlangCurrency(s.getHigh52(), s.getCurrency()).toString().padEnd(12),
            new GlangCurrency(s.getLow52(), s.getCurrency()).toString().padEnd(12),
            s.getSector(),
          ].join(" ");
          console.log(row);
        }
        console.log(divider);
        return null;
      },
    });

    this.globals.define("top_gainer", {
      __builtin__: true, name: "top_gainer",
      call: (args, line) => {
        requireArgs("top_gainer", args, 1, line, 'top_gainer([stock("TCS"), stock("INFY")]) → stock with best return today');
        const [list] = args;
        requireList("top_gainer", list, "a list of stocks", line);
        let best = null, bestChg = -Infinity;
        for (const s of list.items) {
          if (!(s instanceof GlangStock)) throw new GlangRuntimeError('top_gainer() needs a list of stocks.', line, null);
          const chg = s.getChangePct();
          if (chg > bestChg) { bestChg = chg; best = s; }
        }
        return best;
      },
    });

    this.globals.define("top_loser", {
      __builtin__: true, name: "top_loser",
      call: (args, line) => {
        requireArgs("top_loser", args, 1, line, 'top_loser([stock("TCS"), stock("INFY")]) → stock with worst return today');
        const [list] = args;
        requireList("top_loser", list, "a list of stocks", line);
        let worst = null, worstChg = Infinity;
        for (const s of list.items) {
          if (!(s instanceof GlangStock)) throw new GlangRuntimeError('top_loser() needs a list of stocks.', line, null);
          const chg = s.getChangePct();
          if (chg < worstChg) { worstChg = chg; worst = s; }
        }
        return worst;
      },
    });

    this.globals.define("portfolio_pnl", {
      __builtin__: true, name: "portfolio_pnl",
      call: (args, line) => {
        // portfolio_pnl(symbols_list, buy_prices_list, quantities_list)
        // → prints full P&L table and returns total gain/loss
        if (args.length !== 3) throw new GlangRuntimeError(
          `portfolio_pnl() needs 3 lists: symbols, buy prices, quantities.`, line,
          'portfolio_pnl(["TCS","INFY"], [₹3200, ₹1400], [10, 20])'
        );
        const [symbols, buyPrices, quantities] = args;
        requireList("portfolio_pnl", symbols, "stock symbols list (first)", line);
        requireList("portfolio_pnl", buyPrices, "buy prices list (second)", line);
        requireList("portfolio_pnl", quantities, "quantities list (third)", line);
        const n = symbols.items.length;
        if (buyPrices.items.length !== n || quantities.items.length !== n) {
          throw new GlangRuntimeError('All three lists must have the same number of items.', line, null);
        }
        const header = `${"Stock".padEnd(14)} ${"Qty".padEnd(6)} ${"Buy".padEnd(10)} ${"Now".padEnd(10)} ${"Invested".padEnd(12)} ${"Value".padEnd(12)} ${"Gain/Loss".padEnd(12)} Return`;
        console.log("\n── PORTFOLIO P&L ─────────────────────────────────────────────");
        console.log(header);
        console.log("─".repeat(header.length));
        let totalInvested = 0, totalValue = 0;
        let currency = "INR";
        for (let i = 0; i < n; i++) {
          const sym = symbols.items[i];
          const buy = buyPrices.items[i];
          const qty = quantities.items[i];
          if (typeof sym !== "string") throw new GlangRuntimeError('Symbols must be text like "TCS".', line, null);
          requireCurrency("portfolio_pnl", buy, `buy price for ${sym}`, line);
          requireNumber("portfolio_pnl", qty, `quantity for ${sym}`, line);
          const s = new GlangStock(sym.toUpperCase(), line);
          currency = s.getCurrency();
          const cur = s.getPrice();
          const invested = buy.amount * qty;
          const value = cur * qty;
          const gain = value - invested;
          const ret = (gain / invested) * 100;
          const sign = gain >= 0 ? "+" : "";
          totalInvested += invested;
          totalValue += value;
          const fmt = (n, c) => new GlangCurrency(n, c).toString();
          console.log([
            sym.toUpperCase().padEnd(14),
            String(qty).padEnd(6),
            fmt(buy.amount, currency).padEnd(10),
            fmt(cur, currency).padEnd(10),
            fmt(invested, currency).padEnd(12),
            fmt(value, currency).padEnd(12),
            (`${sign}${fmt(Math.abs(gain), currency)}`).padEnd(12),
            `${sign}${ret.toFixed(2)}%`,
          ].join(" "));
        }
        const totalGain = totalValue - totalInvested;
        const totalRet = (totalGain / totalInvested) * 100;
        const sign = totalGain >= 0 ? "+" : "";
        console.log("─".repeat(header.length));
        const fmt = (n) => new GlangCurrency(Math.abs(n), currency).toString();
        console.log(`TOTAL${" ".repeat(37)}${new GlangCurrency(totalInvested, currency).toString().padEnd(12)}${new GlangCurrency(totalValue, currency).toString().padEnd(12)}${(sign + fmt(totalGain)).padEnd(12)}${sign}${totalRet.toFixed(2)}%`);
        console.log("");
        return new GlangCurrency(totalGain, currency);
      },
    });

    // ── File I/O ─────────────────────────────────────────────────────────
    // Only registered for the plain CLI interpreter (see allowFileIO in
    // the constructor) — `glang app` scripts never get these builtins at
    // all, so a shared/untrusted script running in the sandbox has no way
    // to touch the host filesystem, full stop.
    if (this.allowFileIO) {
      // Resolves a user-given path against the running script's own
      // directory (same base as local module imports), unless it's
      // already absolute.
      const resolveFsPath = (p) => {
        return path.isAbsolute(p) ? p : path.resolve(this.currentBaseDir(), p);
      };

      this.globals.define("read_file", {
        __builtin__: true, name: "read_file",
        call: (args, line) => {
          requireArgs("read_file", args, 1, line, `read_file("data.txt") returns the file's contents as text.`);
          const raw = args[0];
          if (typeof raw !== "string") throw new GlangRuntimeError(
            `read_file() needs a text file path, but got ${typeName(raw)}.`, line,
            `Example: read_file("data.txt")`
          );
          const full = resolveFsPath(raw);
          try {
            return fs.readFileSync(full, "utf8");
          } catch (e) {
            if (e.code === "ENOENT") throw new GlangRuntimeError(
              `Can't find the file "${raw}".`, line,
              `Check the path and spelling — by default, paths are relative to your script's own folder.`
            );
            throw new GlangRuntimeError(
              `Couldn't read "${raw}": ${e.message}.`, line,
              `Check that the file exists and that you have permission to read it.`
            );
          }
        },
      });

      this.globals.define("write_file", {
        __builtin__: true, name: "write_file",
        call: (args, line) => {
          requireArgs("write_file", args, 2, line, `write_file("out.txt", "hello") writes (or overwrites) a file.`);
          const [raw, content] = args;
          if (typeof raw !== "string") throw new GlangRuntimeError(
            `write_file() needs a text file path, but got ${typeName(raw)}.`, line, null
          );
          if (typeof content !== "string") throw new GlangRuntimeError(
            `write_file() needs text to write, but got ${typeName(content)}.`, line,
            `Try converting first, e.g. write_file("out.txt", str(total))`
          );
          const full = resolveFsPath(raw);
          try {
            fs.writeFileSync(full, content, "utf8");
          } catch (e) {
            throw new GlangRuntimeError(
              `Couldn't write to "${raw}": ${e.message}.`, line,
              `Check that the folder exists and that you have permission to write there.`
            );
          }
          return null;
        },
      });

      this.globals.define("append_file", {
        __builtin__: true, name: "append_file",
        call: (args, line) => {
          requireArgs("append_file", args, 2, line, `append_file("log.txt", "another line\\n") adds text to the end of a file, creating it if needed.`);
          const [raw, content] = args;
          if (typeof raw !== "string") throw new GlangRuntimeError(
            `append_file() needs a text file path, but got ${typeName(raw)}.`, line, null
          );
          if (typeof content !== "string") throw new GlangRuntimeError(
            `append_file() needs text to add, but got ${typeName(content)}.`, line,
            `Try converting first, e.g. append_file("log.txt", str(total))`
          );
          const full = resolveFsPath(raw);
          try {
            fs.appendFileSync(full, content, "utf8");
          } catch (e) {
            throw new GlangRuntimeError(
              `Couldn't write to "${raw}": ${e.message}.`, line,
              `Check that the folder exists and that you have permission to write there.`
            );
          }
          return null;
        },
      });

      this.globals.define("file_exists", {
        __builtin__: true, name: "file_exists",
        call: (args, line) => {
          requireArgs("file_exists", args, 1, line, `file_exists("data.txt") → true or false`);
          const raw = args[0];
          if (typeof raw !== "string") throw new GlangRuntimeError(
            `file_exists() needs a text file path, but got ${typeName(raw)}.`, line, null
          );
          return fs.existsSync(resolveFsPath(raw));
        },
      });

      // Minimal CSV parser: handles quoted fields (with "" as an escaped
      // quote inside a quoted field) and commas/newlines inside quotes.
      // No external dependency — this is exactly the "hand-rolled CSV
      // parsing with split()" gap this builtin exists to remove for
      // students, so it needs to actually handle real CSV, not just the
      // simple comma case.
      const parseCsv = (text) => {
        const rows = [];
        let row = [];
        let field = "";
        let inQuotes = false;
        let i = 0;
        const pushField = () => { row.push(field); field = ""; };
        const pushRow = () => { pushField(); rows.push(row); row = []; };
        while (i < text.length) {
          const ch = text[i];
          if (inQuotes) {
            if (ch === '"') {
              if (text[i + 1] === '"') { field += '"'; i += 2; continue; }
              inQuotes = false; i++; continue;
            }
            field += ch; i++; continue;
          }
          if (ch === '"') { inQuotes = true; i++; continue; }
          if (ch === ",") { pushField(); i++; continue; }
          if (ch === "\r") { i++; continue; }
          if (ch === "\n") { pushRow(); i++; continue; }
          field += ch; i++;
        }
        // Trailing field/row (file may or may not end with a newline)
        if (field.length > 0 || row.length > 0) pushRow();
        // Drop a single trailing fully-empty row (common with a final newline)
        if (rows.length > 0 && rows[rows.length - 1].length === 1 && rows[rows.length - 1][0] === "") {
          rows.pop();
        }
        return rows;
      };

      const csvFieldOut = (value) => {
        const s = describeValueAsPlainString(value);
        if (/[",\n]/.test(s)) return `"${s.replace(/"/g, '""')}"`;
        return s;
      };

      this.globals.define("read_csv", {
        __builtin__: true, name: "read_csv",
        call: (args, line) => {
          requireArgs("read_csv", args, 1, line, `read_csv("students.csv") → a list of dictionaries, one per row, keyed by the header row.`);
          const raw = args[0];
          if (typeof raw !== "string") throw new GlangRuntimeError(
            `read_csv() needs a text file path, but got ${typeName(raw)}.`, line, null
          );
          const full = resolveFsPath(raw);
          let text;
          try {
            text = fs.readFileSync(full, "utf8");
          } catch (e) {
            if (e.code === "ENOENT") throw new GlangRuntimeError(
              `Can't find the file "${raw}".`, line,
              `Check the path and spelling — by default, paths are relative to your script's own folder.`
            );
            throw new GlangRuntimeError(`Couldn't read "${raw}": ${e.message}.`, line, null);
          }
          const rows = parseCsv(text);
          if (rows.length === 0) return new GlangList([]);
          const headers = rows[0];
          const result = [];
          for (let r = 1; r < rows.length; r++) {
            const map = new Map();
            headers.forEach((h, idx) => map.set(h, rows[r][idx] !== undefined ? rows[r][idx] : ""));
            result.push(new GlangDict(map));
          }
          return new GlangList(result);
        },
      });

      this.globals.define("write_csv", {
        __builtin__: true, name: "write_csv",
        call: (args, line) => {
          requireArgs("write_csv", args, 2, line, `write_csv("out.csv", students) writes a list of dictionaries as a CSV file.`);
          const [raw, data] = args;
          if (typeof raw !== "string") throw new GlangRuntimeError(
            `write_csv() needs a text file path, but got ${typeName(raw)}.`, line, null
          );
          requireList("write_csv", data, "the data (second argument)", line);
          let text = "";
          if (data.items.length > 0) {
            if (!(data.items[0] instanceof GlangDict)) {
              throw new GlangRuntimeError(
                `write_csv() needs a list of dictionaries (one per row), but the first item is ${typeName(data.items[0])}.`, line,
                `Example: write_csv("out.csv", [{name: "Alex", score: 90}, {name: "Sam", score: 85}])`
              );
            }
            const headers = [...data.items[0].map.keys()];
            text += headers.map(csvFieldOut).join(",") + "\n";
            for (const item of data.items) {
              if (!(item instanceof GlangDict)) throw new GlangRuntimeError(
                `write_csv() needs every item to be a dictionary with the same keys, but found ${typeName(item)}.`, line, null
              );
              text += headers.map((h) => csvFieldOut(item.map.has(h) ? item.map.get(h) : "")).join(",") + "\n";
            }
          }
          const full = resolveFsPath(raw);
          try {
            fs.writeFileSync(full, text, "utf8");
          } catch (e) {
            throw new GlangRuntimeError(
              `Couldn't write to "${raw}": ${e.message}.`, line,
              `Check that the folder exists and that you have permission to write there.`
            );
          }
          return null;
        },
      });
    }

  }


  interpret(program, scriptPath) {
    if (scriptPath) {
      const absScript = path.resolve(scriptPath);
      this.baseDirStack = [path.dirname(absScript)];
      this.moduleImportStack = [absScript];
    }
    for (const stmt of program.body) {
      try {
        this.execute(stmt, this.globals);
      } catch (signal) {
        if (signal instanceof BreakSignal) {
          throw new GlangRuntimeError(
            `"break" can only be used inside a loop (repeat, while, or for).`,
            stmt.line || 0,
            "Move this 'break' inside a loop body, or remove it."
          );
        }
        if (signal instanceof ContinueSignal) {
          throw new GlangRuntimeError(
            `"continue" can only be used inside a loop (repeat, while, or for).`,
            stmt.line || 0,
            "Move this 'continue' inside a loop body, or remove it."
          );
        }
        if (signal instanceof ReturnSignal) {
          throw new GlangRuntimeError(
            `"return" can only be used inside a function.`,
            stmt.line || 0,
            "Move this 'return' inside a 'fn ...():' body, or remove it."
          );
        }
        throw signal;
      }
    }
  }

  execute(node, env) {
    switch (node.type) {
      case "Let":
        return this.execLet(node, env);
      case "Const":
        return this.execConst(node, env);
      case "Assign":
        return this.execAssign(node, env);
      case "IndexAssign":
        return this.execIndexAssign(node, env);
      case "PropertyAssign":
        return this.execPropertyAssign(node, env);
      case "FnDecl":
        return this.execFnDecl(node, env);
      case "Return":
        throw new ReturnSignal(node.value ? this.evaluate(node.value, env) : null);
      case "If":
        return this.execIf(node, env);
      case "Repeat":
        return this.execRepeat(node, env);
      case "While":
        return this.execWhile(node, env);
      case "Break":
        throw new BreakSignal();
      case "Continue":
        throw new ContinueSignal();
      case "ForIn":
        return this.execForIn(node, env);
      case "Try":
        return this.execTry(node, env);
      case "Throw":
        return this.execThrow(node, env);
      case "Import":
        return this.execImport(node, env);
      case "ExprStatement":
        this.evaluate(node.expr, env);
        return;
      default:
        throw new GlangRuntimeError(
          `Internal error: don't know how to run a "${node.type}" statement.`,
          node.line || 0,
          "This is likely a bug in Glang itself, not your code."
        );
    }
  }

  execLet(node, env) {
    const value = this.evaluate(node.value, env);
    env.define(node.name, value);
  }

  execConst(node, env) {
    const value = this.evaluate(node.value, env);
    env.defineConst(node.name, value);
  }

  execAssign(node, env) {
    const value = this.evaluate(node.value, env);
    env.assign(node.name, value, node.line);
  }

  execIndexAssign(node, env) {
    const obj = this.evaluate(node.object, env);
    const idx = this.evaluate(node.index, env);
    const value = this.evaluate(node.value, env);

    if (obj instanceof GlangDict) {
      if (typeof idx !== "string") {
        throw new GlangRuntimeError(
          `Dictionary keys must be text, but got ${typeName(idx)} (${describeValue(idx)}).`,
          node.line,
          `Try something like my_dict["${describeValueAsPlainString(idx)}"] = ...`
        );
      }
      obj.map.set(idx, value);
      return;
    }

    if (obj instanceof GlangList) {
      if (typeof idx !== "number" || !Number.isInteger(idx)) {
        throw new GlangRuntimeError(
          `List index must be a whole number, but got ${typeName(idx)} (${describeValue(idx)}).`,
          node.line,
          "Try something like my_list[0] = ..."
        );
      }
      if (idx < 0 || idx >= obj.items.length) {
        throw new GlangRuntimeError(
          `Index ${idx} is out of range — this list only has ${obj.items.length} item${obj.items.length === 1 ? "" : "s"} (valid indexes are 0 to ${obj.items.length - 1}).`,
          node.line,
          obj.items.length === 0
            ? "This list is empty, so there's nothing to update. Use append() to add new items."
            : `Try an index between 0 and ${obj.items.length - 1}.`
        );
      }
      obj.items[idx] = value;
      return;
    }

    throw new GlangRuntimeError(
      `Can't use [...] = ... on ${typeName(obj)} (${describeValue(obj)}) — only lists and dictionaries support this.`,
      node.line,
      "Make sure the value before [ ] is actually a list or dictionary."
    );
  }

  execPropertyAssign(node, env) {
    const obj = this.evaluate(node.object, env);
    const value = this.evaluate(node.value, env);

    if (obj instanceof GlangDict) {
      obj.map.set(node.property, value);
      return;
    }

    throw new GlangRuntimeError(
      `Can't set ".${node.property}" on ${typeName(obj)} (${describeValue(obj)}) — only dictionaries support this.`,
      node.line,
      `Try my_dict["${node.property}"] = ... instead, or check that the value is really a dictionary.`
    );
  }

  execFnDecl(node, env) {
    const fn = new GlangFunction(node, env);
    env.define(node.name, fn);
  }

  execIf(node, env) {
    const condition = this.evaluate(node.condition, env);
    if (this.isTruthy(condition, node.line)) {
      this.executeBlock(node.thenBranch, new Environment(env));
    } else if (node.elseBranch) {
      this.executeBlock(node.elseBranch, new Environment(env));
    }
  }

  execRepeat(node, env) {
    const countVal = this.evaluate(node.count, env);
    if (typeof countVal !== "number") {
      throw new GlangRuntimeError(
        `"repeat ... times" needs a number, but got ${typeName(countVal)}.`,
        node.line,
        `Try something like: repeat 5 times:`
      );
    }
    if (!Number.isInteger(countVal) || countVal < 0) {
      throw new GlangRuntimeError(
        `"repeat ... times" needs a whole number that's 0 or more, but got ${countVal}.`,
        node.line,
        "Try a whole number like: repeat 3 times:"
      );
    }
    for (let i = 0; i < countVal; i++) {
      try {
        this.executeBlock(node.body, new Environment(env));
      } catch (signal) {
        if (signal instanceof BreakSignal) break;
        if (signal instanceof ContinueSignal) continue;
        throw signal;
      }
    }
  }

  execWhile(node, env) {
    let iterations = 0;
    while (true) {
      const condVal = this.evaluate(node.condition, env);
      if (!this.isTruthy(condVal, node.line)) break;

      iterations++;
      if (iterations > MAX_LOOP_ITERATIONS) {
        throw new GlangRuntimeError(
          `This "while" loop ran more than ${MAX_LOOP_ITERATIONS.toLocaleString()} times without stopping.`,
          node.line,
          "This usually means the loop's condition never becomes false. Double-check that something inside the loop body changes a value the condition depends on."
        );
      }

      try {
        this.executeBlock(node.body, new Environment(env));
      } catch (signal) {
        if (signal instanceof BreakSignal) break;
        if (signal instanceof ContinueSignal) continue;
        throw signal;
      }
    }
  }

  execForIn(node, env) {
    const iterable = this.evaluate(node.iterable, env);

    if (iterable instanceof GlangDict) {
      for (const key of iterable.map.keys()) {
        const loopEnv = new Environment(env);
        loopEnv.define(node.varName, key);
        try {
          this.executeBlock(node.body, loopEnv);
        } catch (signal) {
          if (signal instanceof BreakSignal) break;
          if (signal instanceof ContinueSignal) continue;
          throw signal;
        }
      }
      return;
    }

    if (!(iterable instanceof GlangList)) {
      throw new GlangRuntimeError(
        `"for ${node.varName} in ..." needs a list or dictionary, but got ${typeName(iterable)} (${describeValue(iterable)}).`,
        node.line,
        `Try something like: for item in [1, 2, 3]: — or loop over a variable that holds a list or dictionary.`
      );
    }
    for (const item of iterable.items) {
      const loopEnv = new Environment(env);
      loopEnv.define(node.varName, item);
      try {
        this.executeBlock(node.body, loopEnv);
      } catch (signal) {
        if (signal instanceof BreakSignal) break;
        if (signal instanceof ContinueSignal) continue;
        throw signal;
      }
    }
  }

  // Shared with comprehensions and for-in: returns the plain JS array to
  // loop over for a given iterable value. Iterating a dict yields its
  // keys, matching execForIn's existing behavior.
  compIterableItems(iterable, line, varName) {
    if (iterable instanceof GlangDict) return [...iterable.map.keys()];
    if (iterable instanceof GlangList) return iterable.items;
    throw new GlangRuntimeError(
      `"for ${varName} in ..." needs a list or dictionary, but got ${typeName(iterable)} (${describeValue(iterable)}).`,
      line,
      `Try something like: [x for ${varName} in [1, 2, 3]]`
    );
  }

  evalListComp(node, env) {
    const iterable = this.evaluate(node.iterable, env);
    const items = this.compIterableItems(iterable, node.line, node.varName);
    const result = [];
    for (const item of items) {
      const loopEnv = new Environment(env);
      loopEnv.define(node.varName, item);
      if (node.condition && !this.isTruthy(this.evaluate(node.condition, loopEnv), node.line)) {
        continue;
      }
      result.push(this.evaluate(node.expr, loopEnv));
    }
    return new GlangList(result);
  }

  evalDictComp(node, env) {
    const iterable = this.evaluate(node.iterable, env);
    const items = this.compIterableItems(iterable, node.line, node.varName);
    const map = new Map();
    for (const item of items) {
      const loopEnv = new Environment(env);
      loopEnv.define(node.varName, item);
      if (node.condition && !this.isTruthy(this.evaluate(node.condition, loopEnv), node.line)) {
        continue;
      }
      const key = this.evaluate(node.keyExpr, loopEnv);
      if (typeof key !== "string") {
        throw new GlangRuntimeError(
          `Dictionary keys must be text, but this comprehension produced ${typeName(key)} (${describeValue(key)}).`,
          node.line,
          `Make sure the key expression evaluates to text, e.g. str(${node.varName}): ... for ${node.varName} in ...`
        );
      }
      const value = this.evaluate(node.valueExpr, loopEnv);
      map.set(key, value);
    }
    return new GlangDict(map);
  }

  // try/catch/finally. `finally` always runs, even if the try (or catch)
  // block returns, breaks, continues, or re-throws — that's handled for
  // free by JS's own try/catch/finally underneath this.
  execTry(node, env) {
    try {
      this.executeBlock(node.tryBlock, new Environment(env));
    } catch (err) {
      // Control-flow signals (return/break/continue) aren't errors — let
      // them keep unwinding untouched. The `finally` below still runs.
      if (err instanceof ReturnSignal || err instanceof BreakSignal || err instanceof ContinueSignal) {
        throw err;
      }
      if (!node.catchBlock) {
        throw err;
      }
      const catchEnv = new Environment(env);
      if (node.catchVar) {
        catchEnv.define(node.catchVar, this.toCatchValue(err));
      }
      this.executeBlock(node.catchBlock, catchEnv);
    } finally {
      if (node.finallyBlock) {
        this.executeBlock(node.finallyBlock, new Environment(env));
      }
    }
  }

  execThrow(node, env) {
    const value = this.evaluate(node.value, env);
    throw new GlangThrownValue(value, node.line);
  }

  // Converts whatever got caught into the value a `catch err:` binds.
  // - `throw <value>` in Glang code hands back exactly that value.
  // - An engine error (bad input, missing variable, etc.) becomes a
  //   dictionary with .message / .line, so it's inspectable like any
  //   other Glang value instead of just being a string.
  toCatchValue(err) {
    if (err instanceof GlangThrownValue) return err.value;
    if (err instanceof GlangRuntimeError || err instanceof GlangSyntaxError) {
      const map = new Map();
      map.set("message", err.message);
      map.set("line", err.line ?? null);
      map.set("hint", err.hint || "");
      return new GlangDict(map);
    }
    // A raw JS error slipping through (shouldn't normally happen, but
    // catch it here too rather than letting a crash escape 'try').
    const map = new Map();
    map.set("message", err && err.message ? err.message : String(err));
    map.set("line", null);
    map.set("hint", "");
    return new GlangDict(map);
  }

  execImport(node, env) {
    // Resolve module path:
    // 1. stdlib module (e.g. "finance", "tax", "stocks", "math")
    // 2. community package in packages/community/
    // 3. Relative file path (e.g. "./mymodule.grw") — resolved against
    //    the *importing file's own directory*, not the process's cwd,
    //    so a student's multi-file project works no matter where
    //    `glang run` is invoked from.
    // 4. Absolute path

    const stdlibDir   = path.join(__dirname, "../packages/stdlib");
    const communityDir = path.join(__dirname, "../packages/community");

    let modulePath = null;
    const name = node.module;

    // Try stdlib first
    const stdlibPath = path.join(stdlibDir, name + ".grw");
    if (fs.existsSync(stdlibPath)) {
      modulePath = stdlibPath;
    }

    // Try community packages
    if (!modulePath) {
      const communityPath = path.join(communityDir, name, "index.grw");
      if (fs.existsSync(communityPath)) {
        modulePath = communityPath;
      }
      const communityFlat = path.join(communityDir, name + ".grw");
      if (!modulePath && fs.existsSync(communityFlat)) {
        modulePath = communityFlat;
      }
    }

    // Try as a file path (relative to the importing file's directory, or absolute)
    if (!modulePath) {
      const fileName = name.endsWith(".grw") ? name : name + ".grw";
      const resolved = path.isAbsolute(fileName)
        ? fileName
        : path.resolve(this.currentBaseDir(), fileName);
      if (fs.existsSync(resolved)) {
        modulePath = resolved;
      }
    }

    if (!modulePath) {
      throw new GlangRuntimeError(
        `Can't find module "${name}".`,
        node.line,
        `Built-in modules: finance, tax, stocks, math\nFor a local file: import "./mymodule.grw"\nInstall community packages with: glang install <package-name>`
      );
    }

    const absPath = path.resolve(modulePath);

    // Circular import detection — a.grw importing b.grw importing a.grw
    // would otherwise infinite-loop (or stack-overflow) re-running the
    // module. Name the cycle explicitly instead of crashing.
    if (this.moduleImportStack.includes(absPath)) {
      const chain = [...this.moduleImportStack, absPath].map((p) => path.basename(p)).join(" → ");
      throw new GlangRuntimeError(
        `Circular import: ${chain}`,
        node.line,
        `"${path.basename(absPath)}" ends up importing itself through this chain. Move the code both modules need into a third module that they each import instead.`
      );
    }

    // Re-import caching: the same module imported from two different
    // files in one run executes once (keyed by its resolved absolute
    // path) and every importer shares the same exports — otherwise a
    // module with side effects (like show()) would run its top-level
    // code again for every place that imports it.
    let exportsMap = this.moduleCache.get(absPath);
    if (!exportsMap) {
      const source = fs.readFileSync(absPath, "utf8");
      const { Lexer }  = require("./lexer.js");
      const { Parser } = require("./parser.js");

      let ast;
      try {
        const tokens = new Lexer(source).tokenize();
        ast = new Parser(tokens).parse();
      } catch (err) {
        throw new GlangRuntimeError(
          `Error loading module "${name}": ${err.message}`,
          node.line,
          null
        );
      }

      // Run the module — all its fn/let definitions go into a module env
      const moduleEnv = new Environment(this.globals);
      this.moduleImportStack.push(absPath);
      this.baseDirStack.push(path.dirname(absPath));
      try {
        this.executeBlock(ast.body, moduleEnv);
      } catch (err) {
        // A stray break/continue/return at a module's top level (outside
        // any loop/function) isn't a JS-level error — give it the same
        // friendly treatment as the top-level interpret() loop does.
        if (err instanceof BreakSignal) {
          throw new GlangRuntimeError(
            `"break" can only be used inside a loop (repeat, while, or for).`,
            node.line, "Move this 'break' inside a loop body, or remove it."
          );
        }
        if (err instanceof ContinueSignal) {
          throw new GlangRuntimeError(
            `"continue" can only be used inside a loop (repeat, while, or for).`,
            node.line, "Move this 'continue' inside a loop body, or remove it."
          );
        }
        if (err instanceof ReturnSignal) {
          throw new GlangRuntimeError(
            `"return" can only be used inside a function.`,
            node.line, "Move this 'return' inside a 'fn ...():' body, or remove it."
          );
        }
        // Don't re-wrap an error that's already a friendly Glang error
        // (e.g. a circular-import error surfacing from a nested import,
        // or a normal runtime error inside the module) — otherwise each
        // level of nested import piles on another "Error running
        // module..." prefix and buries the actual message.
        if (err instanceof GlangRuntimeError || err instanceof GlangSyntaxError) {
          throw err;
        }
        throw new GlangRuntimeError(
          `Error running module "${name}": ${err.message}`,
          node.line,
          null
        );
      } finally {
        this.baseDirStack.pop();
        this.moduleImportStack.pop();
      }

      exportsMap = moduleEnv.vars;
      this.moduleCache.set(absPath, exportsMap);
    }

    // Export all defined names from the module into the caller's env
    // If alias is provided: env.alias = { all module exports }
    // If no alias: merge all exports directly into env
    if (node.alias) {
      // import finance as fin  →  fin.rule_of_72(...) etc.
      const ns = new GlangNamespace(name, exportsMap);
      env.define(node.alias, ns);
    } else {
      // import finance  →  all functions available directly
      for (const [key, val] of exportsMap.entries()) {
        env.define(key, val);
      }
    }
  }

  executeBlock(statements, env) {
    for (const stmt of statements) {
      this.execute(stmt, env);
    }
  }

  // --- Expression evaluation ---------------------------------------------

  evaluate(node, env) {
    switch (node.type) {
      case "NumberLit":
        return node.value;
      case "StringLit":
        return node.value;
      case "BoolLit":
        return node.value;
      case "CurrencyLit":
        return new GlangCurrency(node.amount, node.currency);
      case "PercentLit":
        return new GlangPercent(node.value);
      case "Variable":
        return env.get(node.name, node.line);
      case "Unary":
        return this.evalUnary(node, env);
      case "Binary":
        return this.evalBinary(node, env);
      case "Logical":
        return this.evalLogical(node, env);
      case "Call":
        return this.evalCall(node, env);
      case "ListLit":
        return new GlangList(node.elements.map((el) => this.evaluate(el, env)));
      case "DictLit": {
        const map = new Map();
        for (const { key, value } of node.pairs) {
          map.set(key, this.evaluate(value, env));
        }
        return new GlangDict(map);
      }
      case "ListComp":
        return this.evalListComp(node, env);
      case "DictComp":
        return this.evalDictComp(node, env);
      case "Index":
        return this.evalIndex(node, env);
      case "PropertyAccess":
        return this.evalProperty(node, env);
      case "Ternary":
        return this.isTruthy(this.evaluate(node.condition, env), node.line)
          ? this.evaluate(node.thenExpr, env)
          : this.evaluate(node.elseExpr, env);
      case "Interpolation":
        return node.parts
          .map((part) =>
            part.kind === "str"
              ? part.value
              : describeValueAsPlainString(this.evaluate(part.value, env))
          )
          .join("");
      default:
        throw new GlangRuntimeError(
          `Internal error: don't know how to evaluate a "${node.type}" expression.`,
          node.line || 0,
          "This is likely a bug in Glang itself, not your code."
        );
    }
  }

  evalUnary(node, env) {
    const right = this.evaluate(node.right, env);
    if (node.op === "-") {
      if (typeof right === "number") return -right;
      if (right instanceof GlangCurrency) return new GlangCurrency(-right.amount, right.currency);
      if (right instanceof GlangPercent) return new GlangPercent(-right.value);
      throw new GlangRuntimeError(
        `Can't use "-" in front of ${typeName(right)}.`,
        node.line,
        "The minus sign only works on numbers, money, or percentages."
      );
    }
    if (node.op === "not") {
      return !this.isTruthy(right, node.line);
    }
  }

  evalLogical(node, env) {
    const left = this.evaluate(node.left, env);
    if (node.op === "or") {
      if (this.isTruthy(left, node.line)) return left;
      return this.evaluate(node.right, env);
    }
    // and
    if (!this.isTruthy(left, node.line)) return left;
    return this.evaluate(node.right, env);
  }

  evalBinary(node, env) {
    const left = this.evaluate(node.left, env);
    const right = this.evaluate(node.right, env);
    const op = node.op;

    if (["==", "!="].includes(op)) {
      const eq = this.valuesEqual(left, right);
      return op === "==" ? eq : !eq;
    }

    if (["<", "<=", ">", ">="].includes(op)) {
      return this.compare(left, right, op, node.line);
    }

    if (op === "+") return this.add(left, right, node.line);
    if (op === "-") return this.subtract(left, right, node.line);
    if (op === "*") return this.multiply(left, right, node.line);
    if (op === "/") return this.divide(left, right, node.line);
  }

  // --- Arithmetic with type rules for currency/percent --------------------
  // Rules:
  //   number + number -> number
  //   string + string -> string (concatenation)
  //   currency + currency (same currency) -> currency
  //   currency + currency (different currency) -> friendly error
  //   currency + number -> friendly error (ambiguous; be explicit)
  //   currency * percent -> currency (e.g. balance * rate)
  //   percent + percent -> percent
  //   number * percent -> number
  //   string + number/currency/etc -> friendly error (must str() first)

  add(left, right, line) {
    if (typeof left === "number" && typeof right === "number") return left + right;
    if (typeof left === "string" && typeof right === "string") return left + right;

    if (left instanceof GlangCurrency && right instanceof GlangCurrency) {
      if (left.currency !== right.currency) {
        throw new GlangRuntimeError(
          `Can't add ${left.currency} and ${right.currency} directly — they're different currencies.`,
          line,
          `Convert one first, e.g. convert(${describeValue(right)}, to: "${left.currency}")`
        );
      }
      return new GlangCurrency(left.amount + right.amount, left.currency);
    }

    if (left instanceof GlangPercent && right instanceof GlangPercent) {
      return new GlangPercent(left.value + right.value);
    }

    if (typeof left === "string" || typeof right === "string") {
      throw new GlangRuntimeError(
        `Hold on! You tried to combine ${typeName(left)} (${describeValue(left)}) and ${typeName(right)} (${describeValue(right)}) using +.`,
        line,
        `Words and other types don't combine directly. Try converting first, e.g. str(...) around the non-text value.`
      );
    }

    throw new GlangRuntimeError(
      `Can't add ${typeName(left)} (${describeValue(left)}) and ${typeName(right)} (${describeValue(right)}) together.`,
      line,
      "Check that both sides are the same kind of thing (both numbers, both money in the same currency, or both percentages)."
    );
  }

  subtract(left, right, line) {
    if (typeof left === "number" && typeof right === "number") return left - right;

    if (left instanceof GlangCurrency && right instanceof GlangCurrency) {
      if (left.currency !== right.currency) {
        throw new GlangRuntimeError(
          `Can't subtract ${right.currency} from ${left.currency} directly — they're different currencies.`,
          line,
          `Convert one first, e.g. convert(${describeValue(right)}, to: "${left.currency}")`
        );
      }
      return new GlangCurrency(left.amount - right.amount, left.currency);
    }

    if (left instanceof GlangPercent && right instanceof GlangPercent) {
      return new GlangPercent(left.value - right.value);
    }

    throw new GlangRuntimeError(
      `Can't subtract ${typeName(right)} (${describeValue(right)}) from ${typeName(left)} (${describeValue(left)}).`,
      line,
      "Check that both sides are the same kind of thing."
    );
  }

  multiply(left, right, line) {
    if (typeof left === "number" && typeof right === "number") return left * right;

    // currency * number, or number * currency -> currency
    if (left instanceof GlangCurrency && typeof right === "number") {
      return new GlangCurrency(left.amount * right, left.currency);
    }
    if (typeof left === "number" && right instanceof GlangCurrency) {
      return new GlangCurrency(left * right.amount, right.currency);
    }

    // currency * percent, or percent * currency -> currency
    if (left instanceof GlangCurrency && right instanceof GlangPercent) {
      return new GlangCurrency(left.amount * right.value, left.currency);
    }
    if (left instanceof GlangPercent && right instanceof GlangCurrency) {
      return new GlangCurrency(right.amount * left.value, right.currency);
    }

    // number * percent -> number
    if (typeof left === "number" && right instanceof GlangPercent) {
      return left * right.value;
    }
    if (left instanceof GlangPercent && typeof right === "number") {
      return left.value * right;
    }

    if (left instanceof GlangCurrency && right instanceof GlangCurrency) {
      throw new GlangRuntimeError(
        `Can't multiply two money values together (${describeValue(left)} times ${describeValue(right)} doesn't mean anything financially).`,
        line,
        "Money can be multiplied by a plain number or a percentage, but not by another amount of money."
      );
    }

    throw new GlangRuntimeError(
      `Can't multiply ${typeName(left)} (${describeValue(left)}) and ${typeName(right)} (${describeValue(right)}).`,
      line,
      "Multiplication works between numbers, or between money/percentages and a number."
    );
  }

  divide(left, right, line) {
    const checkZero = (divisor) => {
      const isZero =
        (typeof divisor === "number" && divisor === 0) ||
        (divisor instanceof GlangCurrency && divisor.amount === 0) ||
        (divisor instanceof GlangPercent && divisor.value === 0);
      if (isZero) {
        throw new GlangRuntimeError(
          "Can't divide by zero.",
          line,
          "Check what's on the right side of the / — it evaluated to zero."
        );
      }
    };

    if (typeof left === "number" && typeof right === "number") {
      checkZero(right);
      return left / right;
    }

    if (left instanceof GlangCurrency && typeof right === "number") {
      checkZero(right);
      return new GlangCurrency(left.amount / right, left.currency);
    }

    // currency / currency (same type) -> plain number ratio
    if (left instanceof GlangCurrency && right instanceof GlangCurrency) {
      if (left.currency !== right.currency) {
        throw new GlangRuntimeError(
          `Can't divide ${left.currency} by ${right.currency} directly — they're different currencies.`,
          line,
          `Convert one first, e.g. convert(${describeValue(right)}, to: "${left.currency}")`
        );
      }
      checkZero(right);
      return left.amount / right.amount;
    }

    throw new GlangRuntimeError(
      `Can't divide ${typeName(left)} (${describeValue(left)}) by ${typeName(right)} (${describeValue(right)}).`,
      line,
      "Division works between two numbers, or money divided by a plain number."
    );
  }

  compare(left, right, op, line) {
    let a, b;
    if (typeof left === "number" && typeof right === "number") {
      a = left; b = right;
    } else if (left instanceof GlangCurrency && right instanceof GlangCurrency) {
      if (left.currency !== right.currency) {
        throw new GlangRuntimeError(
          `Can't compare ${left.currency} and ${right.currency} directly — they're different currencies.`,
          line,
          `Convert one first, e.g. convert(${describeValue(right)}, to: "${left.currency}")`
        );
      }
      a = left.amount; b = right.amount;
    } else if (left instanceof GlangPercent && right instanceof GlangPercent) {
      a = left.value; b = right.value;
    } else {
      throw new GlangRuntimeError(
        `Can't compare ${typeName(left)} (${describeValue(left)}) with ${typeName(right)} (${describeValue(right)}).`,
        line,
        "Comparisons (<, >, etc.) need both sides to be the same kind of thing."
      );
    }

    switch (op) {
      case "<": return a < b;
      case "<=": return a <= b;
      case ">": return a > b;
      case ">=": return a >= b;
    }
  }

  valuesEqual(left, right) {
    if (left instanceof GlangCurrency && right instanceof GlangCurrency) {
      return left.currency === right.currency && left.amount === right.amount;
    }
    if (left instanceof GlangPercent && right instanceof GlangPercent) {
      return left.value === right.value;
    }
    if (left === null || right === null) return left === right;
    return left === right;
  }

  isTruthy(value, line) {
    if (typeof value === "boolean") return value;
    if (typeof value === "number") return value !== 0;
    if (typeof value === "string") return value.length > 0;
    if (value instanceof GlangCurrency) return value.amount !== 0;
    if (value instanceof GlangPercent) return value.value !== 0;
    if (value === null) return false;
    return true;
  }

  // --- List indexing -------------------------------------------------

  evalIndex(node, env) {
    const obj = this.evaluate(node.object, env);
    const idx = this.evaluate(node.index, env);

    if (obj instanceof GlangDict) {
      if (typeof idx !== "string") {
        throw new GlangRuntimeError(
          `Dictionary keys must be text, but got ${typeName(idx)} (${describeValue(idx)}).`,
          node.line,
          `Try something like my_dict["${describeValueAsPlainString(idx)}"].`
        );
      }
      if (!obj.map.has(idx)) {
        throw new GlangRuntimeError(
          `This dictionary doesn't have a key called "${idx}".`,
          node.line,
          `Available keys: ${[...obj.map.keys()].map((k) => `"${k}"`).join(", ") || "(none — this dictionary is empty)"}`
        );
      }
      return obj.map.get(idx);
    }

    if (!(obj instanceof GlangList)) {
      throw new GlangRuntimeError(
        `Can't use [...] on ${typeName(obj)} (${describeValue(obj)}) — only lists and dictionaries support indexing.`,
        node.line,
        "Make sure the value before [ ] is actually a list or dictionary, e.g. let items = [1, 2, 3]"
      );
    }
    if (typeof idx !== "number" || !Number.isInteger(idx)) {
      throw new GlangRuntimeError(
        `List index must be a whole number, but got ${typeName(idx)} (${describeValue(idx)}).`,
        node.line,
        "Try something like my_list[0] for the first item."
      );
    }
    if (idx < 0 || idx >= obj.items.length) {
      throw new GlangRuntimeError(
        `Index ${idx} is out of range — this list only has ${obj.items.length} item${obj.items.length === 1 ? "" : "s"} (valid indexes are 0 to ${obj.items.length - 1}).`,
        node.line,
        obj.items.length === 0
          ? "This list is empty, so there's nothing to index into."
          : `Try an index between 0 and ${obj.items.length - 1}.`
      );
    }
    return obj.items[idx];
  }

  // --- Property access (stock.price, stock.pe etc.) -------------------

  evalProperty(node, env) {
    const obj = this.evaluate(node.object, env);
    const prop = node.property;

    if (obj instanceof GlangDict) {
      if (!obj.map.has(prop)) {
        throw new GlangRuntimeError(
          `This dictionary doesn't have a key called "${prop}".`,
          node.line,
          `Available keys: ${[...obj.map.keys()].map((k) => `"${k}"`).join(", ") || "(none — this dictionary is empty)"}`
        );
      }
      return obj.map.get(prop);
    }

    if (obj instanceof GlangNamespace) {
      const val = obj.get(prop);
      if (val === undefined) {
        throw new GlangRuntimeError(
          `Module "${obj.name}" doesn't have a function or value called "${prop}".`,
          node.line,
          `Check the module docs with: glang docs`
        );
      }
      return val;
    }

    if (obj instanceof GlangStock) {
      const currency = obj.getCurrency();
      switch (prop) {
        case "price":      return new GlangCurrency(obj.getPrice(), currency);
        case "prev_price": return new GlangCurrency(obj.getPrev(), currency);
        case "change":     return new GlangCurrency(obj.getChange(), currency);
        case "change_pct": return new GlangPercent(obj.getChangePct());
        case "sector":     return obj.getSector();
        case "exchange":   return obj.getExchange();
        case "pe":
        case "pe_ratio": {
          const pe = obj.getPE();
          if (pe === null || pe === undefined) return "N/A";
          return pe;
        }
        case "high52":
        case "high":
        case "week_high":  return new GlangCurrency(obj.getHigh52(), currency);
        case "low52":
        case "low":
        case "week_low":   return new GlangCurrency(obj.getLow52(), currency);
        case "volume":     return obj.getVolume();
        case "market_cap":
        case "marketcap": {
          const mc = obj.getMarketCap();
          if (mc === null || mc === undefined) return "N/A";
          return new GlangCurrency(mc, currency);
        }
        case "name":      return obj.getName();
        case "symbol":    return obj.symbol;
        case "is_demo":   return obj.isMock();
        default:
          throw new GlangRuntimeError(
            `Stocks don't have a property called "${prop}".`,
            node.line,
            `Available properties: price, pe, high52, low52, volume, market_cap, name, symbol`
          );
      }
    }

    if (obj instanceof GlangList) {
      switch (prop) {
        case "length": return obj.items.length;
        default:
          throw new GlangRuntimeError(
            `Lists don't have a property called "${prop}".`,
            node.line,
            `Available list properties: length. Or use total(), average(), max_val(), min_val() functions.`
          );
      }
    }

    throw new GlangRuntimeError(
      `${typeName(obj)} doesn't have properties you can access with a dot.`,
      node.line,
      `The dot (.) notation works on stocks and lists. For example: my_stock.price`
    );
  }

  // --- Function calls -------------------------------------------------

  evalCall(node, env) {
    const callee = this.evaluate(node.callee, env);

    if (callee && callee.__builtin__) {
      for (const a of node.args) {
        if (a.name) {
          throw new GlangRuntimeError(
            `"${callee.name}()" is a built-in function and doesn't support named arguments like "${a.name}=...".`,
            a.line,
            `Call it with plain values in order instead, e.g. ${callee.name}(...).`
          );
        }
      }
      const args = node.args.map((a) => this.evaluate(a.value, env));
      return callee.call(args, node.line);
    }

    if (callee instanceof GlangFunction) {
      const evaluatedArgs = node.args.map((a) => ({
        name: a.name,
        value: this.evaluate(a.value, env),
        line: a.line,
      }));
      return this.callFunction(callee, evaluatedArgs, node.line);
    }

    throw new GlangRuntimeError(
      `"${this.describeCallee(node.callee)}" isn't something you can call like a function.`,
      node.line,
      `Make sure it's a function name, and that you haven't shadowed it with a variable of the same name.`
    );
  }

  describeCallee(node) {
    if (node.type === "Variable") return node.name;
    return "this";
  }

  // `args` is a list of { name, value, line } — name is null for
  // positional arguments, or the parameter name for `name=value` calls.
  callFunction(fn, args, callLine) {
    const params = fn.decl.params; // [{ name, default }, ...]
    const paramNames = params.map((p) => p.name);
    const fnEnv = new Environment(fn.closure);

    // Split into positional values and a name -> value map, enforcing
    // that named arguments come after all positional ones (matches how
    // the parser reads left to right at the call site).
    const positional = [];
    const named = new Map();
    let seenNamed = false;
    for (const a of args) {
      if (a.name) {
        seenNamed = true;
        if (named.has(a.name)) {
          throw new GlangRuntimeError(
            `"${a.name}" was passed more than once to "${fn.decl.name}".`,
            callLine,
            `Check the call to ${fn.decl.name}(...) — each parameter should only get a value once.`
          );
        }
        named.set(a.name, a.value);
      } else {
        if (seenNamed) {
          throw new GlangRuntimeError(
            `Found a plain value after a named argument in this call to "${fn.decl.name}".`,
            callLine,
            `Positional values have to come first, then name=value arguments, e.g. ${fn.decl.name}(${paramNames.join(", ")}).`
          );
        }
        positional.push(a.value);
      }
    }

    if (positional.length > params.length) {
      throw new GlangRuntimeError(
        `"${fn.decl.name}" was given too many values — it takes ${params.length} (${paramNames.join(", ")}), but got ${positional.length} positional value${positional.length === 1 ? "" : "s"}.`,
        callLine,
        `Check the call to ${fn.decl.name}(...) and remove the extra value(s).`
      );
    }

    for (const key of named.keys()) {
      if (!paramNames.includes(key)) {
        throw new GlangRuntimeError(
          `"${fn.decl.name}" doesn't have a parameter called "${key}".`,
          callLine,
          `${fn.decl.name}'s parameters are: ${paramNames.join(", ") || "(none)"}.`
        );
      }
    }

    // Bind each parameter in order: positional value, then named value,
    // then its default (evaluated fresh in fnEnv so it can see earlier
    // parameters), then a friendly "missing required value" error.
    for (let i = 0; i < params.length; i++) {
      const p = params[i];
      let value;
      if (i < positional.length) {
        if (named.has(p.name)) {
          throw new GlangRuntimeError(
            `"${p.name}" was given both a positional value and a named value in this call to "${fn.decl.name}".`,
            callLine,
            `Pass "${p.name}" only once — either positionally or as ${p.name}=..., not both.`
          );
        }
        value = positional[i];
      } else if (named.has(p.name)) {
        value = named.get(p.name);
      } else if (p.default !== null) {
        value = this.evaluate(p.default, fnEnv);
      } else {
        throw new GlangRuntimeError(
          `"${fn.decl.name}" is missing a value for "${p.name}".`,
          callLine,
          `Call it like: ${fn.decl.name}(${paramNames.join(", ")})`
        );
      }
      fnEnv.define(p.name, value);
    }

    if (this.callDepth >= MAX_CALL_DEPTH) {
      throw new GlangRuntimeError(
        `"${fn.decl.name}" called itself too many times (over ${MAX_CALL_DEPTH} levels deep).`,
        callLine,
        `This usually means a function is missing its base case (the condition that stops the recursion), so it keeps calling itself forever. Double check that ${fn.decl.name}(...) always reaches a "return" without calling itself again.`
      );
    }

    this.callDepth++;
    try {
      try {
        this.executeBlock(fn.decl.body, fnEnv);
      } catch (signal) {
        if (signal instanceof ReturnSignal) {
          return signal.value;
        }
        // A small safety net for the (very unlikely, given the depth guard
        // above) case where the underlying JS engine still runs out of
        // real stack space first — translate it instead of leaking a raw
        // Node error to the user.
        if (signal instanceof RangeError) {
          throw new GlangRuntimeError(
            `"${fn.decl.name}" recursed too deeply and ran out of space to keep going.`,
            callLine,
            `Check that ${fn.decl.name}(...) always reaches a "return" without calling itself again.`
          );
        }
        throw signal;
      }
      return null; // no explicit return
    } finally {
      this.callDepth--;
    }
  }
}

// Used by str() — converts any Glang value to a plain JS string (no quotes)
function describeValueAsPlainString(value) {
  if (value instanceof GlangCurrency) return value.toString();
  if (value instanceof GlangPercent) return value.toString();
  if (value instanceof GlangList) return "[" + value.items.map(describeValueAsPlainString).join(", ") + "]";
  if (value instanceof GlangDict) {
    const entries = [...value.map.entries()].map(
      ([k, v]) => `${k}: ${describeValueAsPlainString(v)}`
    );
    return "{" + entries.join(", ") + "}";
  }
  if (typeof value === "string") return value;
  if (value === null) return "nothing";
  return String(value);
}

module.exports = {
  Interpreter,
  GlangRuntimeError,
  GlangThrownValue,
  GlangCurrency,
  GlangList,
  GlangDict,
  GlangPercent,
  GlangFunction,
  GlangStock,
};
