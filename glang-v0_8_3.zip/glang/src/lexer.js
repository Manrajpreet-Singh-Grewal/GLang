// Glang Lexer
// Turns raw .grw source text into a stream of tokens.
// This is the FIRST stage of the pipeline: text -> tokens -> AST -> result

const TokenType = {
  // Literals
  NUMBER: "NUMBER",
  STRING: "STRING",
  FSTRING: "FSTRING",         // f"Total: {amount}"
  CURRENCY: "CURRENCY",       // e.g. $500, ₹500, €500, £500
  PERCENT: "PERCENT",         // e.g. 5%
  IDENTIFIER: "IDENTIFIER",
  BOOLEAN: "BOOLEAN",

  // Keywords
  LET: "LET",
  CONST: "CONST",
  FN: "FN",
  RETURN: "RETURN",
  IF: "IF",
  ELIF: "ELIF",
  ELSE: "ELSE",
  REPEAT: "REPEAT",
  TIMES: "TIMES",
  WHILE: "WHILE",
  BREAK: "BREAK",
  CONTINUE: "CONTINUE",
  FOR: "FOR",
  IN: "IN",
  IMPORT: "IMPORT",
  TRY: "TRY",
  CATCH: "CATCH",
  FINALLY: "FINALLY",
  THROW: "THROW",
  TRUE: "TRUE",
  FALSE: "FALSE",
  AND: "AND",
  OR: "OR",
  NOT: "NOT",

  // Symbols
  PLUS: "PLUS",
  MINUS: "MINUS",
  STAR: "STAR",
  SLASH: "SLASH",
  EQUAL: "EQUAL",             // =
  EQUAL_EQUAL: "EQUAL_EQUAL", // ==
  NOT_EQUAL: "NOT_EQUAL",     // !=
  LESS: "LESS",
  LESS_EQUAL: "LESS_EQUAL",
  GREATER: "GREATER",
  GREATER_EQUAL: "GREATER_EQUAL",
  LPAREN: "LPAREN",
  RPAREN: "RPAREN",
  LBRACKET: "LBRACKET",
  RBRACKET: "RBRACKET",
  LBRACE: "LBRACE",
  RBRACE: "RBRACE",
  DOT: "DOT",
  COLON: "COLON",
  COMMA: "COMMA",

  // Structure
  NEWLINE: "NEWLINE",
  INDENT: "INDENT",
  DEDENT: "DEDENT",
  EOF: "EOF",
};

const KEYWORDS = {
  let: TokenType.LET,
  const: TokenType.CONST,
  fn: TokenType.FN,
  return: TokenType.RETURN,
  if: TokenType.IF,
  elif: TokenType.ELIF,
  else: TokenType.ELSE,
  repeat: TokenType.REPEAT,
  times: TokenType.TIMES,
  while: TokenType.WHILE,
  break: TokenType.BREAK,
  continue: TokenType.CONTINUE,
  for: TokenType.FOR,
  in: TokenType.IN,
  import: TokenType.IMPORT,
  try: TokenType.TRY,
  catch: TokenType.CATCH,
  finally: TokenType.FINALLY,
  throw: TokenType.THROW,
  true: TokenType.TRUE,
  false: TokenType.FALSE,
  and: TokenType.AND,
  or: TokenType.OR,
  not: TokenType.NOT,
};

const CURRENCY_SYMBOLS = {
  "$": "USD",
  "₹": "INR",
  "€": "EUR",
  "£": "GBP",
};

class GlangSyntaxError extends Error {
  constructor(message, line, hint) {
    super(message);
    this.name = "GlangSyntaxError";
    this.line = line;
    this.hint = hint;
  }
}

class Token {
  constructor(type, value, line, column) {
    this.type = type;
    this.value = value;
    this.line = line;
    this.column = column;
  }
}

class Lexer {
  constructor(source) {
    this.source = source;
    this.pos = 0;
    this.line = 1;
    this.column = 1;
    this.tokens = [];
    this.indentStack = [0];
    this.atLineStart = true;
    this.bracketDepth = 0; // tracks ( and [ nesting; newlines are invisible inside brackets
  }

  error(message, hint) {
    throw new GlangSyntaxError(message, this.line, hint);
  }

  peek(offset = 0) {
    return this.source[this.pos + offset];
  }

  advance() {
    const ch = this.source[this.pos];
    this.pos++;
    if (ch === "\n") {
      this.line++;
      this.column = 1;
    } else {
      this.column++;
    }
    return ch;
  }

  isAtEnd() {
    return this.pos >= this.source.length;
  }

  push(type, value) {
    this.tokens.push(new Token(type, value, this.line, this.column));
  }

  tokenize() {
    while (!this.isAtEnd()) {
      if (this.atLineStart) {
        this.handleIndentation();
        if (this.isAtEnd()) break;
      }
      this.scanToken();
    }

    // Close out any remaining indentation levels at EOF
    while (this.indentStack.length > 1) {
      this.indentStack.pop();
      this.push(TokenType.DEDENT, null);
    }

    this.push(TokenType.EOF, null);
    return this.tokens;
  }

  // Measures leading whitespace on a logical line and emits INDENT/DEDENT
  // tokens by comparing against the indent stack. Blank lines and
  // comment-only lines are skipped entirely (they don't affect indentation).
  handleIndentation() {
    let indent = 0;
    let scanPos = this.pos;

    while (scanPos < this.source.length) {
      const ch = this.source[scanPos];
      if (ch === " ") {
        indent++;
        scanPos++;
      } else if (ch === "\t") {
        this.error(
          "Tabs aren't allowed for indentation in Glang.",
          "Use spaces instead — most editors can convert tabs to spaces automatically. We recommend 4 spaces per indent level."
        );
      } else {
        break;
      }
    }

    // Blank line or comment-only line: skip indentation logic, just consume
    // the whitespace and let scanToken handle the newline/comment.
    const nextCh = this.source[scanPos];
    if (nextCh === "\n" || nextCh === "#" || nextCh === undefined) {
      while (this.pos < scanPos) this.advance();
      this.atLineStart = false; // let scanToken consume the newline/comment normally
      return;
    }

    while (this.pos < scanPos) this.advance();

    const currentIndent = this.indentStack[this.indentStack.length - 1];
    if (indent > currentIndent) {
      this.indentStack.push(indent);
      this.push(TokenType.INDENT, indent);
    } else if (indent < currentIndent) {
      while (
        this.indentStack.length > 1 &&
        this.indentStack[this.indentStack.length - 1] > indent
      ) {
        this.indentStack.pop();
        this.push(TokenType.DEDENT, null);
      }
      if (this.indentStack[this.indentStack.length - 1] !== indent) {
        this.error(
          `This line's indentation doesn't match any previous level (got ${indent} spaces).`,
          "Check that your spacing lines up exactly with an earlier line at the level you're trying to return to."
        );
      }
    }

    this.atLineStart = false;
  }

  scanToken() {
    const ch = this.peek();

    if (ch === "\n") {
      this.advance();
      // Inside brackets/parens, newlines are just whitespace — skip silently
      if (this.bracketDepth > 0) {
        this.atLineStart = false;
        return;
      }
      this.push(TokenType.NEWLINE, null);
      this.atLineStart = true;
      return;
    }

    if (ch === " " || ch === "\r") {
      this.advance();
      return;
    }

    if (ch === "\t") {
      this.error(
        "Tabs aren't allowed in Glang code.",
        "Use spaces instead, even mid-line."
      );
    }

    if (ch === "#") {
      while (!this.isAtEnd() && this.peek() !== "\n") this.advance();
      return;
    }

    if (ch in CURRENCY_SYMBOLS) {
      this.scanCurrency();
      return;
    }

    if (this.isDigit(ch)) {
      this.scanNumber();
      return;
    }

    if (ch === '"') {
      this.scanString(false);
      return;
    }

    if (ch === "f" && this.peek(1) === '"') {
      this.advance(); // consume 'f'
      this.scanString(true);
      return;
    }

    if (this.isAlpha(ch)) {
      this.scanIdentifierOrKeyword();
      return;
    }

    switch (ch) {
      case "+": this.advance(); this.push(TokenType.PLUS, "+"); return;
      case "-": this.advance(); this.push(TokenType.MINUS, "-"); return;
      case "*": this.advance(); this.push(TokenType.STAR, "*"); return;
      case "/": this.advance(); this.push(TokenType.SLASH, "/"); return;
      case "(": this.advance(); this.bracketDepth++; this.push(TokenType.LPAREN, "("); return;
      case ")": this.advance(); if (this.bracketDepth > 0) this.bracketDepth--; this.push(TokenType.RPAREN, ")"); return;
      case "[": this.advance(); this.bracketDepth++; this.push(TokenType.LBRACKET, "["); return;
      case "]": this.advance(); if (this.bracketDepth > 0) this.bracketDepth--; this.push(TokenType.RBRACKET, "]"); return;
      case "{": this.advance(); this.bracketDepth++; this.push(TokenType.LBRACE, "{"); return;
      case "}": this.advance(); if (this.bracketDepth > 0) this.bracketDepth--; this.push(TokenType.RBRACE, "}"); return;
      case ".": this.advance(); this.push(TokenType.DOT, "."); return;
      case ":": this.advance(); this.push(TokenType.COLON, ":"); return;
      case ",": this.advance(); this.push(TokenType.COMMA, ","); return;
      case "=":
        this.advance();
        if (this.peek() === "=") {
          this.advance();
          this.push(TokenType.EQUAL_EQUAL, "==");
        } else {
          this.push(TokenType.EQUAL, "=");
        }
        return;
      case "!":
        this.advance();
        if (this.peek() === "=") {
          this.advance();
          this.push(TokenType.NOT_EQUAL, "!=");
        } else {
          this.error(
            `Glang doesn't use "!" on its own.`,
            `Did you mean "not" to negate something, or "!=" to compare?`
          );
        }
        return;
      case "<":
        this.advance();
        if (this.peek() === "=") {
          this.advance();
          this.push(TokenType.LESS_EQUAL, "<=");
        } else {
          this.push(TokenType.LESS, "<");
        }
        return;
      case ">":
        this.advance();
        if (this.peek() === "=") {
          this.advance();
          this.push(TokenType.GREATER_EQUAL, ">=");
        } else {
          this.push(TokenType.GREATER, ">");
        }
        return;
      default:
        this.error(
          `Glang doesn't recognize the character "${ch}".`,
          `Check for typos or stray characters near this spot.`
        );
    }
  }

  scanCurrency() {
    const symbol = this.advance(); // consume $, ₹, €, or £
    const startLine = this.line;
    const startCol = this.column;

    if (!this.isDigit(this.peek())) {
      this.error(
        `Expected a number right after the currency symbol "${symbol}".`,
        `Try something like ${symbol}500 or ${symbol}19.99.`
      );
    }

    let numStr = "";
    while (this.isDigit(this.peek())) numStr += this.advance();
    if (this.peek() === "." && this.isDigit(this.peek(1))) {
      numStr += this.advance(); // consume "."
      while (this.isDigit(this.peek())) numStr += this.advance();
    }

    this.tokens.push(
      new Token(
        TokenType.CURRENCY,
        { amount: parseFloat(numStr), currency: CURRENCY_SYMBOLS[symbol] },
        startLine,
        startCol
      )
    );
  }

  scanNumber() {
    let numStr = "";
    while (this.isDigit(this.peek())) numStr += this.advance();
    if (this.peek() === "." && this.isDigit(this.peek(1))) {
      numStr += this.advance();
      while (this.isDigit(this.peek())) numStr += this.advance();
    }

    // Check for trailing % to make this a PERCENT token instead of NUMBER
    if (this.peek() === "%") {
      this.advance();
      this.push(TokenType.PERCENT, parseFloat(numStr) / 100);
      return;
    }

    this.push(TokenType.NUMBER, parseFloat(numStr));
  }

  scanString(isInterpolated = false) {
    const startLine = this.line;
    const startCol = this.column;
    const label = isInterpolated ? "interpolated text (f-string)" : "text (string)";
    this.advance(); // consume opening "
    let str = "";
    while (!this.isAtEnd() && this.peek() !== '"') {
      if (this.peek() === "\n") {
        this.error(
          `This ${label} was never closed before the line ended.`,
          `Strings need a closing " on the same line. Did you forget a " somewhere?`
        );
      }
      str += this.advance();
    }
    if (this.isAtEnd()) {
      this.error(
        `This ${label} was never closed.`,
        `Add a closing " at the end of your text.`
      );
    }
    this.advance(); // consume closing "
    this.tokens.push(
      new Token(isInterpolated ? TokenType.FSTRING : TokenType.STRING, str, startLine, startCol)
    );
  }

  scanIdentifierOrKeyword() {
    let str = "";
    while (this.isAlphaNumeric(this.peek())) str += this.advance();

    if (str in KEYWORDS) {
      this.push(KEYWORDS[str], str);
    } else {
      this.push(TokenType.IDENTIFIER, str);
    }
  }

  isDigit(ch) {
    return ch >= "0" && ch <= "9";
  }

  isAlpha(ch) {
    return (
      (ch >= "a" && ch <= "z") || (ch >= "A" && ch <= "Z") || ch === "_"
    );
  }

  isAlphaNumeric(ch) {
    return ch !== undefined && (this.isAlpha(ch) || this.isDigit(ch));
  }
}

module.exports = { Lexer, Token, TokenType, GlangSyntaxError, CURRENCY_SYMBOLS };
