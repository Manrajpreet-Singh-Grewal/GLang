// Glang App Server — Phase 4 Enhanced
// glang app file.grw → web app at http://localhost:4000

const http = require("http");
const path = require("path");
const fs   = require("fs");

const { Lexer, GlangSyntaxError } = require("./lexer.js");
const { Parser }                   = require("./parser.js");
const {
  Interpreter, GlangRuntimeError,
  GlangCurrency, GlangList, GlangPercent, GlangStock,
} = require("./interpreter.js");

const PORT = 4000;

// ── UI Collector ─────────────────────────────────────────────────────────
class UICollector {
  constructor() { this.elements = []; this.tabs = null; this.activeTab = null; }
  reset() { this.elements = []; }

  push(el) { this.elements.push(el); }
  text(content)              { this.push({ type:"text",    content: String(content) }); }
  card(title,value,sub,trend){ this.push({ type:"card",    title, value, sub:sub||"", trend:trend||null }); }
  metric(title,value,prev)   { this.push({ type:"metric",  title, value, prev }); }
  table(headers,rows,csv)    { this.push({ type:"table",   headers, rows, csv:csv||false }); }
  chart(label,data,kind,labels){ this.push({ type:"chart", label, kind:kind||"line", data, labels:labels||null }); }
  heading(text,level)        { this.push({ type:"heading", text, level:level||1 }); }
  divider()                  { this.push({ type:"divider" }); }
  alert(msg,kind)            { this.push({ type:"alert",   msg, kind:kind||"info" }); }
  comparison(left,right)     { this.push({ type:"comparison", left, right }); }
  progress(label,value,max)  { this.push({ type:"progress", label, value, max }); }
}

// ── GlangPercent import helper ───────────────────────────────────────────
function makePercent(decimal) {
  return new GlangPercent(decimal);
}

// ── App Interpreter ──────────────────────────────────────────────────────
class AppInterpreter extends Interpreter {
  constructor(ui, inputs) {
    super({ allowFileIO: false });
    this.ui     = ui;
    this.inputs = inputs;
    this._inputFields = [];
    this._selectOptions = {};
    this.setupAppBuiltins();
  }

  setupAppBuiltins() {
    const ui      = this.ui;
    const self    = this;

    // ── Output ──────────────────────────────────────────────────────────

    this.globals.define("show", {
      __builtin__: true, name: "show",
      call: (args) => { ui.text(args.map(v => plain(v)).join(" ")); return null; },
    });

    this.globals.define("show_card", {
      __builtin__: true, name: "show_card",
      call: (args, line) => {
        if (args.length < 2) throw new GlangRuntimeError('show_card() needs a title and a value.', line, 'show_card("Monthly EMI", emi(loan, rate, years))');
        // optional 3rd=subtitle, 4th=trend ("up"/"down"/"flat")
        ui.card(plain(args[0]), plain(args[1]), args[2] ? plain(args[2]) : "", args[3] ? plain(args[3]) : null);
        return null;
      },
    });

    this.globals.define("show_metric", {
      __builtin__: true, name: "show_metric",
      call: (args, line) => {
        // show_metric(title, current_value, previous_value)
        // Automatically shows trend arrow and % change
        if (args.length < 3) throw new GlangRuntimeError('show_metric() needs title, current value, and previous value.', line, 'show_metric("Revenue", ₹500000, ₹450000)');
        let cur = args[1], prev = args[2];
        let curAmt = cur instanceof GlangCurrency ? cur.amount : (typeof cur === "number" ? cur : null);
        let prevAmt = prev instanceof GlangCurrency ? prev.amount : (typeof prev === "number" ? prev : null);
        let trend = null;
        let chg = null;
        if (curAmt !== null && prevAmt !== null && prevAmt !== 0) {
          chg = ((curAmt - prevAmt) / prevAmt) * 100;
          trend = `${chg >= 0 ? "▲" : "▼"} ${Math.abs(chg).toFixed(2)}% vs previous`;
        }
        ui.card(plain(args[0]), plain(args[1]), trend || "", chg === null ? null : (chg >= 0 ? "up" : "down"));
        return null;
      },
    });

    this.globals.define("show_alert", {
      __builtin__: true, name: "show_alert",
      call: (args, line) => {
        if (!args[0]) throw new GlangRuntimeError('show_alert() needs a message.', line, 'show_alert("Loan approved!")');
        ui.alert(plain(args[0]), "info"); return null;
      },
    });
    this.globals.define("show_success", {
      __builtin__: true, name: "show_success",
      call: (args, line) => { ui.alert(plain(args[0] || ""), "success"); return null; },
    });
    this.globals.define("show_warning", {
      __builtin__: true, name: "show_warning",
      call: (args, line) => { ui.alert(plain(args[0] || ""), "warning"); return null; },
    });
    this.globals.define("show_error", {
      __builtin__: true, name: "show_error",
      call: (args, line) => { ui.alert(plain(args[0] || ""), "error"); return null; },
    });

    this.globals.define("show_heading", {
      __builtin__: true, name: "show_heading",
      call: (args, line) => {
        if (!args[0]) throw new GlangRuntimeError('show_heading() needs text.', line, null);
        ui.heading(plain(args[0]), args[1] ? Number(args[1]) : 1); return null;
      },
    });

    this.globals.define("show_subheading", {
      __builtin__: true, name: "show_subheading",
      call: (args) => { ui.heading(plain(args[0] || ""), 2); return null; },
    });

    this.globals.define("divider", {
      __builtin__: true, name: "divider",
      call: () => { ui.divider(); return null; },
    });

    this.globals.define("show_progress", {
      __builtin__: true, name: "show_progress",
      call: (args, line) => {
        if (args.length < 3) throw new GlangRuntimeError('show_progress() needs a label, current value, and max value.', line, 'show_progress("Savings Goal", ₹200000, ₹500000)');
        const val = args[1] instanceof GlangCurrency ? args[1].amount : Number(args[1]);
        const max = args[2] instanceof GlangCurrency ? args[2].amount : Number(args[2]);
        ui.progress(plain(args[0]), val, max); return null;
      },
    });

    this.globals.define("show_comparison", {
      __builtin__: true, name: "show_comparison",
      call: (args, line) => {
        // show_comparison(left_label, left_value, right_label, right_value)
        if (args.length < 4) throw new GlangRuntimeError('show_comparison() needs two labels and two values.', line, 'show_comparison("Option A", ₹500, "Option B", ₹700)');
        ui.comparison(
          { label: plain(args[0]), value: plain(args[1]) },
          { label: plain(args[2]), value: plain(args[3]) }
        );
        return null;
      },
    });

    this.globals.define("show_table", {
      __builtin__: true, name: "show_table",
      call: (args, line) => {
        if (args.length < 2) throw new GlangRuntimeError('show_table() needs a headers list and a rows list.', line, null);
        const [headers, rows] = args;
        if (!(headers instanceof GlangList)) throw new GlangRuntimeError('show_table() first value must be a list of column names.', line, null);
        if (!(rows instanceof GlangList)) throw new GlangRuntimeError('show_table() second value must be a list of rows.', line, null);
        const exportable = args[2] === true || plain(args[2] || "") === "true";
        const h = headers.items.map(plain);
        const r = rows.items.map(row => row instanceof GlangList ? row.items.map(plain) : [plain(row)]);
        ui.table(h, r, exportable); return null;
      },
    });

    this.globals.define("show_chart", {
      __builtin__: true, name: "show_chart",
      call: (args, line) => {
        if (args.length < 2) throw new GlangRuntimeError('show_chart() needs a label and a list of values.', line, null);
        const [label, data, kind, labelsList] = args;
        if (!(data instanceof GlangList)) throw new GlangRuntimeError('show_chart() second value must be a list.', line, null);
        const points = data.items.map(v => v instanceof GlangCurrency ? v.amount : (typeof v === "number" ? v : null)).filter(v => v !== null);
        const lbls = labelsList instanceof GlangList ? labelsList.items.map(plain) : null;
        ui.chart(plain(label), points, kind ? plain(kind) : "line", lbls); return null;
      },
    });

    this.globals.define("show_bar_chart", {
      __builtin__: true, name: "show_bar_chart",
      call: (args, line) => {
        if (args.length < 2) throw new GlangRuntimeError('show_bar_chart() needs a label and a list of values.', line, null);
        const [label, data, labelsList] = args;
        if (!(data instanceof GlangList)) throw new GlangRuntimeError('show_bar_chart() second value must be a list.', line, null);
        const points = data.items.map(v => v instanceof GlangCurrency ? v.amount : (typeof v === "number" ? v : null)).filter(v => v !== null);
        const lbls = labelsList instanceof GlangList ? labelsList.items.map(plain) : null;
        ui.chart(plain(label), points, "bar", lbls); return null;
      },
    });

    // ── Inputs ──────────────────────────────────────────────────────────

    this.globals.define("input", {
      __builtin__: true, name: "input",
      call: (args, line) => {
        if (args.length < 2) throw new GlangRuntimeError('input() needs a name and a type.', line, 'input("Loan Amount", "money")');
        const name    = plain(args[0]);
        const type    = plain(args[1]).toLowerCase();
        const default_ = args[2] !== undefined ? plain(args[2]) : null;
        const key     = name.toLowerCase().replace(/[^a-z0-9]/g, "_");
        const options = this._selectOptions[key] || null;

        // Always register field for the UI form (deduped)
        if (!this._inputFields.find(f => f.key === key)) {
          this._inputFields.push({ name, type, key, default: default_, options });
        }

        if (this.inputs[key] !== undefined && this.inputs[key] !== "") {
          return parseInput(this.inputs[key], type);
        }

        // Return default or scan-safe value when no user input yet
        return parseInput(default_ || defaultForType(type, this._scanOnly), type);
      },
    });

    this.globals.define("select", {
      __builtin__: true, name: "select",
      call: (args, line) => {
        // select("Stock Symbol", ["TCS", "INFY", "RELIANCE"])
        if (args.length < 2) throw new GlangRuntimeError('select() needs a name and a list of options.', line, 'select("Stock", ["TCS", "INFY"])');
        const name    = plain(args[0]);
        const optList = args[1];
        if (!(optList instanceof GlangList)) throw new GlangRuntimeError('select() second value must be a list of options.', line, null);
        const key     = name.toLowerCase().replace(/[^a-z0-9]/g, "_");
        const options = optList.items.map(plain);
        this._selectOptions[key] = options;

        // Always register field for the UI form (deduped)
        if (!this._inputFields.find(f => f.key === key)) {
          this._inputFields.push({ name, type: "select", key, default: options[0], options });
        }

        if (this.inputs[key] !== undefined && this.inputs[key] !== "") {
          return String(this.inputs[key]);
        }
        return options[0] || "";
      },
    });
  }
}

// ── Input parsing helpers ────────────────────────────────────────────────
function parseInput(raw, type) {
  if (raw === null || raw === undefined) raw = "";
  const s = String(raw);
  if (type === "money" || type === "currency") {
    const amt = parseFloat(s.replace(/[^0-9.]/g, ""));
    return new GlangCurrency(isNaN(amt) ? 0 : amt, "INR");
  }
  if (type === "percent" || type === "percentage") {
    const pct = parseFloat(s.replace(/[^0-9.]/g, ""));
    return new GlangPercent(isNaN(pct) ? 0 : pct / 100);
  }
  if (type === "number") {
    const n = parseFloat(s);
    return isNaN(n) ? 0 : n;
  }
  return s; // text / stock / select
}

function defaultForType(type, scanOnly) {
  // In scan-only mode use non-zero safe values so finance functions don't crash
  if (type === "money" || type === "currency") return scanOnly ? "100000" : "0";
  if (type === "percent" || type === "percentage") return scanOnly ? "8" : "0";
  if (type === "number") return scanOnly ? "10" : "0";
  return scanOnly ? "value" : "";
}

function plain(value) {
  if (value instanceof GlangCurrency) return value.toString();
  if (value instanceof GlangPercent) {
    const pct = Math.round((value.value * 100 + Number.EPSILON) * 100) / 100;
    return `${pct}%`;
  }
  if (value instanceof GlangList) return value.items.map(plain).join(", ");
  if (value instanceof GlangStock) return value.toString();
  if (typeof value === "string") return value;
  if (value === null || value === undefined) return "—";
  return String(value);
}

// ── Run app and collect UI elements ──────────────────────────────────────
function runApp(source, filename, inputs) {
  const ui = new UICollector();
  let inputFields = [];

  // Pass 1: dry run with a special "scan" interpreter that just collects
  // input field registrations without crashing on zero values.
  // We swallow all errors in this pass — we just want the field list.
  try {
    const tokens = new Lexer(source).tokenize();
    const ast    = new Parser(tokens).parse();
    const scanner = new AppInterpreter(new UICollector(), {});
    scanner._scanOnly = true; // signals the interpreter to use safe defaults
    scanner.interpret(ast);
    inputFields = scanner._inputFields || [];
  } catch (e) { /* ignore — just collecting fields */ }

  // Pass 2: real run with actual user inputs
  try {
    const tokens = new Lexer(source).tokenize();
    const ast    = new Parser(tokens).parse();
    const interp = new AppInterpreter(ui, inputs);
    interp.interpret(ast);
    // Merge any fields discovered in pass 2 that weren't in pass 1
    for (const f of (interp._inputFields || [])) {
      if (!inputFields.find(x => x.key === f.key)) inputFields.push(f);
    }
  } catch (err) {
    if (err instanceof GlangSyntaxError || err instanceof GlangRuntimeError) {
      ui.alert(`${err.message}${err.hint ? " — " + err.hint : ""}`, "error");
    } else {
      ui.alert("Internal Glang error: " + err.message, "error");
    }
  }

  return { elements: ui.elements, inputFields };
}

// ── HTML renderer ─────────────────────────────────────────────────────────
function renderHTML(appTitle, elements, inputFields) {
  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>${appTitle} — Glang</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<style>
:root{--bg:#0f1117;--s1:#1a1d2e;--s2:#242740;--s3:#2d3150;--accent:#6c63ff;--accent2:#00d4aa;--text:#e8eaf0;--muted:#9ca3b0;--red:#ff6b6b;--green:#51cf66;--yellow:#ffd43b;--blue:#74c0fc;}
*{box-sizing:border-box;margin:0;padding:0;}
body{background:var(--bg);color:var(--text);font-family:'Segoe UI',system-ui,sans-serif;min-height:100vh;display:flex;flex-direction:column;}
/* Header */
.hdr{background:linear-gradient(135deg,var(--s1),var(--s2));border-bottom:1px solid var(--s3);padding:14px 28px;display:flex;align-items:center;gap:14px;position:sticky;top:0;z-index:100;}
.hdr-logo{font-size:18px;font-weight:800;background:linear-gradient(135deg,var(--accent),var(--accent2));-webkit-background-clip:text;-webkit-text-fill-color:transparent;}
.hdr-title{font-size:16px;font-weight:600;}
.hdr-badge{background:var(--accent);color:#fff;font-size:10px;font-weight:700;padding:3px 8px;border-radius:20px;text-transform:uppercase;letter-spacing:.5px;}
.hdr-refresh{margin-left:auto;background:transparent;border:1px solid var(--s3);color:var(--muted);padding:6px 14px;border-radius:8px;cursor:pointer;font-size:12px;transition:all .2s;}
.hdr-refresh:hover{border-color:var(--accent);color:var(--accent);}
/* Layout */
.body{display:flex;flex:1;overflow:hidden;}
.sidebar{width:280px;min-width:280px;background:var(--s1);border-right:1px solid var(--s3);padding:20px 16px;overflow-y:auto;display:flex;flex-direction:column;gap:0;}
.sidebar h3{font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:1.2px;color:var(--muted);margin-bottom:14px;}
.field{margin-bottom:14px;}
.field label{display:block;font-size:12px;font-weight:500;color:var(--muted);margin-bottom:5px;}
.field input,.field select{width:100%;background:var(--s2);border:1px solid var(--s3);border-radius:8px;padding:9px 11px;color:var(--text);font-size:13px;transition:border-color .2s;}
.field input:focus,.field select:focus{outline:none;border-color:var(--accent);}
.field select option{background:var(--s2);}
.run-btn{width:100%;background:linear-gradient(135deg,var(--accent),#8b5cf6);color:#fff;border:none;border-radius:10px;padding:13px;font-size:14px;font-weight:700;cursor:pointer;transition:opacity .2s;margin-top:6px;letter-spacing:.3px;}
.run-btn:hover{opacity:.9;}
.run-btn:disabled{opacity:.6;}
.no-inputs{text-align:center;color:var(--muted);font-size:12px;padding:16px 0;line-height:1.6;}
.sidebar-footer{margin-top:auto;padding-top:20px;text-align:center;font-size:11px;color:var(--muted);}
.sidebar-footer span{color:var(--accent);font-weight:600;}
/* Main */
.main{flex:1;padding:24px 28px;overflow-y:auto;}
/* Cards */
.cards-row{display:grid;grid-template-columns:repeat(auto-fill,minmax(190px,1fr));gap:14px;margin-bottom:18px;}
.card{background:var(--s1);border:1px solid var(--s3);border-radius:14px;padding:18px 20px;position:relative;overflow:hidden;}
.card::before{content:'';position:absolute;top:0;left:0;right:0;height:3px;background:linear-gradient(90deg,var(--accent),var(--accent2));}
.card-title{font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.8px;color:var(--muted);margin-bottom:10px;}
.card-value{font-size:22px;font-weight:700;color:var(--accent2);}
.card-sub{font-size:11px;color:var(--muted);margin-top:5px;}
.card-trend-up{color:var(--green);font-size:12px;margin-top:4px;}
.card-trend-down{color:var(--red);font-size:12px;margin-top:4px;}
/* Text */
.text-line{font-family:'Courier New',monospace;font-size:13px;color:var(--text);padding:3px 0;white-space:pre-wrap;}
/* Headings */
.h1{font-size:20px;font-weight:700;color:var(--text);margin:22px 0 14px;padding-bottom:10px;border-bottom:2px solid var(--s3);}
.h2{font-size:16px;font-weight:600;color:var(--text);margin:18px 0 12px;color:var(--muted);}
/* Divider */
.divider{border:none;border-top:1px solid var(--s3);margin:18px 0;}
/* Table */
.tbl-wrap{background:var(--s1);border:1px solid var(--s3);border-radius:14px;overflow:hidden;margin-bottom:18px;}
.tbl-actions{padding:12px 16px 0;display:flex;justify-content:flex-end;}
.export-btn{background:var(--s2);border:1px solid var(--s3);color:var(--muted);padding:5px 12px;border-radius:6px;font-size:11px;cursor:pointer;transition:all .2s;}
.export-btn:hover{border-color:var(--accent2);color:var(--accent2);}
table{width:100%;border-collapse:collapse;font-size:13px;}
thead th{background:var(--s2);color:var(--muted);font-weight:600;text-transform:uppercase;font-size:10px;letter-spacing:.8px;padding:11px 15px;text-align:left;}
tbody td{padding:10px 15px;border-top:1px solid var(--s3);color:var(--text);}
tbody tr:hover{background:var(--s2);}
/* Chart */
.chart-wrap{background:var(--s1);border:1px solid var(--s3);border-radius:14px;padding:18px 20px;margin-bottom:18px;}
.chart-label{font-size:13px;font-weight:600;color:var(--muted);margin-bottom:14px;}
canvas{max-height:260px;}
/* Alert */
.alert{border-radius:10px;padding:14px 18px;margin-bottom:16px;border:1px solid;}
.alert-info{background:rgba(108,99,255,.08);border-color:var(--accent);color:var(--accent);}
.alert-success{background:rgba(81,207,102,.08);border-color:var(--green);color:var(--green);}
.alert-warning{background:rgba(255,212,59,.08);border-color:var(--yellow);color:var(--yellow);}
.alert-error{background:rgba(255,107,107,.08);border-color:var(--red);color:var(--red);}
/* Progress */
.progress-wrap{margin-bottom:16px;}
.progress-header{display:flex;justify-content:space-between;font-size:12px;color:var(--muted);margin-bottom:6px;}
.progress-bar{background:var(--s2);border-radius:99px;height:10px;overflow:hidden;}
.progress-fill{background:linear-gradient(90deg,var(--accent),var(--accent2));height:100%;border-radius:99px;transition:width .6s ease;}
/* Comparison */
.comparison{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:18px;}
.comparison-side{background:var(--s1);border:1px solid var(--s3);border-radius:14px;padding:18px;text-align:center;}
.comparison-label{font-size:11px;color:var(--muted);text-transform:uppercase;letter-spacing:.8px;margin-bottom:8px;}
.comparison-value{font-size:26px;font-weight:700;color:var(--accent2);}
/* Loading */
.loading{display:none;position:fixed;top:0;left:0;right:0;height:3px;background:linear-gradient(90deg,var(--accent),var(--accent2));z-index:999;animation:slide 1s infinite;}
@keyframes slide{0%{transform:translateX(-100%)}100%{transform:translateX(100%)}}
</style>
</head>
<body>
<div class="loading" id="loading"></div>
<div class="hdr">
  <div class="hdr-logo">Glang</div>
  <div class="hdr-title">${appTitle}</div>
  <div class="hdr-badge">Finance App</div>
  <button class="hdr-refresh" onclick="runGlang()">⟳ Refresh</button>
</div>
<div class="body">
  <div class="sidebar">
    <h3>Inputs</h3>
    <div id="fields"></div>
    <button class="run-btn" id="runBtn" onclick="runGlang()">▶ Run Analysis</button>
    <div class="sidebar-footer">Built with <span>Glang</span><br>by Grewal</div>
  </div>
  <div class="main" id="output"></div>
</div>

<script>
const INIT_ELEMENTS = ${JSON.stringify(elements)};
const INPUT_FIELDS  = ${JSON.stringify(inputFields)};
let charts = [];
let autoRefreshTimer = null;

function buildFields() {
  const c = document.getElementById("fields");
  if (!INPUT_FIELDS.length) {
    c.innerHTML = '<div class="no-inputs">No inputs needed.<br>Click Run Analysis to start.</div>';
    return;
  }
  c.innerHTML = INPUT_FIELDS.map(f => {
    if (f.type === "select" && f.options) {
      return \`<div class="field"><label>\${f.name}</label><select name="\${f.key}">\${f.options.map(o=>\`<option value="\${o}">\${o}</option>\`).join("")}</select></div>\`;
    }
    const ph = f.type==="money" ? "₹ e.g. 500000" : f.type==="percent" ? "e.g. 8.5" : f.type==="number" ? "e.g. 10" : "Enter value";
    const dv = f.default && f.default !== "0" ? f.default : "";
    return \`<div class="field"><label>\${f.name}</label><input name="\${f.key}" placeholder="\${ph}" value="\${dv}"></div>\`;
  }).join("");
}

function getInputs() {
  const inputs = {};
  document.querySelectorAll("#fields input, #fields select").forEach(el => {
    inputs[el.name] = el.value;
  });
  return inputs;
}

function renderElements(elements) {
  charts.forEach(c => c.destroy()); charts = [];
  const out = document.getElementById("output");
  let html = ""; let cardBuf = []; let chartQueue = [];

  const flushCards = () => {
    if (!cardBuf.length) return;
    html += \`<div class="cards-row">\${cardBuf.join("")}</div>\`;
    cardBuf = [];
  };

  elements.forEach((el, i) => {
    if (el.type !== "card") flushCards();
    switch (el.type) {
      case "card": {
        const trendHtml = el.trend === "up"
          ? \`<div class="card-trend-up">▲ \${el.sub}</div>\`
          : el.trend === "down"
          ? \`<div class="card-trend-down">▼ \${el.sub}</div>\`
          : el.sub ? \`<div class="card-sub">\${el.sub}</div>\` : "";
        cardBuf.push(\`<div class="card"><div class="card-title">\${el.title}</div><div class="card-value">\${el.value}</div>\${trendHtml}</div>\`);
        break;
      }
      case "text":
        html += \`<div class="text-line">\${el.content}</div>\`;
        break;
      case "heading":
        html += \`<div class="\${el.level===2?"h2":"h1"}">\${el.text}</div>\`;
        break;
      case "divider":
        html += '<hr class="divider">';
        break;
      case "alert":
        html += \`<div class="alert alert-\${el.kind}">\${el.msg}</div>\`;
        break;
      case "progress": {
        const pct = Math.min(100, (el.value / el.max) * 100).toFixed(1);
        html += \`<div class="progress-wrap"><div class="progress-header"><span>\${el.label}</span><span>\${pct}%</span></div><div class="progress-bar"><div class="progress-fill" style="width:\${pct}%"></div></div></div>\`;
        break;
      }
      case "comparison":
        html += \`<div class="comparison"><div class="comparison-side"><div class="comparison-label">\${el.left.label}</div><div class="comparison-value">\${el.left.value}</div></div><div class="comparison-side"><div class="comparison-label">\${el.right.label}</div><div class="comparison-value">\${el.right.value}</div></div></div>\`;
        break;
      case "table": {
        const exportBtn = el.csv ? \`<div class="tbl-actions"><button class="export-btn" onclick="exportCSV(\${i})">↓ Export CSV</button></div>\` : "";
        html += \`<div class="tbl-wrap" id="tbl_\${i}">\${exportBtn}<table><thead><tr>\${el.headers.map(h=>\`<th>\${h}</th>\`).join("")}</tr></thead><tbody>\${el.rows.map(r=>\`<tr>\${r.map(c=>\`<td>\${c}</td>\`).join("")}</tr>\`).join("")}</tbody></table></div>\`;
        break;
      }
      case "chart":
        html += \`<div class="chart-wrap"><div class="chart-label">\${el.label}</div><canvas id="c_\${i}"></canvas></div>\`;
        chartQueue.push({ el, i });
        break;
    }
  });
  flushCards();
  out.innerHTML = html;

  // Mount charts after DOM update
  chartQueue.forEach(({ el, i }) => {
    const canvas = document.getElementById("c_" + i);
    if (!canvas) return;
    const rising = el.data[el.data.length-1] >= el.data[0];
    const col  = el.kind === "bar" ? "rgba(108,99,255,0.7)" : (rising ? "rgba(0,212,170,1)" : "rgba(255,107,107,1)");
    const fill = el.kind === "bar" ? "rgba(108,99,255,0.3)" : (rising ? "rgba(0,212,170,0.08)" : "rgba(255,107,107,0.08)");
    const labels = el.labels || el.data.map((_,j) => j+1);
    charts.push(new Chart(canvas, {
      type: el.kind === "bar" ? "bar" : "line",
      data: { labels, datasets: [{ label: el.label, data: el.data, borderColor: col, backgroundColor: fill, borderWidth: 2, pointRadius: el.data.length > 60 ? 0 : 3, fill: el.kind !== "bar", tension: 0.3 }] },
      options: { responsive:true, plugins:{ legend:{display:false} }, scales:{ x:{ display: el.labels ? true : false, ticks:{ color:"#9ca3b0", maxTicksLimit:8 }, grid:{display:false} }, y:{ grid:{ color:"rgba(255,255,255,0.04)" }, ticks:{ color:"#9ca3b0" } } } }
    }));
  });
}

function exportCSV(tableIdx) {
  const tbl = document.querySelector("#tbl_" + tableIdx + " table");
  if (!tbl) return;
  const rows = [...tbl.querySelectorAll("tr")].map(r => [...r.querySelectorAll("th,td")].map(c => '"'+c.textContent.replace(/"/g,'""')+'"').join(","));
  const blob = new Blob([rows.join("\\n")], { type: "text/csv" });
  const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = "glang_export.csv"; a.click();
}

async function runGlang() {
  const btn = document.getElementById("runBtn");
  const loading = document.getElementById("loading");
  btn.disabled = true; btn.textContent = "Running…";
  loading.style.display = "block";
  try {
    const res = await fetch("/run", { method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify(getInputs()) });
    const { elements } = await res.json();
    renderElements(elements);
  } catch(e) {
    document.getElementById("output").innerHTML = '<div class="alert alert-error">Connection error — is the Glang server still running?</div>';
  } finally {
    btn.disabled = false; btn.textContent = "▶ Run Analysis";
    loading.style.display = "none";
  }
}

buildFields();
renderElements(INIT_ELEMENTS);
</script>
</body>
</html>`;
}

// ── HTTP Server ───────────────────────────────────────────────────────────
function startAppServer(filePath) {
  const resolved = path.resolve(filePath);
  if (!fs.existsSync(resolved)) {
    console.error(`Glang: file not found — "${filePath}"`); process.exit(1);
  }
  const filename = path.basename(resolved);
  const appTitle = filename.replace(".grw","").replace(/_/g," ").replace(/\b\w/g,c=>c.toUpperCase());

  const { runSandboxed } = require("./sandbox.js");

  const server = http.createServer((req, res) => {
    const source = fs.readFileSync(resolved, "utf8");

    if (req.method === "GET" && req.url === "/") {
      // Sandboxed: each request gets its own worker thread with a
      // timeout + memory cap, so one runaway/malicious script can't hang
      // or crash the server for every other visitor. See src/sandbox.js.
      runSandboxed(source, filename, {}).then(({ elements, inputFields }) => {
        res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
        res.end(renderHTML(appTitle, elements, inputFields));
      });

    } else if (req.method === "POST" && req.url === "/run") {
      let body = "";
      req.on("data", d => body += d);
      req.on("end", () => {
        let inputs;
        try {
          inputs = JSON.parse(body);
        } catch (e) {
          res.writeHead(400, { "Content-Type": "application/json" });
          res.end(JSON.stringify({ elements: [{ type: "alert", msg: "Couldn't read the submitted form data.", kind: "error" }] }));
          return;
        }
        runSandboxed(source, filename, inputs).then(({ elements }) => {
          res.writeHead(200, { "Content-Type": "application/json" });
          res.end(JSON.stringify({ elements }));
        });
      });
    } else {
      res.writeHead(404); res.end("Not found");
    }
  });

  server.listen(PORT, () => {
    console.log(`\n╔══════════════════════════════════════╗`);
    console.log(`║  Glang App: "${appTitle}"`);
    console.log(`║  → http://localhost:${PORT}`);
    console.log(`║  Ctrl+C to stop`);
    console.log(`╚══════════════════════════════════════╝\n`);
  });
}

module.exports = { startAppServer, AppInterpreter, runApp };
